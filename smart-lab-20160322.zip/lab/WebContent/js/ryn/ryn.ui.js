define([ 'jquery', 'ryn/utils', 'ryn/ui.notify' ], function($, UTILS, NC) {
	var _EDITABLE = 'contenteditable';

	// some useful method for jQuery selected html element
	$.extend($.fn, {
    	// get number value of a css property (if possible)
    	cssv: 		function(prop) { return $.css(this[0], prop, true); },
    	// get bounding client rect of a html element
    	bounds:		function() { return this[0].getBoundingClientRect(); },
    	// shortcut to get first child of a html element
    	firstChild: function(sel) { return this.children(sel).first(); },
    	// clone a html element without any children (top shell only)
    	cloneShell: function() { return $(this[0].cloneNode(false)); },
    	// select element's text
		selectText: function() {
			var doc = document;
			var element = this[0];
			if (doc.body.createTextRange) {
				var range = document.body.createTextRange();
				range.moveToElementText(element);
				range.select();
			} else if (window.getSelection) {
				var selection = window.getSelection();
				var range = document.createRange();
				range.collapse(false);
				range.selectNodeContents(element);
				selection.removeAllRanges();
				selection.addRange(range);
			}
		},
		// detect is focusable
		isFocusable: function() {
			return $(this).is(':radio:checked, :button, :selected, a, [contenteditable], :text');
		},
		// move to first focusable element
		autofocus: function() {
			this.isFocusable()
				? this.focus()
				: this.find(':focusable:visible, [contenteditable]').filter(this.isFocusable).eq(0).focus();
		},
		// move to next focusable element
		focusNext: function() {
			var all = $(document).find(':focusable:visible, [contenteditable]');
			return all.eq(all.index($(this)) + 1).focus();
		},

		// display a busy message associated with this selection object
		busy: function() {
			var noty = NC.post.apply(null, arguments);
			this.data('-busy-', noty);
			return noty;
		},
		// clear assosicated busy message
		busyDone: function() {
			var noty = this.data('-busy-');
			noty && noty.close();
		}

	});

    // custom jQuery selector: TH/TD with cellIndex < fixed_columns_count
    // IMPORTANT: works for only simple table layout (no extra row/col span in fixed columns)
    $.extend($.expr[':'], {
    	// custom jQuery selector: TH/TD with cellIndex < fixed_columns_count
    	// USAGE: $(':fixed(2)') -> match left 2 columns, but only work on index inside parent TR not real cell index of a grid
    	fixed : function(e, index, metadata, stack) {
	    	if (e.tagName === 'TD' || e.tagName === 'TH') {
	    		return (e.cellIndex < metadata[3]);
	    	}
	    },
	    // custom jQuery selector: data-tag attribute
	    // USAGE: $(':tag(t1,t2)') -> match with [data-tag=t1] or [data-tag=t2]
	    tag: function(e, index, metadata, stack) {
	    	var tag = $(e).data('tag') + '';
	    	return tag && $.inArray(tag, metadata[3].split(/[, ]+/)) > -1;
	    }
    });


	$.extend($.fn, {
		/**
		 * contenteditable
		 */
		editable : function() {
			var v = !!arguments[0], $el = this;
			if ($el.is('item')) {
				$el = $el.find('value');
			}

			if (arguments.length === 0) {
				v = $el.attr(_EDITABLE);
			} else {
				var dirty;
				function formatHandler(e) {
					if (dirty) {
						var $el = $(this);
						if ($el.attr('type')) {
							$el.val($el.val());
						}
					}
				};

				function initStatus() {
					dirty = false;
				}

				function keyFilterHandler(e) {
					var $el = $(this), code = e.keyCode || e.which;
					if (code === 13) { // Enter keycode
						var ws = $el.css('white-space');
						if (ws === 'pre' || ws === 'pre-wrap' || ws === 'pre-line') {
							dirty = true;
							if (document.selection) {
								// IE 9 only
								var rng = document.selection.createRange();
								rng.text='\n';
								rng.select();
							} else {
								var selection = window.getSelection(),
									rng = selection.getRangeAt(0),
									br = document.createElement('br');

								rng.deleteContents();
								rng.insertNode(br);
								rng.setStartAfter(br);
								rng.setEndAfter(br);
								rng.collapse(false);

								selection.removeAllRanges();
								selection.addRange(rng);
							}
						} else {
							$el.blur().focusNext().selectText();
						}
						e.preventDefault();
					}
					dirty = true;
				}

				$el.off('focusout', formatHandler)
				   .off('focusin', initStatus)
				   .off('keydown', keyFilterHandler);
				$el.attr(_EDITABLE, v);
				if (v) {
					$el.on('focusout', formatHandler)
					   .on('focusin', initStatus)
					   .on('keydown', keyFilterHandler);
				} else {
					$el.removeAttr(_EDITABLE);
				}
			}

			return v;
		}
	});

	return {};
});
