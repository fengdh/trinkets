/**
 * ryn.ui.touch.js
 *    - A lightweight multi-touch support library, mostly targeting for mobile Safari on iOS device
 *    	(other webkit browser maybe work, but isn't tested thoroughly).
 *    - Basic multi-touch operation depended on jQuery Event Extension, providing path tracing ability to help
 *      implementing sophisticated custom gesture.
 *    - Prevent annoying bounce scroll on iOS device to provide better user experience.
 *
 * RYN(凜) is named after my pretty daughter.
 *
 * @author Feng Dihai<fengdh@gmail.com>
 * @version 0.0.1 preview
 * @since  2014/07/01
 */
define(['jquery', 'ryn/geometry', 'ryn/utils', 'ryn/ui.notify'], function($, G, UTILS, NC) {
    /*! iNoBounce - v0.1.0
    * https://github.com/lazd/iNoBounce/
    * Copyright (c) 2013 Larry Davis <lazdnet@gmail.com>; Licensed BSD */
    (function(global) {
        // Stores the Y position where the touch started
        var startY = 0;

        // Store enabled status
        var enabled = false;

        var handleTouchmove = function(evt) {
            // Get the element that was scrolled upon
            var el = evt.target;

            // Check all parent elements for scrollability
            while (el !== document.body) {
                // Get some style properties
                var style = window.getComputedStyle(el);
                var scrolling = style.getPropertyValue('-webkit-overflow-scrolling');
                var overflowY = style.getPropertyValue('overflow-y');
                var height = parseInt(style.getPropertyValue('height'), 10);

                // Determine if the element should scroll
                var isScrollable = scrolling === 'touch' && (overflowY === 'auto' || overflowY === 'scroll');
                var canScroll = el.scrollHeight > el.offsetHeight;

//                 var cls = el.getAttribute('class');
//                 if (cls === 'selectize-dropdown-content') {
// //                    alert(isScrollable + ', ' + canScroll);
//                 }
                if (isScrollable && canScroll) {
                    // Get the current Y position of the touch
                    var curY = evt.touches ? evt.touches[0].screenY : evt.screenY;

                    // Determine if the user is trying to scroll past the top or bottom
                    // In this case, the window will bounce, so we have to prevent scrolling completely
                    var isAtTop = (startY <= curY && el.scrollTop === 0);
                    var isAtBottom = (startY >= curY && el.scrollHeight - el.scrollTop === height);

                    // Stop a bounce bug when at the bottom or top of the scrollable element
                    if (isAtTop || isAtBottom) {
                            evt.preventDefault();
                        // alert(startY + ' <= ' + curY);
                        if ($(':focus').length === 0) {
                            evt.preventDefault();
                        } else {
//                            NC.debug(el.scrollHeight + ' - ' + el.scrollTop + ' ? ' + height);
//                            if (el.scrollTop > 20) {
//                                evt.preventDefault();
//                            }
//                            NC.debug('scroll top: ' + document.body.scrollTop);
                            if (document.body.scrollTop !== 0) {
//                                alert(document.body.scrollTop);
                                evt.preventDefault();
                                evt.stopPropagation();
                                document.body.scrollTop = 0
                            }
                        }
                    }

                    // No need to continue up the DOM, we've done our job
                    return;
                }

                // Test the next parent
                el = el.parentNode;
            }

            // Stop the bouncing -- no parents are scrollable
            evt.preventDefault();
        };

        var handleTouchstart = function(evt) {
            // Store the first Y position of the touch
            startY = evt.touches ? evt.touches[0].screenY : evt.screenY;
        };

        var enable = function() {
            // Listen to a couple key touch events
            window.addEventListener('touchstart', handleTouchstart, false);
            window.addEventListener('touchmove', handleTouchmove, false);
            enabled = true;
        };

        var disable = function() {
            // Stop listening
            window.removeEventListener('touchstart', handleTouchstart, false);
            window.removeEventListener('touchmove', handleTouchmove, false);
            enabled = false;
        };

        var isEnabled = function() {
            return enabled;
        };

//	    // Enable by default if the browser supports -webkit-overflow-scrolling
//	    // Test this by setting the property with JavaScript on an element that exists in the DOM
//	    // Then, see if the property is reflected in the computed style
//	    var testDiv = document.createElement('div');
//	    document.documentElement.appendChild(testDiv);
//	    testDiv.style.WebkitOverflowScrolling = 'touch';
//	    var scrollSupport = 'getComputedStyle' in window && window.getComputedStyle(testDiv)['-webkit-overflow-scrolling'] === 'touch';
//	    document.documentElement.removeChild(testDiv);

        var scrollSupport = true;
        if (scrollSupport) {
            enable();
        }

        // A module to support enabling/disabling iNoBounce
        var iNoBounce = {
            enable: enable,
            disable: disable,
            isEnabled: isEnabled
        };

        if (typeof module !== 'undefined' && module.exports) {
            // Node.js Support
            module.exports = iNoBounce;
        }
        if (typeof global.define === 'function') {
            // AMD Support
            (function(define) {
                define(function() { return iNoBounce; });
            }(global.define));
        }
        else {
            // Browser support
            global.iNoBounce = iNoBounce;
        }
    }(this));

    var module = {
            name: 'ryn.ui.touch',
            ver: '0.1.0',
            option: function(options) { $.extend(SETTINGS, options); },
            debug: function(enable) { DEBUG = enable; _debug(enable);},
            initTrace: function(options) {
                return options;
            },
    };

    if (!('ontouchstart' in window)) {
        return module;
    }

    var SIXTH_PI = Math.PI / 6, abs = Math.abs, NOOP = $.noop, findDblClickOwner = NOOP,
        DEBUG = false,
        SETTINGS = {
            pulse: 100,                // ms
            longTapThreshold: 500,     // ms
            doubleClickSpeed: 300,     // ms
            flickSpeed: 400,           // ms
            TapBoxSize: 16,            // px
            traceMinStep: 40,     	   // px
    };

//    module.debug(false);

    function setupEventExtension() {
        function markOne(elem, prop, value) {
            var r = elem[prop] = (elem[prop] || 0) + value;
            value >= 0 || r !== 0 || delete elem[prop];
        }

        function mark(elem, selector, prop, value) {
            selector
                ? $(elem).find(selector).each(function(elem) {markOne(this, prop, value);})
                : markOne(elem, prop, value);
        }

        function findMarkOwner(prop, target) {
            if (!target[prop]) {
                target = target.parentElement;
                return (target != null) ? findMarkOwner(prop, target) : false;
            }
            return target;
        }

        var counter = {},
            _touch = { setup : NOOP,
                       handle: function() {
                           var h = arguments[0].handleObj.handler;
                           $.isFunction(h) && h.apply(this, Array.prototype.slice.call(arguments)); } };

        // jQuery Event Extension customization
        $.extend(jQuery.event.special, {
            touchstart: {
                handle: function(/* e, data1, data2, ..*/ ) {
                    var e = arguments[0], handler = e.handleObj.handler;
                    if (e.handleObj.namespace === 'trace') {
                        e.originalEvent && (e.originalEvent._trace = e.data);
                    }
                    $.isFunction(handler) && handler.apply(this, Array.prototype.slice.call(arguments));
                }
            },
            touchmove : _touch,
            touchend:   _touch,
            click: {
                setup: NOOP,

                // For checkbox, fire native event so checked state will be right
                trigger: function() {
                    if ( jQuery.nodeName( this, "input" )) {
                        if (this.type === "checkbox" && this.click ) {
                            this.click();
                        }
                        return false;
                    }
                }
            },
            // mark element which has dblclick event handler
            dblclick: {
                setup:  function() {
                    (counter['dblclick'] = (counter['dblclick'] || 0) + 1) === 1 && (findDblClickOwner = findMarkOwner.bind(null, '_has_dblClickHandler'));
                },
                teardown: function() { (counter['dblclick'] -= 1) === 0 && (findDblClickOwner = NOOP);},
                add:      function(handleObj) { mark(this, handleObj.selector, '_has_dblClickHandler', 1); },
                remove:   function(handleObj) { mark(this, handleObj.selector, '_has_dblClickHandler', -1); }
            },
        });
    }

    /**
     * A simple and fast incremental path tracer which abstracts proximal vertices using only the current and latest
     * point/vertex, based on algorithm published by Kevin Mehall: Line and Shape Recognition in Javascript
     * (http://kevinmehall.net/2009/line-and-shape-recognition) under MIT license.
     *
     * This implementation includes revision to improve path tracing accuracy, also support of both
     * step-by-step and batch mode of parsing points along the path.
     *
     * Usage:
     *    var pathfinder = new PathFinder(t);        // start a path finder at point (t.pageX, t.pageY) with specified id, discard raw points position
     *
     *    pathfinder.setp(x, y);				     // add new point (x, y), tracing step-by-step or not
     *
     *    var path = pathfinder.finish().result();   // finish tracing and retrieve result as array of vertex [[x0, x0], ... [xn, yn]]
     *
     * @param t A touch object
     * @param tracker Specify how to track raw path positions:
     * 				  - undefined(missed) or false, default, keep trace result but discard raw positions
     *                - true, keep both trace result and raw positions
     *                - function(x, y), custom way to record raw positions.
     *                	This function will be bound to local variable 'path' which is initialized as [startX, startY, startX, startY].
     *                  One example is to record first and last position only
     */
    function PathFinder(t, tracker) {
        // import Geometry functions as local
        eval(G.exportAs('G'));
        var identifier = t.identifier, startX = t.pageX, startY = t.pageY, ts = t.timeStamp,
            // tracing point along path
            first = [startX, startY], prev = first, curr,
            // latest tracing result vertex
            anchor = first,
            // 2-dimension array holding all vertices deducted from path
            vertices = [first],
            // accrued length of tracing path since the latest result point
            stretch = 0,
            // accrued approximate deviation from tracing path since the latest result point, considering different side along path
            deviation = 0,
            // current tracing index upon path array
            i = 2,
            MINSTEP = SETTINGS.traceMinStep,
            // recording touch move direction(horizontal/vertical approximatly) and offset from start point
            motion = {},
            path = [startX, startY];

        /**
         * Trace on a new point along path.
         *
         * It is based on the latest vertex and point along path to deduct a new result vertex,
         * giving a significant distance and change of direction happened.
         */
        function trace(x, y) {
            var v0 = delta(anchor, prev), v1 = delta(prev, curr = [x, y]), lv1 = len(v1), theta;

            stretch += lv1;
            if (stretch > MINSTEP || lv1 > MINSTEP || len(v0) + lv1 > MINSTEP) {
                updateMotion(curr);

                if (!same(v1, v0)) {
                    if ((theta = angle(v1, v0)) > SIXTH_PI
                            || abs(deviation += lv1 * theta * direction(v1, v0)) > MINSTEP) {
                        vertices.push(anchor = prev);
                        prev = curr; deviation =  stretch = 0; i += 2;
                        return;
                    }
                }
            }
            prev = curr; i += 2;
        }

        function updateMotion(p) {
            var d;
            if (motion.v != true && motion.h !== false) {
                d = delta(p, first);
                motion.h = alongAxis(d[0], d[1]);
            }
            if (motion.h !== true && motion.v !== false) {
                d = d || delta(p, first);
                motion.v = alongAxis(d[1], d[0]);
            }
        }

        function alongAxis(x, y) {
            if (abs(x) > MINSTEP) {
                return y !== 0 ? abs(x/y) > 6 : true;
            }
        }

        function shape() {
            for (var i = 0, result; i < arguments.length; i++) {
                if (result = arguments[i](vertices)) {
                    return result;
                }
            }
            return vertices;
        }

        /**
         * Finish path tracing:
         * 	- Close path if start/end point near each other enough.
         *  - Try to regularize square when possible.
         *  - Try to merge the latest two point near each other enough.
         *  - Update touch move direction and offset from start point.
         *
         *  @param shape(s) optional, convert vertices to shape if possible
         */
        function finish(/* shape1, shape2, ... */) {
            // trim end points
            if (vertices.length > 1 && len(delta(curr, anchor)) < MINSTEP / 3) {
                vertices.pop();
            }

            // close path
            curr = curr || first;
            if (len(delta(curr, first)) < MINSTEP / 2) {
                motion = {};
                vertices.push(first);
                vertices.closed = true;
                if (arguments.length > 0) {
                    vertices = this.shape.apply(this, arguments);
                }
            } else {
                updateMotion(curr);
                vertices.push(curr);
            }

            return this;
        }

        /**
         * Return a value object containing touch move direction and offset from start point:
         * { h: undefined/false/'right'/'left',
         *   v: undefined/false/'down'/'up',
         *   offset: [x, y]
         * }
         */
        function getMotion(last) {
            last = last || curr || first;
            var offset = {x : last[0] - first[0], y : last[1] - first[1]};
            if (motion.h) {
                motion.h = offset.x > 0 ? 'right' : 'left';
            } else if (motion.v) {
                motion.v = offset.y > 0 ? 'down' : 'up';
            }
            motion.extent = { start:  {x: first[0], y: first[1]},
                              end:    {x: last[0],  y: last[1]},
                              offset: offset};
            return motion;
        }

        // how to track path?
        if ($.isFunction(tracker)) {
            path.push(startX, startY);
            step = function(x,y) { updateMotion(curr = [x, y]); tracker.call(path, x, y); };
        } else if (tracker === true) {
            step = function(x, y) { path.push(x, y); trace(x, y);};
        } else {
            step = trace;
        }

        return  $.extend(this, {
            id:        function() { return identifier; },
            timeStamp: function() { return ts; },
            result:    function() { return vertices; },
            path:      function() { return path || []; },
            step:      step,
            finish:    finish,
            getMotion: getMotion,
            shape:     shape,
        });
    }

    function _debug(enable) {
        PathFinder.prototype = enable
            ? { debug: function(plot, option) {
                    if (plot) {
                        if (option === 'raw') {
                            plot(this.id(), this.path(), 'raw');
                        } else {
                            plot(this.id(), this.result().reduce(function(a,b) {return a.concat(b);}), option);
                        }
                    }
                    return this;
               }}
            : {debug: NOOP};
    }

    _debug(DEBUG);

    /**
     * Delayed event trigger.
     *
     * @param target
     * @param type
     * @param context Context providing extra necessary data
     * @param delay
     * @param monitor Function to be called just before triggering the event, return true to cancel
     * @return A timer id to identify the delayed event trigger, can be canceled using clearTimeout().
     */
    function will(target, type, context, delay, monitor) {
        return setTimeout(function() { (monitor && monitor()) || $(target).trigger(type, context); }, delay);
    }

    /**
     * Create a new fact object which will keep track of basic states(id/path/time stamp etc.)
     * through one touch operation from its start to end.
     *
     * A touch operation maybe be involved with multiple touches or more than one touch-start-move-end cycle
     * to support delayed operation (click vs. double click).
     *
     * It is used to help implementing:
     * 	- basic touch operation: fast click/double click/long tap
     *  - custom gesture: multiple tap/flick/swipe/drag or more sophisticated path/shape based operation
     *
     * @param te A touch start event which stands for a new touch operation. Only the one in a series of
     *           related touch events (start-move-end) can create a new fact object.
     */
    function createFact(te) {
        var fact = {},
            // first touch object which is responsible for distinguishing a touch operation
            t = te.touches[0],
            // touch id used to distinguish a touch operation
            tid = t.identifier,
            // start time of a touch operation
            ts = te.timeStamp,
            // start point of a touch operation
            tapAt = {x: t.pageX, y: t.pageY},
            // tap(click) invalid flag, tap operation must be constrained inside a small touch box area
            outofTapBox = false,
            // record all touch id occurred during one touch operation
            tidset = {},
            // map of PathFinder (with touch id as key) tracking of none/single or multiple touches
            tracers = {},
            // a delayed long-tap, which can be canceled by a significant movement or too quick touch end
            willLongTap = will(te.target, 'longtap', fact, SETTINGS.longTapThreshold),
            // debug raw path flag
            TAPBOXSIZE = SETTINGS.TapBoxSize,
            // trace option: none/single/multiple, keep raw path
            tr = te._trace;

        var trace, tracker = (!tr || !tr.type) ? function(x, y) {this[2] = x; this[3] = y;} : tr.raw;

        if (tr && tr.type === 'multi') {
            trace = function traceMulti(touchEvent) {
                var i, touches = touchEvent.changedTouches, len = touches.length;
                for (i = 0; i < len; i++) {
                    var t = touches[i], id = t.identifier, pf = tracers[id];
                    tidset[id] = 1;
                    if (pf) {
                        pf.step(t.pageX, t.pageY);
                    } else {
                        pf = tracers[id] = new PathFinder(t, tracker);
                    }

                    // starter touch
                    if (tid === id && !outofTapBox) {
                        if ((abs(t.pageX - tapAt.x) > TAPBOXSIZE || abs(t.pageY - tapAt.y) > TAPBOXSIZE)) {
                            outofTapBox = true; clearTimeout(willLongTap);
                        }
                    }

                    pf.debug($._draw_trace, 'raw');
                    pf.debug($._draw_trace, false);
                }
            };
        } else {
            trace = function traceSingle(touchEvent) {
                var i, touches = touchEvent.changedTouches, len = touches.length;
                for (i = 0; i < len; i++) {
                    var t = touches[i], id = t.identifier;
                    tidset[id] = 1;

                    // starter touch
                    if (tid === t.identifier) {
                        var pf = tracers[id];
                        if (!pf) {
                            pf = tracers[id] = new PathFinder(t, tracker);
                            continue;
                        }

                        if(!outofTapBox) {
                            if ((abs(t.pageX - tapAt.x) > TAPBOXSIZE || abs(t.pageY - tapAt.y) > TAPBOXSIZE)) {
                                outofTapBox = true; clearTimeout(willLongTap);
                            }
                        }

                        pf.step(t.pageX, t.pageY);

                        pf.debug($._draw_trace, 'raw');
                        pf.debug($._draw_trace, false);
                    }
                }
            };
        }

        trace(te);

        return  $.extend(fact, {
            target: function() { return te.target;},
            id: function() { return tid; },
            idset: function() { return tidset;},
            // total touch count occurred in one touch operation, include released ones
            touchCount: function() { return Object.keys(tidset).length; },
            isOutofTapBox: function(touchMove) { return outofTapBox; },

            isFlick: function(now) { return (now || $.now()) - ts <= SETTINGS.flickSpeed; },
            isLongTap: function(now) { return now - ts >= SETTINGS.longTapThreshold; },
            cancelLongTap: function() { clearTimeout(willLongTap);},

            /**
             * trace each touch, for internal implementation only
             */
            trace: trace,
            /**
             * @param id Specify a touch id to retrieve its path trace result, if missed return all.
             */
            getPath: function(id) { return (arguments.length === 1)  ? tracers[id] : tracers; },
            /**
             * Short-cut method for prime path.
             */
            path:   function() { return tracers[tid];},
            motion: function() { return tracers[tid].getMotion(); },
            extent: function() { return tracers[tid].getMotion().extent; }
        });
    }


    (function touchSupport() {
       function maybeClick(touchEvent, fact) {
            var timelimit = touchEvent.timeStamp + SETTINGS.doubleClickSpeed, target = touchEvent.target,
                willClick = will(target, 'click', fact, SETTINGS.doubleClickSpeed, function() {
                    delayClick = null;
DEBUG && NC.post('I', 'click: ' + target.tagName + '.' + target.getAttribute('class'));
                });

            return {
                checkDoubleClick: function(nextTouchEvent) {
                    if (findDblClickOwner(target) === findDblClickOwner(nextTouchEvent.target)) {
                        if (nextTouchEvent.timeStamp <= timelimit) {
                            clearTimeout(willClick);
                            delayClick = null;
                            $(target).trigger('dblclick', fact);
DEBUG && NC.post('I', 'double click: ' + target.tagName + '.' + target.getAttribute('class'));
                            return true;
                        }
                    } else {
                        clearTimeout(willClick);
                    }
                },
                cancel: function() { clearTimeout(willClick); }
            };
        }

        // TODO: no double click event handler at all

        var fact, delayClick;

        document.addEventListener('touchstart', function(te) {
DEBUG && $._draw_trace && $._draw_trace();
DEBUG && NC.post('length: touches = ' + te.touches.length + ', changed = ' + te.changedTouches.length);

            var dc = delayClick;
            delayClick = null;

            if (!dc || !dc.checkDoubleClick(te)) {
                fact = fact || createFact(te);
            } else {
                fact && fact.trace(te);
            }
        });

        document.addEventListener('touchmove', function(te) {
            fact && fact.trace(te);
            $(te.target).trigger($.Event(te), fact);
        });

        document.addEventListener('touchend', function(te) {
            if (te.touches.length === 0 && fact) {
                if (!fact.isLongTap(te.timeStamp)) {
                    fact.cancelLongTap();
                    if (!fact.isOutofTapBox()) {
                        // Support double click triggered by single finger only
                        if (fact.touchCount() === 1 && findDblClickOwner(te.target)) {
                            if (!delayClick) {
                                if (te.target === fact.target()) {
                                    delayClick = maybeClick(te, fact);
                                }
                            } else {
                                delayClick.cancel();
                                delayClick = null;
                            }
                        } else {
                            $(fact.target()).trigger('click', fact);
//                            fact = null;
//                            return;
DEBUG && NC.post('I', 'click: ' + te.target.tagName + '.' + te.target.getAttribute('class'));
                        }
                    }
                }

if (DEBUG) {
    var tracers = fact.getPath();
    for (var k in tracers) {
        tracers[k].finish(G.shape.square).debug($._draw_trace, true);
    };
}

                $(fact.target()).trigger($.Event(te), fact);
                fact = null;
            }
        });

        document.addEventListener('touchcancel', function(te) {
            fact && fact.cancelLongTap(); fact = null;
            delayClick && delayClick.cancel(); delayClick = null;
DEBUG && NC.post('W', 'touch canceled!');
        });


        setupEventExtension();
    })
    ()
    ;

    return module;
});


