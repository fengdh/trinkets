/**
 * app.cache.js
 *
 * IMPORTANT:
 * This script is not a AMD module, which must be included in <head> section before any other scripts being loaded.
 * It is used to manage cached resource trying to keep web application up-to-date.
 */
window.addEventListener('load', function(e) {
    (function tryUpdateCache(appCache) {
        function css(e, n, v) { return arguments.length === 1 || (e.style[n] = v), css.bind(null, e); }

        if (appCache) {
            var body = document.body,
                html = document.documentElement,
                bar = document.createElement('div'),
                msgbody = document.createElement('div'),
                MSG = ['アプリケーションをダウンロードしています。',
                       '新しいバージョンが見つかりました。\r\n画面は自動的に更新します。'],
                PARAMS = {
                    modal: true,
                    startDelay: 0,
                    lifespan: 0,
                    displayPace: 0,
                    icon: true,
                    message: '%iconにタップして、Webアプリを<br><strong>ホーム画面に追加</strong>してください。',
                    onShow: function() { body.classList.add('fuzzy');},
                    onRemove: function() { body.classList.remove('fuzzy');},
                };

            bar.appendChild(msgbody);

            css(msgbody, 'position', 'relative')('top', '50%')('-webkit-transform', 'translateY(-50%)')('display', 'inline-block')('text-align', 'left')('font-weight', 'bold');

            appCache.addEventListener('downloading',function() {
                body.classList.add('fuzzy');

                css(bar)('position', 'absolute')('bottom', '100%')('height', '80px')('width', '100%')
                        ('background', '#000')('color', '#FFF')('z-index', '1')('-webkit-transform', 'translateZ(20px)')
                        ('white-space', 'pre-wrap')('text-align', 'center');

                msgbody.innerText = MSG[0];
                css(html, '-webkit-transition', '-webkit-transform 500ms ease')('-webkit-transform', 'translateY(80px)');
                html.appendChild(bar);
            });

            appCache.addEventListener('cached',function() {
                css(html, '-webkit-transition', '-webkit-transform 500ms ease')('-webkit-transform', 'translateY(0px)');
                html.removeChild(bar);

                if (!window.navigator.standalone) {
                    addToHomescreen(PARAMS);
                } else {
                    body.classList.remove('fuzzy');
                }
            });

            appCache.addEventListener('noupdate',function() {
                addToHomescreen(PARAMS);
                body.classList.remove('fuzzy');
            });

            appCache.addEventListener('updateready',function() {
                msgbody.innerText = MSG[1];
                appCache.swapCache();

                msgbody.addEventListener('click', function() { location.reload(); });

                setTimeout(function() {
                    css(html, '-webkit-transition', '-webkit-transform 200ms ease')('-webkit-transform', 'translateY(0px)');
                    setTimeout(function() {location.reload();}, 500);
                }, 500);
            });
          
          body.classList.remove('fuzzy');
        }
    }) (window.applicationCache);
}, false);

