define(['jquery', 'ryn/utils', 'ryn/ui'], function($, UTILS, UI) {

//    var requestFrame = (function(){
//        var raf = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame ||
//                              function(fn){ return window.setTimeout(fn); };
//        return function(fn){ return raf(fn); };
//      })();

    var RYN_GRID = '_ryn.grid_',

        COMPOSER = {
            tag: function ($row, data, recNo, lineIndex) {
                function bindTag() {
                    var $elm = $(this), tag = $elm.data('tag');
                    if (tag) {
                        $elm.val(data[tag]);
                    }
                    return $elm;
                }
                $row.children().each(function(idx) {
                    bindTag.call($(this)).find('*[data-tag]').each(bindTag);
                });
                return $row;
            },
            indexed: function ($row, data, recNo, lineIndex) {
                return $row;
            }
        },

        ROLLER = {
            single: function(arr, $tbody, $row_tmpl, compose, indexer) {
                if (arr) {
                    var i, len = arr.length, $row, j;
                    if ($.isArray(compose)) {
                        compose = compose[0];
                    }
                    for (i = 0; i < len; i++) {
                        $row = indexer($row_tmpl.clone(), i, arr[i]);
                        compose && $tbody.append(compose($row, arr[i], i));
                        if (i % 2 === 1) {
                            $row.addClass('even');
                        }
                    }
                    $row && $row.addClass('bottom');
                } else {
                    // TODO: create empty body rows
                }
            },
            multiline: function(arr, $tbody, $row_tmpl, compose, indexer) {
                $tbody.addClass('multi-lines');
                if (arr) {
                    var i, len = arr.length, $row, j;
                    // TODO: rewrite in a robust and effective way
                    if ($.isArray(compose)) {
                        for (i = 0; i < len; i++) {
                            $row = indexer($row_tmpl.clone(), i, arr[i]);
                            for (j = 0; j < $row.length; j++) {
                                compose[j] && $tbody.append(compose[j]($row.eq(j), arr[i], i, j));
                            }
                            if (i % 2 === 1) {
                                $row.addClass('even');
                            }
                        }
                    } else {
                        for (i = 0; i < len; i++) {
                            $row = indexer($row_tmpl.clone(), i, arr[i]);
                            for (j = 0; j < $row.length; j++) {
                                compose && $tbody.append(compose($row.eq(j), arr[i], i, j));
                            }
                            if (i % 2 === 1) {
                                $row.addClass('even');
                            }
                        }
                    }
                    $row && $row.addClass('bottom');
                } else {
                    // TODO: create empty body rows
                }
            }
        },
        DEFAULTS = {
            // simple: false,
            fill: true,
            // fixedCols: ':fixed(1)',
            indexer: function($row, rowIndex, data) {
                return $row.find('.-row-index').html(rowIndex + 1), $row;
            },
            adapt: function(obj) {
                return $.isArray(obj) ? UTILS.slice(obj) : $.makeArray(obj);
            },
            composer: COMPOSER.tag
        },
        settings = Object.create(DEFAULTS);

    function setupOneRow(lineIndex, obj) {
        var $row = $(obj),
            cols = parseInt($row.data('cols'), 10)
                    - $.makeArray($row.children()).reduce(function(p, c) { return p + c.colSpan; }, 0);
        $row.append(UTILS.repeat('<td/>', cols))
            .remove().removeClass('-row-tmpl').removeAttr('data-tags').removeAttr('data-cols');
        obj.className.length || $row.removeAttr('class');
        // IE9だけは<TD>と<TD>間の余分の空白・改行の影響を受け、セルがずれってしまうことがある。　→　一律削除。
        $row.contents().filter(function(){ return this.nodeType !== 1; }).remove();
    }

    // loop through children of a pair of html element (such as a thead/tbody/tr)
    function loop($src, $target, op) {
        for ($src = $src.firstChild(), $target = $target.firstChild(); $target.length !== 0; $src = $src.next(), $target = $target.next()) {
            if (op($src, $target)) {
                return true;
            };
        }
        return false;
    }

    // match each cell's height/width between 2 tables
    function matchRow($src, $target) {
        loop($src, $target.height($src.bounds().height), matchWidth);
    }

    function matchWidth ($c1, $c2) {
        $c2.width($c1.bounds().width
                    - $c1.cssv('padding-left') - $c1.cssv('padding-right')
                    - $c2.cssv('border-left-width') - $c2.cssv('border-right-width'));
    };


    var Class = function($table, options) {
        if ($table && $table.is('table')) {
            /**
             * internal local variables:
             *   [data/view]
             * 		_input:		holding raw input data
             *  	_arr:		cached array of row data being processed (mapping/sorting/filtering)
             *  	_rpp:		rows per page
             *  	_top:		top row index in viewport
             *
             * 	 [element]		html element = /abrev./ jQuery selection object for a html element
             * 		$wrapper:	wrapper html element (usually a DIV) of the base table of this grid
             * 		$thead:		the first (and only) thead element in base table
             * 		$tbody:		the content body in base table
             * 		$pintop:	wrapper html element which holds pinned column/row header and corner area
             *		$pinleft
             *		$pincorner
             * 	 [bounds]
             * 		wbounds:
             *
             * 	 [etc]
             * 		delayer:
             * 		grid:       hold the only Grid instance of a table element
             */
            var _input,
                _arr,
                _rpp,
                _top,

                $wrapper = $table.closest('.-rg'),
                $scroll = $wrapper.parent(),
                pinme,
                wbounds,
                delayer = UTILS.delayer(),
                grid = $table.data(RYN_GRID);

            var local = (grid && grid instanceof Class) && grid._local();

            if (!local) {
                local = $.extend(Object.create(settings), {rowTmpl:  $table.find('.-row-tmpl')}, options);
            } else if (options) {
                local = $.extend(local, options);
            }

            if (!('simple' in local)) {
                local.simple = $table.hasClass('simple');
            }

            if ($.isNumeric(local.fixedCols)) {
                local.fixedCols = ':fixed(' + local.fixedCols + ')';
            }

            // mark up tbody contains multi-lines row for each record
            if (local.rowTmpl.length > 1) {
                local.roller || (local.roller = ROLLER.multiline);
            } else {
                local.roller || (local.roller = ROLLER.single);
            }

            // clone row template
            local.rowTmpl = UTILS.eval(local.rowTmpl);
            local.rowTmpl.each(setupOneRow);

            // IMPORTANT: $tableのコンテンツが変更される可能性がある！
            var $tbody = $table.firstChild('tbody').cloneShell();

            pinme = local.pinme;
            if (!pinme) {
                local.pinme = pinme =  (function() {
                    var $thead, $tbody, $pintop, $pinleft, $pincorner, hasRowHeader = false;

                    function syncScroll(e) {
                        wbounds = $wrapper.bounds();
                        var bs = $scroll.bounds(), sl = bs.left - wbounds.left,
                            cb = bs.top - wbounds.top + bs.height - $thead.height() - (bs.height - $scroll[0].clientHeight - 1) - 0;

                        $pintop.css(   {'left': wbounds.left, 'top': bs.top + 1,
                                        'clip': 'rect(auto, ' + (wbounds.width + sl + 1) + 'px, auto, ' + sl + 'px)'});
                        $pinleft.css(  {'left': bs.left, 'top': wbounds.top + $thead.bounds().height ,
                                        'clip': 'rect(' + (bs.top - wbounds.top) + 'px, ' + ($pincorner.content.width() + 4) +'px, ' + cb + 'px, auto)'});
                        $pincorner.css({'left': bs.left, 'top': bs.top});
                    }

                    function watch() {
                        console.log('watch');
                        if (!$pintop
                                || loop($pintop.colhead, $thead, function($r1, $r2) {
                                        if ($r1.bounds().width != $r2.bounds().width) {
                                            return true;
                                        }
                                        return loop($r1, $r2, function($r1, $r2) {return ($r1.bounds().height != $r2.bounds().height);});
                                    })
                                || loop($pinleft.rowhead, $tbody, function($r1, $r2) {return ($r1.bounds().height != $r2.bounds().height);})) {
                            requestFrame(pinme);
                        }
                    }

                    return function() {
                        console.log('pinme');
                        if (!$pintop || !local.$layer) {
                            $thead = $table.firstChild('thead');
                            $tbody = $table.firstChild('tbody');

                            // force to run HTML layout
                            // $tbody.height();

                            $pintop = $wrapper.cloneShell().removeAttr('id').addClass('fixed');
                            $pincorner = $pintop.clone();
                            $pinleft = $pintop.clone();

                            var $colHead = $table.cloneShell().removeAttr('id').appendTo($pintop),
                                $corner  = $colHead.clone().addClass('corner').appendTo($pincorner),
                                $rowHead = $colHead.clone().addClass('row-head').appendTo($pinleft);

                            $colHead.addClass('col-head');

                            $pintop.colhead = $($thead[0].outerHTML).appendTo($colHead);
                            $pinleft.rowhead = $tbody.cloneShell().appendTo($rowHead);

                            $pincorner.content = $pintop.colhead.cloneShell().appendTo($corner);

                            loop($pincorner.content, $pintop.colhead, function($c1, $c2) {
                                var cells = $c2.children(local.fixedCols).clone(), hasRowHeader = cells.length > 0;
                                hasRowHeader && $pincorner.content.append($c2.cloneShell().append(cells));
                            });

                            hasRowHeader && loop($pinleft.rowhead, $tbody, function($c1, $c2) {
                                $c1 = $c2.cloneShell().append($c2.children(local.fixedCols).clone());
                                $pinleft.rowhead.append($c1);
                            });

                            $scroll.on('scroll', syncScroll);

                            var viewport = window.document.body;
                            var $LAYER =  local.$layer = local.$layer || $('<DIV>', {'class': '-FIXED-LAYER-', style: 'position:absolute;'}).appendTo(viewport);

                            $pintop.appendTo($LAYER);

                            if (hasRowHeader) {
                                $pinleft.appendTo($LAYER);
                                $pincorner.appendTo($LAYER);
                            }

    //                      $table.resize(pinme);
    //        				$(window).resize(function() {
    ////        					requestFrame(watch);
    ////        					pinme();
    //        					delayer.call(pinme);
            //
    //        				});
                        }

                        $thead.parent().length || ($thead = $table.firstChild('thead'));
                        $tbody.parent().length || ($tbody = $table.firstChild('tbody'));

                        local.$layer.css('display', 'none');

                        wbounds = $wrapper.bounds();
                        console.log("wrapper", wbounds);
                        loop($thead, $pintop.colhead, matchRow);

                        var bt = $table.bounds(), bh = $thead.bounds();
                        console.log("table", bt);
                        console.log("thead", bh);

                        $pintop.width(Math.max(bt.right - wbounds.left, bh.right - bt.left));
                        $pintop.width(bt.right- bt.left);


                        if (hasRowHeader) {
                            loop($thead, $pincorner.content, matchRow);
                            loop($tbody, $pinleft.rowhead, function($r1, $r2) {
                                // TODO: matching cell width of only heading rows
                                if ($r2[0].sectionRowIndex < local.rowTmpl.length) {
                                    loop($r1, $r2, matchWidth);
                                }
                                $r2.height($r1.bounds().height);
                            });
                        }

                        syncScroll();
                        local.$layer.show();
                    };

                })();
            }

//            local.simple || $(window).resize(watch);
            local.simple || $(window).resize(pinme);

            if (grid && grid instanceof Class) {
                return grid;
            } else {
                function update() {
                    if (!UTILS.isUndefined(local.input)) {
                        if (UTILS.isUndefined(local.arr)) {
                            local.arr = local.adapt(local.input);
                        }
                        if (local.filters) {
                        }
                        if (local.sorter) {
                        }

                        var $old = $table.find('tbody').empty();
                        $tbody = $tbody.cloneShell();
                        local.roller(local.arr, $tbody, UTILS.eval(local.rowTmpl), local.composer, local.indexer);
                        $old.replaceWith($tbody);

                        local.simple || pinme();
//    					local.simple || (pinme(), requestFrame(watch));
                    } else {
                        // clear();
                    }
                };

                function take() {
                    var prop = arguments[0],
                        flags = arguments[1],
                        args = UTILS.slice(arguments, 2),
                        i,
                        v,
                        arglen = args.length;

                    if (arglen === 0) {
                        return local[prop];
                    } else {
                        if (flags) {
                            if (!flags.simple) {
                                for (i = 0; i < arglen; i++) {
                                    v = args[i];
                                    if (!UTILS.isUndefined(v)) {
                                        if ($.isArray(v)) {
                                            v.forEach(function(each) {
                                                $.isFunction(each) || $.error(prop + ' must be Function(s): ', prop);
                                            });
                                        } else {
                                            $.isFunction(v) || $.error(prop + ' must be Function(s): ', prop);
                                        }
                                    }
                                }
                            }
                            if (!flags.multi) {
                                v = arglen === 1 ? args[0] : UTILS.slice(args);
                            } else {
                                if (args.length > 0) {
                                    args = $.map(args, function(v) {return v;});
                                }
                                v = args;
                            }
                        }
                        if (v === null || UTILS.isUndefined(v)) {
                            delete local[prop];
                        } else {
                            local[prop] = v;
                        }

                        delayer.call(update);
                        return this;
                    }
                };

                var apis = {
                        _local: function() { return local;},
                        clearFixed: function() {
                            if (local.$layer) {
                                local.$layer.remove();
                                delete local.$layer;
                            }
                        },
                        getTable: function() {
                            return $table;
                        },
                        input:
                            function() {
                                $tbody.empty();
                                arguments.length > 0 && delete local.arr;
                                return take.bind(this, 'input', {simple: true}).apply(this, arguments);
                            },
                        roll:     		take.bind(this, 'roller', {}),
                        adapt:    		take.bind(this, 'adaptor', {}),
                        compose:  		take.bind(this, 'composer', {multi: true}),
                        compare:  		take.bind(this, 'comparators', {multi: true}),
                        sort:     		take.bind(this, 'sorter', {}),
                        filtrate: 		take.bind(this, 'filters', {multi: true}),
                        row:      	  	take.bind(this, 'rowTmpl', {simple: true}),
                        tbody:    	  	take.bind(this, 'tbody', {simple: true}),
                        select: 	  	function(/** selection... */) {},
                        getSelection: 	function() {},
                        show: 			function() {
                                            delayer.cancel();
                                            update();
                                            return this;
                                        }
                };

                $.extend(this, apis);
                $table.data(RYN_GRID, this);
                return this;
            }
        } else {
            $.error('not a table');
        }
    };

    // public methods
    var methods = {
          setup: function (options) {
            settings = $.extend({}, DEFAULTS, options);
            return this;
          },

          COMPOSER: COMPOSER
    };

    var _private = {
    };

    return $.extend(Class, methods);
});