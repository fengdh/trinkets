/**
 * ryn.remote.js
 *    - A lightweight JavaScript RMI client module based on JSON.
 *    - ryn.remote.js depends on jQuery and RequireJS library, which is also a AMD module.
 *    - ryn.remote.js communicates with server via HTTP connection, supporting sync/async and multiplex invocation.
 *    - Spring Framework container must be configured with server side functions for ryn.remote.js:
 *         - A ServicePublisher bean publishing specification of serviceable interface and bridging remote call to target bean.
 *         - Each published service consisting of a pair of interface and its implementation which needs to be exposed as a bean.
 *
 * RYN(凜) is named after my pretty daughter.
 *
 * @author Feng Dihai<fengdh@gmail.com>
 * @version 0.0.1 preview
 * @since  2013/12/20
 */
define(['jquery', 'ryn/utils', 'ryn/ui.notify'], function($, UTILS, NC) {
    // ------------------------------------------------------
    // internal variables and functions
    // ------------------------------------------------------

    // constant, return result type identification
    var RYN_REMOTE_RESULT = 'ryn.remote.result';

    // internal session object, only one valid instance being opened, otherwise undefined (init/closed)
    var session;

    // ------------------------------------------------------
    // default options, configurable by merging Ryn.Remote.options
    var defaults = $.extend({ toSpecUrl: function(ids) { return 'api/' + ids + '/spec';},
                              invokeUrl: '../remoting/ryn/invoke/',
                              downloadUrl: '../remoting/ryn/download/',
                              downloadTimeout: 1200 /* = 500ms * 1200 = 600s = 10m */ },
                            this.Ryn && Ryn.Remote && Ryn.Remote.options);

    // default settings for $.ajax(), overridable through session/module options
    var AJAX_SETTINGS = {
            'async': false,
               type: 'POST',
              toUrl: require.toUrl,
           dataType: 'json'};

    /**
     * RemoteError stands for error occurred during calling or returned by remote service
     *
     * @param subject object which issued remote service call, also a jQuery Deferred object
     * @param cause a plain object standing for a Java exception returned by remote service
     * @param err an optional Error object providing calling stack
     */
    function RemoteError(subject, cause, err) {
        $.extend(this, {
            subject: subject,
            cause:   cause,
            stack:   err && err.stack,
            message: 'Failed on calling remote service ### ' + subject.target + '#' + subject.method.name + '(..)'});
    }

    RemoteError.prototype = new Error();
    RemoteError.prototype.constructor = RemoteError;
    RemoteError.prototype.name = 'RemoteError';

    /**
     * Void stands for void return value returned by remote service.
     */
    function Void() {}

    function stringify(obj) {
        return JSON.stringify(obj).replace(/%/g, '%25');
    }

    /**
     * Remote service proxy constructor.
     *
     * ryn.remote.js#call([serviceNames], callback = function(serviceProxy, ..) {..}, errback) will pass proxy object(s) of
     * resolved remote service(s) to callback function.
     *  - In callback function, you can just call available methods with proper arguments.
     *  - Single synchronized remote call(default) will block following process until result or RemoteError being returned/thrown out.
     *  - Asynchronized remote call(uniform/multiplex) is non-blocking and will return promise object immediately.
     *  - Promise can inform result value or RemoteError returned/thrown by async remote call via callback functions.
     *  - Promise can be treated indepently as OR-relationship.
     *  - $.when(promises, callback, errback) can be used to bind multiple promises as AND-relationship.
     *  - Explicitly openning a new session can issue multiple remote calls in async mode.
     *
     * @param spec API specification of a remote service returned by ServicePublisher,
     *             including all serviceable methods(name, params and return value)
     */
    function createProxy(spec) {
        // internal variable holding its own settings for $.ajax(), overridable through Proxy#$(options) method
        var settings = $.extend({}, AJAX_SETTINGS),
            /**
             * The constructed remote service proxy object is also a setup function which overrides settings applied to $.ajax().
             * Calling without arguments equals to #setup({async:true}).
             *
             * @param options will be combined with default settings when applied to $.ajax()
             * @return this remote service proxy object (also a setup function)
             */
            proxy = function setup(options) {
                $.extend(settings, UTILS.isUndefined(options) ? {'async': true} : options);
                settings._meta_ = options;
                return proxy;
            };

        if (spec.methods && spec.methods.length) {
            function makeInvoc(method) {
                return proxy[method.name] = function() {
                    return _private.issue(spec.name, method, UTILS.slice(arguments), settings);
                };
            }
            spec.methods.map(makeInvoc, this);
        }

        // Add #setup() to proxy object if the remote service has no method named "setup" for compatibility reason.
        proxy.setup = proxy.setup ||  proxy;
        return proxy;
    }
  
    /**
     * Session enables multiple remote calls through a single HTTP connection that can improve user experience dramatically.
     *    - There is at last one session per work thread that is the main UI thread most time.
     *    - #module.Session.open(options) call #module.Session.close() at first, and starts a new session.
     *      After then following remote calls will join the session, return a promise object immediately and defer its result.
     *    - #module.Session.close() will close the opened session if one exists, also request server to execute bound
     *      remote calls through a single HTTP connection.
     *    - The opened session not closed yet will be closed implicitly when current thread is idle to execute timeout code.
     *    - Result/exception being returned/thrown by remote service can be informed to its "promise" in asynchronized way.
     *
     * Note: Session() constructor is for interna use, while #module.Session is a open namespace to provide access to session.
     *
     * @param options shared settings applied to $.ajax() when issuing multiple remote call through a single HTTP connection.
     */
    function Session(options) {
        // local variables
        var delayer = UTILS.delayer(), arr = [], settings = $.extend({}, AJAX_SETTINGS, options);

        // local functions: resolve multiple remote calls with its returned value
        function resolveValues(values) {
            for (var i = 0; i < arr.length; i++) {
                _private.resolve(values[i], arr[i], true);
            }
        };

        $.extend(this, {
            // append data of a remote call (including target service/method/arguments)
            append: function(data) { arr.push(data); },
            // close session and request server to execute bound remote calls
            close: function() {
                       if (session && arr && arr.length > 0) {
                        var result = _private.query(settings, arr);
                        settings.async ? result.done(resolveValues) : resolveValues(result);
                        UTILS.debug("\t\t\t\t ------ [session closed]");
                    }
                    session = undefined;
                },
            // update idle timer to close session implicitly
            update: function() { delayer.call(this.close); }
        });
    }

    // private functions
    var _private = {
            /**
             * Convert service id(s) to url to retrieve remote service specification.
             *
             * @param list array of service ids or a single sevice id string
             * @return url to retrieve remote service specification.
             *         - Multiple ids are combined with '+'.
             *         - '/' seperator is replaced with '|' to avoid conflicting with url path.
             *         - Assign Ryn.Remote.options.toSpecUrl to a function to configure url conversion.
             */
            assembleSpecUrl:
                function (list) {
                        if (list) {
                            if (!$.isArray(list)) {
                                list = [list];
                            }
                            return [defaults.toSpecUrl(list.join('+').replace('/', '|'))];
                        }
                    },

            /**
             * Issue a remote call, internal implementation.
             *   - If there is an opened session, then join it.
             *   - Or request server to excute the remote call (sync/async).
             *
             * @param srvName full name of remote service
             * @param method target method to invocate
             * @param args arguments to be passed
             * @param settings applied to $.ajax()
             *
             * @return For synchronized single remote call, return the resolved result.
             *         Otherwise deferred resolved result as a promise.
             * @throws RemoteError will be thrown out when caught a exception from remote service.
             */
           issue:
                function (srvName, method, args, settings) {
                        settings = $.extend({}, settings);

                        var data = $.extend($.Deferred(), {target: srvName, method: method, args: args, getSettings: function() {return settings;}});
                        if (method.output) {
                            return _private.download(settings, data, method.output);
                        }

                        function go() {
                            UTILS.debug('Try remote call: \r\n\t' + srvName + '#' + method.name + '(' + args + ')');
                            var result = _private.query(settings, [data], {srvName: srvName, method: method});
                            if (settings && settings.async) {
                                result.done(function(value) {
                                    _private.resolve(value[0], data, true);
                                });
                                return data.promise();
                            } else {
                                return _private.resolve(result[0], data);
                            }
                        };

                        function join() {
                            session.append(data);
                            session.update();
                            return data.promise();
                        };

                        return session ? join() : go();
                    },
            /**
             * Request remote service to execute single/multiple remote calls.
             *
             * Note: Server side will always return remote call result in a array which needs to be resolved.
             *
             * @param settings will be applied to $.ajax()
             * @param data consists of remote call data including service/method name and arguments
             *
             * @return For synchronized single remote call, return the raw result.
             *         Otherwise deferred raw result as a promise.
             * @throws RemoteError will be thrown out when caught a exception from remote service.
             */
            query:
                function(settings, data) {
                    UTILS.debug('settings: ', settings);
                    var req = $.extend({}, settings, {data: stringify(data)});
                    settings.toUrl && (req.url = UTILS.eval(settings.toUrl, defaults.invokeUrl));
                    var result = jqxhr = $.ajax(req).fail(function() { NC.neterr(req.url); });
                    if (!settings.async) {
                        jqxhr.done(function(value) {
                            result = value;
                        });
                    } else {
                    }
                    return result;
                },
            /**
             * Request a (allowing only one) remote method to start downloading a server output file.
             * It will create an invisible temporary IFRAME, fill a form with argument(s)
             * and meta data then submit it to avoid overriding the current page.
             * No returned value, no synchronous or batch call.
             */
            download: function(settings, data, output) {
                    var willStartDownload = $.Deferred(), cnt = 0,
                        token = 'ryn.download.' + UTILS.randomstr(),
                        method = data.method,
                        meta = $.extend({}, settings._meta_, {"\token": token}),
                        $iframe = $('<iframe>').hide().appendTo(document.body),
                        doc = $iframe[0].contentWindow.document,
                        cookiecan = UTILS.cookiecan(doc),
                        url = defaults.downloadUrl,
                        $form = $('<form>', {'method': 'post', 'action': UTILS.eval(settings.toUrl, url), 'target': '_self'});

                    doc.write('<html><body>download page</body></html>');
                    $form.append($('<input>', {name: 'payload', value: stringify(data)}));
                    $form.append($('<input>', {name: 'meta',    value: stringify(meta)}));
                    $form.appendTo(doc.body).submit();

                    // remove iframe after server responding with specified cookie (path="/")
                    var checkcookie = window.setInterval(function() {
                        var timeout = cnt++ > settings.downloadTimeout;
                        if (timeout || cookiecan.has(token)) {
                            cookiecan.remove(token, "/");
                            window.clearInterval(checkcookie);
                            $iframe.remove();
                            willStartDownload[timeout ? 'reject' : 'resolve'](token);
                        }
                    }, 500);

                    return willStartDownload;
                },

            /**
             * Resolve returned raw result (Array object) to each remote call.
             *
             * @param result raw result (Array object) by remote service
             * @param deferred $.Deferred object representing a remote call
             * @param async flag to indicate whether to resolve deferred result in async mode
             *
             * @return For synchronized single remote call, return the resolved result.
             *         Otherwise a promise which will be informed with the resolved result.
             * @throws RemoteError will be thrown out when caught a exception from remote service.
             */
            resolve:
                function(result, deferred, isAsync) {
                    function _doPost(NC, message, more, context) {
                        NC.post(message, more, context);
                    }

                    function post(message) {
                        var context = deferred.getSettings(), more = this != window ? this : null;
                        if ($.isFunction(context.messageFilter)) {
                            if (!context.messageFilter(NC, message, more, context)) {
                                return;
                            }
                        }
                        _doPost(NC, message, more, context);
                    }

                    if ($.isPlainObject(result) && result.hasOwnProperty(RYN_REMOTE_RESULT)) {
                        switch (result[RYN_REMOTE_RESULT]) {
                            case 1: // remote exception
                                if (result.options) {
                                    result.options.forEach(post, result.value ? [result.value.origin, result.value.message] : undefined);
                                } else {
                                    // TODO: remote error without message
                                }

                                result = new RemoteError(deferred, result.value, new Error);
                                break;

                            case -1:	// remote void value
                                result.options && result.options.forEach(post);
                                result = deferred.promise(new Void());
                                break;

                            default:	// normal
                                result.options && result.options.forEach(post);
                                result = result.value;
                                break;
                        }
                    }

                    if (result instanceof RemoteError) {
                        if (isAsync) {
                            deferred.reject(result);
                        } else {
                            throw result;
                        }
                    } else {
                        deferred.done(function(value) {result = value;})
                                .resolve(result);
                    }
                    if (!isAsync) {
                        result = result !== 'object' && new Object(result);
                        result = deferred.promise(result);
                    }

                    return result;
                }
    };


    // public method & namespace
    var module = {
        /**
         * Require remote service (as a single string or array of service id) and execute callback.
         * #module.call(..) simulates require(deps, callback, errback) API, but including process to
         * resolve remote service and assemble remote service proxy.
         *
         * NOTE:
         * - Proxy object to remote service is passed to callback function when resolved,
         *   which itself is also a "setup" function being able to modify how to call remote service.
         * - Inside callback/errback function, "this" points to this ryn.remote.js module.
         *
         * <code>
         * Usage:
         *    Spring Framework Configuration
         *    ------------------------------
         *    [1] Mappping org.springframework.web.servlet.DispatcherServlet to url "/remoting/*"
         *    [2] ServicePublisher providing service at
         *          - /remoting/ryn/api/{query}/spec.js  => query speccification of remote service
         *          - /remoting/ryn/invoke/              => execute remote call
         *          - /remoting/ryn/download/{filetype}  => download a server output file
         *    [3] Beans defined:
         *          - org.springframework.web.servlet.view.ContentNegotiatingViewResolver
         *          - jp.co.bbs.ryn.remote.JsModuleDefineView (name="ryn:jsModuleDefineView")
         *          - jp.co.bbs.ryn.remote.ServiceMappings: declare default package and map path to packages
         *          - beans with type of {*.*.IFacetService, *.*.IZipService}
         *
         *    web content folder
         *    -------------------
         *       {webroot}/
         *          +--- css/
         *          +--- index.html
         *          +--- sample.html
         *          +--- js/
         *                 +--- app/
         *                 |      +--- remote.sample.js
         *                 |
         *                 +--- ryn/
         *                 |      +--- ryn.remote.js
         *                 |      +--- ryn.ui.js
         *                 |      +--- ryn.util.js
         *                 |
         *                 +--- jquery-2.0.3.js
         *                 +--- require.js
         *
         *    conf.js
         *    -------
         *    var require = {
         *          baseUrl: 'js',
         *
         *          paths: { 'app'         : '../js/app',
         *                   'ryn'         : '../js/ryn',
         *                   'api'         : '../remoting/ryn/api',
         *                   'jquery'      : 'jquery-2.0.3'},
         *
         *          map: {'*' : {
         *                   'ryn/util'    : 'ryn/ryn.utils',
         *                   'ryn/remote'  : 'ryn/ryn.remote',
         *                   'ryn/ui'      : 'ryn/ryn.ui',
         *                   'ryn/ui.grid' : 'ryn/ryn.ui.grid'
         *                }}
         *    };
         *
         *    var Ryn = {
         *         Remote: {
         *             options: {
         *                     toSpecUrl: function(ids) { return 'api/' + ids + '/spec';}
         *             }
         *         }
         *    };
         *
         *    remote.sample.js
         *    ----------------
         *    require(['jquery', 'ryn/remote'], function($, Remote) {
         *        ...
         *        Remote.use(['IFacetService', 'prototype/IZipService'], function(facet, zip) {
         *           var result;
         *           　　　
         *           console.log('# synchronized remote call');
         *           result = facet.auth(uid, pwd);
         *           console.log('auth: ', result);
         *
         *           result = zip.lookup('179-0072');
         *           console.log('lookup zip:', result);
         *
         *           try {
         *               zip.bad();
         *           } catch (e) {
         *               console.log('RemoteError', e);
         *           }
         *
         *           　　　      console.log('# asynchronized remote call');
         *           zip({async:true}).lookup('1790072')
         *              .done(function(value) {
         *                  console.log('lookup zip(deferred):', value);
         *              });
         *
         *           zip.bad()
         *              .fail(function(e) {
         *                  console.log('RemoteError(deferred)', e);
         *              });
         *
         *           　　　      console.log('# batch remote call');
         *           Remote.Session.open();
         *
         *           var p1 = zip.lookup('1790072'),
         *               p2 = zip.bad(),
         *               p3 = zip.listAll();
         *
         *           p3.done(function(value) {
         *               console('list all zips(deferred, OR-relationship):', value);
         *           });
         *
         *           $.when(p1, p2, p3)
         *            .done(function(r1, r2, r3) {
         *                 console.log('deferred result[1]:', r1);
         *                 console.log('deferred result[2]:', r2);
         *                 console.log('deferred result[3]:', r3);
         *            })
         *            .fail(function(e) {
         *                 console.log('batch remote call failed(AND-relationship):', e);
         *            });
         *
         *        });
         *        ...
         *    };
         *
         * </code>
         * <p>
         * If a remote call (allowing only ONE and always ASYNCHRONOUS) to a method annotated as @Output(<I>some_file_type</I>)
         * will start to download a server output file. Here we can use the proxy object to download service as a "setup" function
         * to pass meta data to server, such as {saveas: "file_name"}.
         *
         * @param ids a single string or array of service id
         * @param callback define process to call remote service, remote service proxy object will be passed as its arguments
         * @param errback define error callback when failed, a single RequireJS error object will be passed as its argument.
         */
        use:
            function(ids, callback, errback) {
                var willDone = $.Deferred();

                function whenErr(err) {
                    if (errback) {
                        errback.apply(module, arguments);
                    } else {
                        var failedId = err.requireModules && err.requireModules[0];
                        NC.neterr(failedId);
                        UTILS.debug("Failed to load module: ", failedId);
                        if (failedId) {
                            requirejs.undef(failedId);
                        }
                    }
                    willDone.reject();
                }

                require(_private.assembleSpecUrl(ids),
                        function() {
                            // BE CAREFUL: change args element will also change cached module in RequireJS registry.
                            var arr = UTILS.slice(arguments)[0], args = [];
                            if (arr) {
                                for (var idx in arr) {
                                    args[idx] = createProxy(arr[idx]);
                                }
                                var ret = callback.apply(module, args);
                                willDone.resolve(ret);
                            } else {
                                // IE9 only: arr is undefined when server error occuring
                                whenErr({requireModules: [ids]});
                            }
                        },
                        whenErr);

                return willDone;
            },


        /**
         * #module.Session namespace
         */
        Session: {
            /**
             * Open a new session which can bind multiple remote call through a single HTTP connection.
             * If there exists a opened session, it will be closed first automatically.
             * There is no more than one session can be opened per worker thread which is main UI thread at most time.
             *
             * @param options shared settings applied to $.ajax() when issuing multiple remote call through a single HTTP connection.
             */
            open:
                function(options) {
                    session ? session.close() : session = new Session(options);
                },
            /**
             * Close an opened session if existed.
             */
            close:
                function() {
                    session && session.close();
                    delete session;
                }
        },

        /**
         * Remote Error type
         */
        Error: RemoteError,

        /**
         * Remote void return value type
         */
        Void: Void,
    };

    return module;
});

