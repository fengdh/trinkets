/**
 * ryn.app.js
 * - Pre-load & application's resources
 */
define(['jquery'], function($) {
    var settings = {
            debug: null, // function(type, obj) {}
    };

    // pre-load and cache resources
    function collect(args /* url_of_manifest or [urls of resources] */) {
        var total = 0, resolved = 0, deferred = $.Deferred(), resources = [];

        // parse offline application manifest file
        function parse(m) {
            var arr = m.split(/[\r\n]+/g);
            if (arr.length < 2 || arr[0].toUpperCase() !== 'CACHE MANIFEST') {
                return deferred.resolve(args, total);
            }
            var valid = true;
            arr.slice(1).forEach(function(t) {
                t = t.trim();
                var u = t.toUpperCase();
                (u === 'FALLBACK:' || u === 'NETWORK:') && (valid = false);
                if (u === 'CACHE:')  {
                    return valid = true;
                }
                (valid && t.length > 0 && t.charAt(0) !== '#')  && resources.push(t);
            });
            doCache(resources);
        }

        function doCache(args) {
            deferred.notify(total += args.length, 0);
            args.forEach(function loadAsText(v) {
                require([ 'text!' + v ], function(content) {
                    if (deferred.state !== 'rejected') {
                        deferred.notify(total, ++resolved, v);
                        (total === resolved) && deferred.resolve(args, total);
                    }
                    }, function(err) {
                        deferred.notify(total, -1, v);
                        deferred.reject(v, err);
                    });
                });
        }

        settings.debug && settings.debug('cache', deferred);
        ($.isArray(args)) ? doCache(args) : $.get(args).done(parse);
        return deferred.promise({target: args, resources: resources});
    }

    var jobs = [],
        module = {
            /**
             * Run $(callback) after all cache jobs finished, or errback when any cache job failed.
             *
             * @param callback
             * @param errback
             * @return a combined deferred object represents all cache jobs.
             */
            $ : function(callback, errback) {
                var willExec = $.when.apply(null, jobs).done(function() {$(callback);});
                $.isFunction(errback) && willExec.fail(errback);
                return willExec;
            },

            /**
             * Cache resources.
             *
             * @param args a url of an offline application manifest, or array containing urls of resources to be cached.
             * @return a single resource cache job, which has promise API to report progress.
             *         cache progress will be notified with arguements of (total, resolved, resource):
             *           - total resources of job
             *           - resolved as so far, 0 = about to cache, -1 = failed
             *           - resource currently being cached
             */
            cache: function(args) {
                var p = collect(args);
                jobs.push(p);
                return p;
            },

            /**
             * Register each deferred cache job with a progress notification handler.
             * @param callback
             * @return ryn.app.js module itself
             */
            progress: function(callback) {
                jobs.forEach(function(each) { each.progress(callback);});
                return module;
            },

            /**
             * @return all resource cache jobs as so far.
             */
            all: function() { return jobs; },

            /**
             * Setup ryn.app.js module.
             *
             * @param options {..}
             * 			debug: function(type, obj) {..}  - configurate debug handler
             * @return combined settings
             */
            setup: function(options) { return $.extend(settings, options);}
        };

    return module;
});