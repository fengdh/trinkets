/**
 * ryn.ui.jqm.js
 */
define(['jquery', 'ryn/utils'], function($, UTILS) {
    var module = {

        autoComplete: function($input, $list, options) {
            var
            delayer = UTILS.delayer(),
            init,
            settings = {
                fill: function($ul, data) {
                    if ($.isArray(data)) {
                        var i, buf = UTILS.buffer('<li>', '</li>');
                        for (i = 0; i < data.length; i++) {
                            buf.add(data[i]);
                        }
                        $ul.empty().html(buf.join());
                    }
                },

                css: { //'position': 'absolute',
                    'overflow-y': 'auto',
                    'width': '300px',
                    'max-height': '240px'},

                'match-start-first': true
                };

            $.extend(settings, options);

            function create(data) {
                settings.fill($list, UTILS.eval(data));
                $list.filterable('refresh');
            }

            $list.one('filterablebeforefilter', function() {
                if (settings.async && $.isFunction(settings.data)) {
                    UTILS.eval(settings.data, create);
                } else {
                    create(settings.data);
                }

                // TODO:
                //    keys: up/down/right/pgUp/pgDn/Home/End/Enter
                //    multiple keywords: and/or filters
                //    multi-layer data
                $input.on('keydown', function(e) {
                    $list.show();

                    var items = $list.find('li:visible'),
                    item = items.filter('li.ui-hilight'),
                    current = item.length > 0 ? items.index(item) : -1;
                    item.removeClass('ui-hilight');

                    switch (e.which) {
                        case 38: current--; break;
                        case 40: current++; break;
                        default: return;
                    }
                    if (current < 0) current = 0;
                    if (current >= items.length) current = items.length - 1;
                    item = $(items[current]);
                    if (item.length > 0) {
                        item.addClass('ui-hilight');
                        console.log(current, item);
                        $list.filterable('disable');
                        $input.val(item.text());

                        item[0].scrollIntoView(false);
                        delayer.call(function(){
                            $list.filterable('enable');
                        }, 250);
                    }
                });

                $list.css(UTILS.eval(settings.css));

                var hide = settings.hide;
                if (hide) {
                    if ($.isFunction(hide)) {
                        hide($list);
                    } else {
                        settings.container.on(hide, function() { $list.hide();});
                    }
                }
            });

        }

    };

    return module;
});