define(['jquery', 'jquery.notyfy'], function($, Notyfy) {

    // Configurate and enhance jquery.notyfy
    $.extend($.notyfy.defaults, {
        maxVisible: -1,

        template: '<div class="notyfy_message"><span class="notyfy_text"></span><div class="notyfy_close"></div></div>',

        events: {
            shown:
                function() {
                    var noty = $.notyfy.get($(this).find('.notyfy_bar').attr('id'));

                    $(this).find('.notyfy-more').one('click', function(e) {
                        var $this = $(this);
                        $this.fadeToggle().finish().html($this.attr('value')).removeAttr('value').fadeToggle();
                        e.stopPropagation();
                    }).end()
                    .find('.notyfy-link').on('click', function(e) {
                        try {
                            noty['#context'].focus();
                        } catch (e) {}
                        e.stopPropagation();
                    });
                    if (noty.options && noty.options.modal) {
                        noty.container.addClass('ryn-modal');
                        $.notyfy.layouts[noty.options.layout] && $.notyfy.layouts[noty.options.layout].apply($(this).parent());
                    }
                },
            hidden :
                function() {
                    var noty = $.notyfy.get($(this).find('.notyfy_bar').attr('id'));
                    if (noty.options && noty.options.modal) {
                        $.notyfy.layouts[noty.options.layout] && $.notyfy.layouts[noty.options.layout].apply($(this).parent());
                    }
                    noty.resolve && noty.resolve('hidden');
                }
            }
    });

    function enhance(notyfy) {
        var repo = {};
        return $.extend(notyfy, {
            after: function(type) {
                return (repo[type] || (repo[type] = $.Deferred())).promise(this);
            },
            resolve: function (type, trigger) {
                repo[type] && repo[type].resolveWith(this, trigger);
                return this;
            }
        });
    }

    $(document).on('click', '.notyfy_container', function(e) {
        var $c = $(e.target);
        if ($c.has('.notyfy_container')) {
            $c.removeClass('closeall');
            $c.find('.notyfy_bar').each(function() { $.notyfy.close(this.id); });
        }
    }).on('mouseenter', '.notyfy_container', function(e) {
        var $c = $(e.target).closest('.notyfy_container');
        $c.children().length > 1 ? $c.addClass('closeall') : $c.removeClass('closeall');
    });

    var oldInit = $.notyfyRenderer.init;
    $.extend($.notyfyRenderer, {
        hideModalFor: function(notyfy) {
            this.setModalCount(-1);
            if(this.getModalCount() == 0) {
                if ($.fx.off) {
                    $('#notyfy_container_' + notyfy.options.layout + '.ryn-modal').detach();
                    this._modal.detach();
                } else {
                    var modal = this._modal.fadeOut('fast', function() {
                        // detach empty modal notyfy container
                        $('#notyfy_container_' + notyfy.options.layout + '.ryn-modal').detach();
//                        modal.detach();
                    });
                }
            }
        },
        init: function(options) {
            return enhance(oldInit.call(this, options));
        }
    });

    var TYPES = {
            'I': 'information',	// auto-dismissable
            'W': 'warning',		// auto-dismissable
            'Q': 'confirm',
            'E': 'error',
            'C': 'confirm',
            'P': 'alert',
            'F': 'error',
            'U': 'alert',
            'S': 'alert',	// stable, not auto-dismissable
            'R': 'information',	// Ratio/Percentage/Progress
            ' ': 'information'
    };

    function doPost(message, more, options, noti) {
        var id = message.id || '', text = message.text || '', type = id.substr(0, 1), context = options && options.context;
        noti = $.extend({layout: 'topRight', type: TYPES[type],}, noti);
        id !== type || (id = '');

        if (more) {
            text += $('<span>', {'class': 'notyfy-more', value: Ryn.Notify.assembleMore(more, options), text: '詳細表示'})[0].outerHTML;
        }

        if (type === 'R') {
            text += '<div class="notyfy-ratio"><span class="notyfy-bar"></span></div>';
        }

        if (context) {
            text += $('<span>', {'class': 'notyfy-link', value: '', title: '原因箇所: ', text: context.title})
                    .data('#owner', context.item)[0].outerHTML;
        }
        text = '<span class="notyfy-msg">' + text + '</span>';
        if (type != '' && id.length > 1 || !noti.modal) {
            text = '<span class="notyfy-msgid">' + id + '</span> ' + text;
        }

        noti.text = text;
        if (!noti.modal || type === 'C' || type === 'Q') {
            switch (type) {
                case 'I': noti.timeout = 5000; break;
                case 'W': noti.timeout = 8000; break;
                case 'C':
                case 'Q':
                    noti.buttons = noti.buttons || [{
                            addClass: 'btn btn-primary',
                            text: 'Ok',
                            onClick: function(notyfy) {
                                notyfy.resolve('hidden', this).close();
                            }
                          }, {
                            addClass: 'btn btn-danger',
                            text: 'Cancel',
                            onClick: function(notyfy) {
                                notyfy.resolve('hidden', this).close();
                            }
                          }];
                    break;
                case '': noti.timeout = noti.modal ? 8000 : 5000; break;
            }
        }
        noti = notyfy(noti);

        context && (noti['#context'] = context.item);
        return noti;
    }

    function config(message, conf, modal) {
        var id = message.id || '', type = id.substr(0, 1);

        switch (type) {
            case 'F':
            case 'C':
            case 'Q':
            case 'P':
                modal = true;
                break;

        }
        if (modal) {
            conf = $.extend({}, conf, {
                force: true,
                dismissQueue: true,
                showEffect:  function(bar) { $('#notyfy_modal').hide().finish().show(); bar.fadeIn('fast').finish(); },
                hideEffect:  function(bar) { bar.fadeOut('fast').finish(); },
                layout: 'center', modal: true});
        } else {
            if (!type) {
                message.id = '';
            }
        }
        return conf;
    }

    function configAsDebug(message, conf, modal) {
        return $.extend({layout: 'bottom'}, config(message, conf, false));
    }

    function produce(message, more, context, options, modal, config) {
        if (typeof message === 'string') {
            if (typeof more === 'string') {
                message = {id: message, text: more};
                more = undefined;
            } else {
                message = {text: message};
            }
        }

        return doPost(message, more, context, config(message, options, modal));
    }

    var module = {
            /**
             * Post a message to be shown as modal or modal-less according to its type.
             *
             * post("msgtext")
             * post("msgid", "msgtext")
             * post(messgae = {id, text}, more = [], context = {title, item}, notyfy_options = {...})
             *
             * @param message
             * @param more
             * @param context
             * @param options
             * @returns NotyfyObject
             */
            post: function(message, more, context, options) {
                return produce(message, more, context, options, false, config);
            },

            /**
             * Show a modal message explicitly.
             *
             * @param message
             * @param more
             * @param context
             * @param options
             * @returns Notyfy object
             */
            shout: function(message, more, context, options) {
                return produce(message, more, context, options, true, config);
            },
            debug: function(message, more) {
                var noti = produce(message, more, {}, {}, false, configAsDebug);
                if (noti.wrapper && noti.wrapper.is(':visible')) {
                    noti.wrapper[0].scrollIntoView();
                }
                return noti;
            },

            /**
             * Create a progressbar object:
             * 	- #show(..): same api as #post()/shout() to show progress message
             *  - #show(..) will return a promise object also with abilities of resolve/reject/notify, which can be used
             *    to display done/fail/progress message if registered with handler or desired message.
             *
             * @param calcRatio Function used to calculate ratio(percentage),
             * 				    must return a function returning [value, label].
             * @returns progressbar object
             */
            progressbar: function (calcRatio) {
                return { show: function show() {
                    var noty = module.post.apply(null, arguments),
                        $ratio = noty.message.find('.notyfy-ratio'),
                        $bar = $ratio.children().first(),
                        deferred = $.Deferred(),
                        ret = deferred.then(whenDone.bind(ret, undefined), null, calcRatio && calcRatio());

                    function whenDone(msg) {
                        $bar.finish();
                        msg && ($ratio[0].previousSibling.nodeValue = msg);
                        setTimeout(noty.close, 5000);
                    }

                    function whenFail(msg) {
                        $bar.finish();
                        noty.close();
                        module.post.apply(null, msg);
                    }

                    ret = ret.progress(function(arg) {
                                $bar.finish().animate({'width': arg[0]}, 200, function() { $bar.text(arg[1]); });
                            });

                    ['resolve', 'reject', 'notify'].forEach(function(v) { ret[v] = deferred[v].bind(deferred); });
                    var _done = ret.done, _fail = ret.fail;
                    ret.done = function(arg) { return _done.apply(this, $.isFunction(arg) ? arg : [whenDone.bind(this, arg)]); };
                    ret.fail = function(arg) { return _fail.apply(this, $.isFunction(arg) ? arg : [whenFail.bind(this, arguments)]); };
                    ret.noty = noty;

                    return ret;
                }};
            },

            neterr: function(resource) {
                this.shout({id: 'F', text: "Network error: " + resource});
            }
    };

    Ryn.Notify.neterr && (module.neterr = Ryn.Notify.neterr);
    return module;

});