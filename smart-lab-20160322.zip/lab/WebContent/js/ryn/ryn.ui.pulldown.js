/**
 * ryn.ui.pulldown.js
 */
define(['jquery'], function($) {

    $.fn.puller = function(opt) {
        var OPENED_FLAG = false;
        opt = $.extend({
            cursor: 's-resize',
            cancelable: true,
            caption: 'Release to select.',
            cancelCaption: 'Cancel',
            matchSelected: function($list, $handler) {
                var txt = $handler.text();
                $list.each(function() {
                    var $li = $(this);
                    if (txt == $li.text()) {
                        $li.addClass(CLS.SELECTED);
                        return false;
                    }
                });
            },
        }, opt);

        var /* CONST */
            EMPTY = $([]),
            SAVED_POS = 'ryn.puller/saved.pos',
            CLS = { CONTENT:  'pull-content',
                    LIST:     'pull-list',
                    CAPTION:  'pull-caption',
                    HANDLER:  'pull-handler',
                    EXPANDED: 'pull-expanded',
                    SELECTED: 'pull-selected'};

        var $elements = this;



        if ($.isFunction(opt.init)) {
            $elements.each(opt.init);
        }

        function create() {
            var $e = $(this),
                $content = $e.find('.' + CLS.CONTENT),
                $caption = $e.find('.' + CLS.CAPTION),
                $ul      = $e.find('.' + CLS.LIST),
                $handler = $e.find('.' + CLS.HANDLER);
            if ($content.length === 0) {
                $content = $('<div>', {'class': CLS.CONTENT}).prependTo($e);
            }
            if ($caption.length === 0) {
                $caption = $('<div>', {'class': CLS.CAPTION}).prependTo($content);
            }
            if ($ul.length === 0) {
                $ul = $('<ul>', {'class': CLS.LIST}).prependTo($e);
            }

        }

        $elements.each(create);


        function adapt(e) {
            var oe = e.originalEvent;
            if (window.TouchEvent) {
                if (oe instanceof TouchEvent) {
                    e.touched = true;
                    var touch = oe.changedTouches[0];
                    e.pageX = touch.pageX;
                    e.pageY = touch.pageY;
                    e.target = oe.changedTouches[oe.changedTouches.length-1].target;
                }
            }
        }

        /**
         * Expand pulldown list when start to being pulled down or click/tap at "dropdown" icon.
         */
        function expand(e) {
            if (OPENED_FLAG) {
                e.preventDefault();
                return;
            }
            OPENED_FLAG = true;

            adapt(e);
            var $selected = EMPTY,
                $puller  = $(this),
                $content = $puller.find('.' + CLS.CONTENT),
                $caption = $puller.find('.' + CLS.CAPTION),
                $ul      = $puller.find('.' + CLS.LIST),
                $handler = $puller.find('.' + CLS.HANDLER),
                $list    = $ul.children(),
                expanded = $puller.hasClass(CLS.EXPANDED),
                marginTop= $.css(this, 'margin-top', true),
                pos      = $puller.data(SAVED_POS) || {
                                cssTop: $.css(this, 'top', true),
                                top: $puller.offset().top + marginTop,
                                listTop: $ul.outerHeight() + $puller.offset().top + marginTop,
                                start: e.pageY,
                                px: e.pageX,
                                py: e.pageY,
                                height: $ul.outerHeight() + $caption.outerHeight()};

            $caption.text(opt.cancelable? opt.cancelCaption : opt.caption);
            if ($content.length === 0) {
                $caption.css({top: -pos.height});
            }

            /**
             * Scan for possible candidate item under mouse or touch position.
             */
            function scan(e) {
                adapt(e);
                // TODO: ignore middle/right mouse button
                var oldSelected = $selected;
                if (expanded) {
                    // hilight list item under mouse
                    // TODO: detect item under touch position
                    $selected =	e.touched ? $(e.target).closest('li'): $puller.find('li:hover');
                } else {
                    // search top visible list item
                    var py = e.pageY, d = py - pos.start,
                        $li = $list.last(), h = 0, lh,
                        down = py > pos.py;

                    if (d <= pos.height && d > 0) {
                        var ch = py - pos.start;
                        $content.height(ch);
                        $puller.offset({ top: ch + pos.top});
                    }

                    d *= 7;
                    while ($li.length) {
                        lh = $li.outerHeight();
                        if (d < 7 * h + (down ? 6 : 11) * lh) {
                            if (down) {
                                if ($li.index() === 0 && d > 7 * h + 4 * lh) {
                                    $selected = $li;
                                    break;
                                }
                                $li = $li.next();
                            }
                            $selected = $li;
                            break;
                        } else {
                            $li = $li.prev();
                            h += lh;
                            if ($li.length === 0 && opt.cancelable && d > 7 * h + 6 * lh) {
                                $selected = EMPTY;
                            }
                        }
                    }

                    if (!down && $selected[0] === $list.last()[0] && d < 3 * lh) {
                        $selected = EMPTY;
                    }
                }

                if ($selected[0] !== oldSelected[0]) {
                    $list.removeClass(CLS.SELECTED);
                    $selected.addClass(CLS.SELECTED);
                }
                pos.px = e.pageX;
                pos.py = py;
            };

            /**
             * Fold up pulldown list, fire changed event as needed.
             */
            function foldup(e) {
                if (e.type === "touchend") {
                    scan(e);
                } else {
                    adapt(e);
                }

                // click to expand
                if (e.pageX == pos.px && e.pageY == pos.start) {
                    $puller.data(SAVED_POS, pos)
                           .offset({ top:  pos.listTop})
                           .addClass(CLS.EXPANDED);

                    if ($.isFunction(opt.matchSelected)) {
                        opt.matchSelected($list, $handler);
                    }
                    $content.height($ul.outerHeight() );

                    expanded = true;
                    return;
                }

                $(this).off('mouseup', foldup)
                       .off('mousemove', scan);

                $(this).off('touchend', foldup)
                       .off('touchmove', scan);

                var effects = {duration: 'fast'};
                $content.animate({height: -marginTop}, effects);
                effects.complete = function() {
                    $content.height('');
                    try {
                        if ($selected.length > 0) {
                            $puller.trigger('change', [$selected]);
                        }
                    } catch(e) {
                    } finally {
                        OPENED_FLAG = false;
                    }
                };
                $puller.animate({top: pos.cssTop }, effects);

                $puller.removeData(SAVED_POS).removeClass(CLS.EXPANDED);
                $list.removeClass(CLS.SELECTED);
            }

            $(document).on('mousemove', scan)
                       .on('mouseup', foldup);

            $(document).on('touchmove', scan)
                       .on('touchend', foldup);
            e.preventDefault();
        }

        $elements.on('mousedown', expand);
        $elements.on('touchstart', expand);

        return this;
    };

});