/**
 * ryn.utils.js
 */
define(['jquery'], function($) {
    var ARR = Array.prototype;


    // TODO: one slot task delayer
    function Delayer() {
        var timer;

        $.extend(this, {
            call: function(task, delay) {
                if (!module.isUndefined(timer)) {
                    clearTimeout(timer);
                    timer = undefined;
                }
                timer = setTimeout(task, delay);
            },

            cancel: function() {
                clearTimeout(timer);
                timer = undefined;
            }
        });
    };

    // a powerful string buffer
    function Buffer(h, t, d) {
        var arr = [];
        module.isUndefined(d) && (d = '');

        $.extend(this, {
            add: function() {
                    h && arr.push(h);
                    ARR.push.apply(arr, arguments);
                    t && arr.push(t);
                    return this;
                },
            insert: function() {
                t && arr.unshift(t);
                ARR.unshift.apply(arr, arguments);
                h && arr.unshift(h);
                return this;},
            clear: function (values) {arr = $.isArray(values) ? values : []; return this;},
            isEmpty: function() {return arr.length == 0;},
            toArray: function() {return arr;},
            join: function() { return arr.join(d); },
            toString: this.join
        });
    };

    // based on https://developer.mozilla.org/en-US/docs/Web/API/document.cookie
    function cookiecan(doc) {
        doc = doc || document;
        return {
              get: function (sKey) {
                return decodeURIComponent(doc.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
              },
              set: function (sKey, sValue, vEnd, sPath, sDomain, bSecure) {
                if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) { return false; }
                var sExpires = "";
                if (vEnd) {
                  switch (vEnd.constructor) {
                    case Number:
                      sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
                      break;
                    case String:
                      sExpires = "; expires=" + vEnd;
                      break;
                    case Date:
                      sExpires = "; expires=" + vEnd.toUTCString();
                      break;
                  }
                }
                doc.cookie = encodeURIComponent(sKey) + "=" + encodeURIComponent(sValue) + sExpires + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "") + (bSecure ? "; secure" : "");
                return true;
              },
              remove: function (sKey, sPath, sDomain) {
                if (!sKey || !this.has(sKey)) { return false; }
                doc.cookie = encodeURIComponent(sKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + ( sDomain ? "; domain=" + sDomain : "") + ( sPath ? "; path=" + sPath : "");
                return true;
              },
              has: function (sKey) {
                return (new RegExp("(?:^|;\\s*)" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=")).test(doc.cookie);
              },
              keys: /* optional method: you can safely remove it! */ function () {
                var aKeys = doc.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:\=[^;]*)?;\s*/);
                for (var nIdx = 0; nIdx < aKeys.length; nIdx++) { aKeys[nIdx] = decodeURIComponent(aKeys[nIdx]); }
                return aKeys;
              }
            }
    };

    function createPool(size) {
      var used = 0, pending = [];
      size = size || 3;
      
      return {
            get: function() {
                   var wait = $.Deferred();
                   used++ < size ? wait.resolve(used) : pending.push(wait);
                   return wait.promise({ free: function() {
                      if (used > 0 && wait && wait.state !== 'pending') {
                        pending.length > 0 && pending.shift().resolve(used);
                        used--; wait = null;
                      }
                    }});
                },
        adjust: function(newSize) {
                  var d = newSize - size;
                  if (d > 0) {
                    while (pending.length >= d) {
                      pending.shift().resolve(used--);
                    }
                  }
                  size = newSize;
                },
       release: function() {
                  var old = pending;
                  pending = [];
                  used = 0;
                  old.forEach(function(w) { w.resolve(0) })
                }
      }
    }

    var module = {
        // cookie helper associated with a specified document
        cookiecan: cookiecan,

        // check if it is an undefined value
        isUndefined:
            function(v) { return typeof v === 'undefined'; },

        // slice on any array-like values (i.e. arguments)
        slice:
            function(arr, begin, end) { return ARR.slice.call(arr, begin, end);},

        // evaluate as a function result or a simple value
        eval:
            function(v) {return (typeof v === 'function') ? v.apply(null, ARR.slice.call(arguments, 1)) : v;},

        repeat: function (s, n) {
            var arr = [''], i;
            for (i = 0; i < n; i++, arr.push(s));
            return arr.join('');
        },

        randomstr: function(l) {
            return Math.random().toString(36).substring(2, 2 + (l || 7));
        },

        keywords: function(s) {
            return s.split(/[ \u3000]*/).filter(function(v) {return v.length > 0;});
        },

        matchAny: function(t, w) {
            var k = this.keywords(w);
            if (k.length > 0) {
                return k.some(function(v) {
                    return t.indexOf(v) != -1;
                });
            } else {
                return true;
            }
        },
        matchAll: function(t, w) {
            var k = this.keywords(w);
            if (k.length > 0) {
                return k.every(function(v) {
                    return t.indexOf(v) != -1;
                });
            } else {
                return true;
            }
        },

        delayer: function() {
            return new Delayer();
        },
      
        pool: createPool,

        buffer: function(head, tail, delimiter) {
            return new Buffer(head, tail, delimiter);
        },

        expect: function(proc) {
            var cache = {};
            return function(key) {
                if (!cache[key]) {
                    cache[key] = $.Deferred(function(deferred) {
                        proc(deferred, key);
                    }).promise();
                }
                return cache[key];
            };
        },

        /**
         * スコープ生成処理
         * ストレージとストレージ内のデータを識別するIDを渡して、ストレージに対してID毎のデータの設定、削除を行う為のスコープを生成する
         * ストレージ内のデータを取得する際は、戻り値のスコープを直接参照して、データを取得する
         *
         * @parameter storage localStorage/sessionStorage
         * @parameter id storageを識別するID
         * @return    scope: ストレージに対してID毎のデータの設定、削除を行う為のスコープ
         */
        createScopeFrom: function(storage, id) {
          var scope = storage[id];
          scope = (scope && JSON.parse(scope)) || {};
          var delayer = new Delayer();
          function writebackLater(scope) {
            delayer.call(scope.writeback.bind(scope));
            return scope;
          }

          // ローカルストレージは文字列しか保存できない！
          return $.extend(scope, {
            put: 		function(prop, value) {	this[prop] = value; return writebackLater(this); },
            writeback : function () { localStorage[id] = JSON.stringify(this); return this;},
            del: 		function(prop) {delete this[prop]; return writebackLater(this);}
          });
        }
    };

    // print debug message
    try {
        if (window.console) {
            if (window.console.log && $.isFunction(window.console.log)) {
//            module.debug = function() {console.log.apply(null, arguments);};
                module.debug = console.log;
            } else {
                module.debug = window.console.log = function() {};
            }
        } else {
            window.console= {log: function() {}};
        }
    } catch(e) {
        window.console = {log: function() {}};
    }
    module.debug = function() { /* ignore */ };

    return module;
});