/**
 * ryn.ui.widget.js - A lightweight widget management JavaScript module:
 * 	* Promises API based asynchronous loading.
 * 	* Ability to extend widget via inheritance.
 *
 * Usage:
 * ==========
 * - Create a HTML file containing widget(s) definition and link(s) to associated JavaScript/CSS style sheet.
 *      widget specified attributes:
 *      	data-widget   Mark a HTML element as widget, using its value as widget identification.
 * 	 		data-merge    Mark an element(script or stylesheet) to be merged with main document.
 * 						  For <script> element, its value represents a AMD module id.
 *      example: widgets.html
 * 	 <html xmlns:ryn="http://www.bbs.co.jp/smartweb/2013">
 *   <head>
 *   	<link rel="stylesheet" type="text/css" href="my.widgets.css" ryn:mixin>
 *   </head>
 * 	 <body>
 * 		<div ryn:model="my.widget.msg">
 * 			<span>I am a widget.</span>
 *      </div>
 *      ...
 *      <script ryn:mixin="my.widgets"></script>
 *   </body>
 *   </html>
 *
 * - Use requireJS to load ryn.ui.widget module, which is function object.
 * 		require(['ryn/ui.widget',..], function(widget, ..) {..});
 *
 * - Define how to connect widget id to its associated resource(s):
 *      - map or package list
 *      - finder function
 *      - pass path directly
 *      - draft a widget without associated resource at all
 *
 * - Define widget constructor function.
 * 		// a base widget
 * 		widget('my.widget.msg').define(function(color, name) {
 * 			this.css('color', color)
 * 				.append(document.createTextNode('Call me ' + name + '. '));
 * 		});
 * 		// a inherited widget
 * 		widget.inherit('my.widget.msg:alert').define(function MsgAlert(color, msg) {
 *          MsgAlert._super('#F00', msg);
 * 			this.append(document.createTextNode('I am inherited from "my-widget".'));
 * 		});
 * 		// a sibling widget
 * 		widget.sibling('my.widget.msg:login').define(function() {
 * 			this.append(document.createTextNode('I am a sibling of "my-widget".'));
 * 		});
 *
 * - Asnchronous create new widget instance from widget model:
 *		widget('my-widget').thenCreate('red', 'Agent Smith').appendTo($el);
 *		widget('child-widget').thenCreate('blue', 'Smith Jr.').appendTo($el);
 *		widget('no-widget').thenCreate().fail(function(wg) { console.error('Widget does not exist.'); });
 *
 * RYN(凜) is named after my pretty daughter.
 *
 * @author Feng Dihai<fengdh@gmail.com>
 * @version 0.1.0 preview
 * @since  2014/10/01
 */
define(['jquery', 'ryn/ui.databind'], function ($, bind) {
  var
  /* [Regular expression]     **************/
    TO_DOT    = /[>/]/,       // convert '>' or '/' to '.' when normalizing widget id
    TRIM_TAIL = /\>.*$/,      // extract string before the last '>' when translating widget id to its resource path
    COLON_BRK = /(.*):(.*)/,  // break widget id at ':' into parent and child parts
  /* [Other constants]        **************/
    GLOBAL    = this,         // alias of global object which equals window object inside browser
    VOID      = void(0),      // alias of undefined value
    NOOP      = new Function, // no-op function
  /* [Module scope variables] **************/
    /*            alias */  $isFunc = $.isFunction,
    /*            alias */   $defer = $.Deferred,
    /*  module settings */ settings = $.extend({}, GLOBAL.Ryn ? GLOBAL.Ryn.WidgetKit : VOID),
    /*       domain map */ _domains = {},
    /*   default domain */ defaultDomain,
  /* [One-line utility functions]      **************/
    // slice array-like object
    slice     = function(target, start, end) { return [].slice.call(target, start, end) },
    // a function return a single value being assigned
    fnValue   = function(v) { return v },
    // create a function which returns a constant value
    fnConst   = function(v) { return fnValue.bind(null, v) },
    // fill target fields with paired values
    fill      = function(target, fields, values) { for (var i in fields) { target[fields[i]] = values[i] } },
    // make a object from a prototype and then extend it if necessary
    makeobj   = function(proto, ext) { return $.extend(Object.create(proto || Object.prototype), ext) },
    // Normalize widget id, e.g. 'package>widget' or 'package/widget' or 'package.widget' -> 'package.widget'.
    normalize = function(id) { return id !== VOID ? id.replace(TO_DOT, '.') : VOID },
    // Detect if a deferred object in pending state
    notReady  = function(d)  { return d.state() === 'pending' };

  // Look up map and package list, converting widget id to resource path if existed.
  function lookup(id, obj /* used as local variables */, p, dict) {
    if (obj) {
      if (obj.map && (p = obj.map[id])) {
        return p;
      } else {
        if (p === '') {
          return id;
        } else if (dict = obj.package || obj.packages) {
          for (p in dict) {
            if ($.inArray(id, $.makeArray(dict[p])) >= 0) {
              return p;
            };
          }
        }
      }
    }
    // return undefined
  }

  // Convert resource path to valid location: 1) prepend root path, 2) append HTML file extension.
  function locate(path, base) {
    path[0] === '/' || (path = (base || '/pack') + '/' + path);
    var tail = path.slice(-5).toLowerCase();
    tail === '.html' || tail.slice(1) === '.htm' || (path += '.html');
    return requirejs.toUrl(path);
  }

  // Convert widget id to embedding resource location according to domain options or default way.
  function translatePath(options, path, id) {
    var finder = options.finder;
    path = path || ($isFunc(finder) ? finder(id) : lookup(id, finder)) || id.replace(TRIM_TAIL, '');
    return $isFunc(options.location) ? options.location(path) : locate(path, options.base);
  }

  // Solve url of mixin-ed script/stylesheet relative to referring resource.
  function solveMixin(url, ref, options) {
    if ($isFunc(options.solve)) {
      return options.solve(url, ref);
    } else if (!url || url[0] === '/') {
      return url;
    } else {
      var pos = ref.lastIndexOf('/');
      return (pos < 0 ? '' : ref.slice(0, pos)) + '/' + url;
    }
  }

  // Simulated Class
  function Class(base, setup, props) {
    $isFunc(setup) || ( props = setup, setup = NOOP );
    fill(this, ['base', 'setup', 'props'], [base, setup, props || {}]);
  }

  Class.prototype = {
      // root: false,  // true if representing root in domain (optional)
      proto: function() {
        return this.it = this.it || (this.base ? makeobj(this.base.proto(), this.props) : makeobj(this.props));
      },
      chainup: function (proxy) {
        var b = this.base, up = this;
        while (b && b.setup === NOOP) { b = b.base }
        this.setup._super = b ? (up = b.chainup(proxy), b.root ? NOOP : b.setup.bind(proxy)) : NOOP;
        return up;
      },
      makeProxy: function(ctx) {
        var supr = this.base ? this.base.makeProxy(ctx) : {},
            val  = function(n, v) {
              n = n === VOID ? 'content' : n.toLowerCase();
              return n === 'super' ? supr : (arguments.length > 1 ? ctx[n] = v : ctx[n]);
            };
        return makeobj(this.proto(), {$: val});
      },
      build: function(proxy, $el, args) {
        proxy.$('content', $el);
        var top = this.chainup(proxy), setup = this.setup;
        top === this || !top.root || top.setup === NOOP || top.setup.apply(proxy, args);
        (setup === NOOP ? setup._super : setup).apply(proxy, args);
        return proxy;
      },
      construct: function (id, $el, args) {
        return this.build(this.makeProxy({id: id}), $el, args);
      },
  };

  // Resolve a deferred object standing for a widget module to inject code being defined.
  function inject(module, id, domain, cls) {
    if (notReady(module)) {
      return module.resolve(domain.monitor('defined', id, cls));
    } else {
      throw 'Already defined: ' + id;
    }
  }

  // Resolve a deferred object standing for a widget model to return a promise of widget module
  function settle(model, $el, inject) {
    if (notReady(model)) {
      var module = $defer(),
          target = {  tmpl: fnConst($el),
                    absent: fnConst(!inject),
                    create: function () { return $el.clone() } };

      model.inject = inject ? inject.bind(null, module, model.id) : NOOP;
      model.resolve(module.promise(target));
    }
  }

  // Wrapper for a method invocation with arguments
  function Invoc(target, method, args) {
    fill(this, ['target', 'method', 'args'], [target, method, args]);
  }

  // Execute a method invocation
  Invoc.prototype.exec = function() { return this.method.apply(this.target, this.args) };

  // return a constructor function to be invoked when creating widget UI object
  function constructor(id, widget, args) {
    return function ($el, cls, domain) {
      try {
        var invoc = domain.monitor('willCreate', id, new Invoc(cls, cls.construct, [id, $el, args])),
            proxy = domain.monitor('created', id, invoc.exec());
        widget.cls = cls;
        return widget.resolveWith(proxy, [proxy]);
      } catch (e) {
        console.log(e);
        return widget.reject('Failed when constructing widget caused by: \n\t' + e);
      }
    };
  }

  // Assemble promised widget model, with which you can define/create widget lately.
  function assemble(domain, model, base) {
    model.result = model.result || model.promise({
        /**
         * @return Id of widget model.
         */
        id: fnConst(model.id),
        /**
         * Define constructor, properties & methods for this widget model.
         *
         * @param setup Constructor function.
         * @param props A plain object containing properties & methods as prototype of widget model.
         * @return Promise of widget model itself.
         */
        define: function(setup, props) {
          $.when(this, base)
           .then(function (module, superModule) {
              return $.when(superModule || false) } )
           .then(function(superCls) {
              if (!superCls && domain.options.proto) {
                var arr = $.makeArray(domain.options.proto);
                arr.push(VOID, VOID);
                superCls = new Class(VOID, arr[0], arr[1]);
                superCls.root = true;
              }
              return model.inject(domain, new Class(superCls, setup, props));
            });
          return this;
        },
        pupulate: function($el) {
          if (notReady(model)) {
            settle(model, $el, inject);
          } else {
            console.warn('Cannot override content of a resolved model.');
          }
          return this;
        },
        /**
         * Create a promise of widget if widget model being resolved (loaded & defined).
         * @param Optional arguments to be passed to widget constructor function.
         * @return A promise of widget with chainable API.
         */
        thenCreate: function() {
          var widget = $defer(), args = arguments;
          this.then(function (module) {
            widget.module = module;
            module.absent()
              ? widget.reject('Unable to load widget: ' + model.id)
              : $.when(module.create(), module, domain).then(constructor(model.id, widget, args));
          });

          return domain.endow(widget);
        }
      });
    return model.result;
  }

  // Domain supports

  // Scan dom object(usually returned by an XHR) for widget UIs and load their associated script/stylesheets.
  function scanner(id, model, path, $loader, domain) {
    return function whenDone(response, status, xhr) {
      if (status === 'error') {
        console.warn('Unable to load widget:', id || '<none>', 'from', path);
        settle(model, $('<div class="-widget-blank-"></div>'), inject);
      } else {
        var links = [], found, options = domain.options;
        $loader.find(options[':mixin']).each(function() {
          var $this = $(this), url = $this.attr(options['@url']);
          if ($this.is('script')) { // external/internal script
            url = url || $this.attr('src');
            url ? links.push(solveMixin(url, path, options)) : $($this.closest('head').length ? 'head' : 'body').append($this);
            // TODO: remember mixin-ed scripts to remove them later!!!!
          } else { // external/internal CSS stylesheet
            $this.attr('href', solveMixin(url || $this.attr('href'), path, options));
            $($this.parent().is('head') ? 'head' : 'body').append($this);
            domain.styleSheets.push(this);
          }
        });

        $loader.find(options[':model']).each(function() {
          var $el = $(this), thisId = $el.attr(options['@id']) + '', thisModel;
          if (thisId === id) {
            thisModel = model;
            found = true;
          } else {
            thisModel = domain.fetch(thisId);
          }
          settle(thisModel, options.content ? options.content($el) : $el.children(), inject);
        });

        links.length > 0 && requirejs(links);
        (!id || found) || whenDone(response, 'error', xhr);
      }
    };
  }

  function loadModel(model, path, domain) {
    var $loader;
    if (path) { // external
      if (domain.unknown(path)) {
        $loader = $('<div>', {style: 'display: none;'});
        $loader.load(path, scanner(model.id, model, path, $loader, domain));
      }
    } else {    // local
      $loader = $('[ryn\\:module]');
      scanner(model.id, model, GLOBAL.location.pathname, $loader, domain)(null, 'ok', null);
    }
  }

  function obtain(id, path) {
    var m = COLON_BRK.exec(id);
    if (m) {
      return this.inherit(m[1], id, path);
    } else {
      var model = this.fetch(id);
      notReady(model) && loadModel(model, translatePath(this.options, path, id), this);
      return assemble(this, model);
    }
  }

  function scan() {
    slice(arguments, 1).forEach(function (path) {
      path = translatePath(this.options, path);
      if (this.unknown(path)) {
        var $loader =  $('<div>', { style: 'display: none;' });
        $loader.load(path, scanner(null, $defer(), path, $loader, this));
      }
    });
  }

  var DOMAIN_DEFAULTS = {
        ':mixin': '[ryn\\:mixin]', '@url': 'ryn:mixin',
        ':model': '[ryn\\:model]',  '@id': 'ryn:model',
          events: { defined: false, willCreate: false, created: false },
         publish: function(will) {
            var api   = {will: will},
                verbs = ['appendTo', 'append', 'prepend', 'pretendTo', 'before', 'after',
                         'replaceWith', 'replace', 'remove', 'empty', 'wrap', 'wrapAll', 'wrapInner'];
            verbs.forEach(function(k) { api[k] = will($.fn[k]) });
            api.bind = will(function(data, options) { return bind(this, data, options), this });
            return api;
         }
//       content: VOID,     // return $el.children()
//      location: VOID,
//         solve: VOID,
//         proto: VOID      // = [func, {..}], widget prototype
  };

  function draft(id) {
    var m = COLON_BRK.exec(id);
    if (m) {
      return this.inherit(m[1], id);
    } else {
      var model = this.fetch(id);
      return assemble(this, model);
    }
  };
  
  // IMPORTANT: Don't use this method, which is unreliable to release resource mixin-ed by widgets in the domain.
  function release() {
    this.entries = {};
    this.paths = {};
    this.styleSheets.forEach(function(each) { $(each).remove() });
    // TODO: remove mixin-ed scripts!!!!
    this.styleSheets = [];
  }

  // public API
  function Domain(options) {
    var agent = obtain.bind(this), $$ = this.$ = $(this);
    agent.scan    = scan.bind(this);
    agent.draft   = draft.bind(this);
    agent.release = release.bind(this);
    agent.options = fnConst(options);
    ['on', 'off', 'one'].forEach(function(fn) {
      agent[fn] =　function() { return $$[fn].apply($$, arguments), agent }
    });

    options = $.extend({}, DOMAIN_DEFAULTS, options);
    fill(this, ['entries', 'paths', 'styleSheets', 'scripts',
                'options', '$', 'agent'], [{}, {}, [], {}, options, $$, agent]);
  }

  Domain.prototype = {
    unknown: function(path) { return !this.paths[path] && (this.paths[path] = true) },
     /**
     * Refer to a widget model which can be either lazy-resolved or an existed one (including inherited widget).
     *
     * @param id a widget id, e.g.'path>id:child:grand-child' where
     *                          i. using '>' to separate optional path from id
     *                         ii. using ':' to indicate inheriting from a base widget
     * @param path optional, pass resource path implicitly
     */
    inherit: function(baseId, childId, path) {
        var base  = this.agent(baseId, path), model = this.fetch(childId);
        notReady(model) && base.then(function(module) { settle(model, module.tmpl(), inject) });
        return assemble(this, model, base);
    },
    // fetch widget model model from cache, create new one if missing
    fetch: function(id) {
        return id = normalize(id), this.entries[id] || (this.entries[id] = $.extend($defer(), {id: id}));
    },
    // enhance the deferred object standing for a widget with chainable api
    endow: function(widget) {
        function will(fn) {
          function run() {
            var args = slice(arguments), expect = $defer();
            widget.then(function(proxy) {
              try {
                var $el = proxy.$(), r = ($isFunc(fn) ? fn : $el[fn]).apply($el, args);
                expect.resolve(makeobj(proxy, {$: function(n) { return (n + '').toLowerCase() === 'result' ? r : proxy.$(n) }}));
              } catch (e) {
                // IMPORTANT: It's critical to catch potential exception here due to jQuery's implementation (before 3.0),
                //            unable to re-throw it but can only output as an UNCAUGHT exception to console.
                // @see http://blog.mediumequalsmessage.com/promise-deferred-objects-in-javascript-pt1-theory-and-semantics
                notReady(expect) ? expect.reject(e) : console.error('UNCAUGHT', e);
              }
            }, function(e) { console.error('ryn.ui.widget#endow(widget)', e) });
            return expect.promise(api);
          }

          return arguments.length > 1 ? run.apply(null, slice(arguments, 1)) : run;
        };

        var api = this.options.publish(will);
        widget.then(function(proxy) {
          api.restore = function(/* arg0, arg1, .. */) {
            var $content = widget.module.create();
            proxy.$() && proxy.$().replaceWith($content);
            widget.cls.build(proxy, $content, slice(arguments));
            return widget.promise(api);
          }
          api.cast = function($content/* , arg0, arg1, .. */) {
            widget.cls.build(proxy, $content, slice(arguments, 1));
            return widget.promise(api);
          }
        });
        return widget.promise(api);
    },
    monitor: function(type, id, data) {
        this.options.events[type] && this.$.triggerHandler(type, [id, data]);
        return data;
    }
  }

  function findDomain(name) {
    var d = _domains[name];
    return d ? (d instanceof Domain ? d : _domains[name] = new Domain(d)) : defaultDomain;
  }

  (function _regesiter_domains(v) {
    for (var k in v || {}) { _domains[k] = v[k] };
    defaultDomain = _domains[''] = new Domain(_domains['']);
  }) (settings.domains);


  return $.extend(defaultDomain.agent, {
            domain: function(name) { return findDomain(name || '_temp_').agent },
          register: function(name, options) { return (_domains[name || '_temp_'] = new Domain(options)).agent },
                 _: { NOOP: NOOP,
                      fnConst: fnConst
                    }
        });
});


// [OK]: registered & pre-defined domain
// [OK]: common behavior provided by domain
// [OK]: Domain's prototype
// [OK]: life circle events: defined/willCreate/created

// TODO: ryn.ui.widget.import.js
// TODO: packed(zipped) widget file support
