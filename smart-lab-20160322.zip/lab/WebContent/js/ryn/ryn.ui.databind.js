/**
 * ryn.ui.databind.js
 */
define(['jquery', 'ryn/utils', 'ryn/ui', 'ryn/ui.grid', 'accounting'], function($, UTILS, UI, Grid, ACC) {

    Number.isNaN = Number.isNaN || function(any) { return typeof any === 'number' && isNaN(any); };

    var settings = {};

    function setup(settings) {
        var NEG_MARK = '▲', REGEXP_NEG = new RegExp('^\\s*[\\-\\' + NEG_MARK + '].*'),
            CLEAN = new RegExp("[^0-9-" + '.' + "]", ["g"]);

        $.extend(ACC.settings.currency, {
            symbol: '',
            format: {
                pos : '%s%v',  // for positive values, eg. '$ 1.00' (required)
                neg : NEG_MARK + '%s%v', // for negative values, eg. '$ (1.00)' [optional]
                zero: '%s%v'    // for zero values, eg. '$  0' [optional]
            }
        });

        var defaults = {
                isNeg : function(t) {
                    return REGEXP_NEG.test(t);
                },
                // TODO: better way to validate numeric/text value, like Excel using '  explicitly
                notNumeric: function(t) {
                    if (t.charAt(0) === '\'') return true;
                    t = t.replace(CLEAN, '');
                    return t === '' || Number.isNaN(t * 1);
                }
            };

        $.extend(settings, defaults , settings);
    }

    setup(settings);

    function data($el, name, defv) { return $el.data('fmt-' + name) || defv; }

    function styleNeg($el, v) { v < 0 ? $el.addClass('neg') : $el.removeClass('neg'); }

    function fmtNumeric(options, $el, v, func, style) {
        var num = v === '' ? Number.NaN : v * 1;
        if (Number.isNaN(num)) {
            v = data($el, 'default', v);
            if (typeof v !== 'number') {
                return (v.charAt(0) !== '\'') ? v : v.slice(1);
            }
        } else {
            v = num;
        }
        style && style($el, v);
        return func(v, options);
     }

    function createFormat($el, options, fmt, style) {
        if ($el) {
          var locals = { precision: data($el, 'precision', options.precision),
                          symbol:    data($el, 'symbol',    options.symbol),
                          thousand:  data($el, 'thousand',  options.thousand)};
          options = $.extend({}, locals);
        }

        return function($el, v) { return fmtNumeric(options, $el, v, fmt, style); };
    }

    var D_FMT = 'ryn.ui.databind/fmt',
        PERCENT = [null, {thousand: '', precision: 1}, ACC.formatMoney, styleNeg],
        NONE = function($el, v) { return (v === '') ? data($el, 'default', v) : v;}
        FORMAT = {
          'none':   	NONE,
          'num':    	[null, {precision: 0}, ACC.formatNumber],
          'num(2)': 	createFormat(null, {precision: 2}, ACC.formatNumber),
          'currency':   [null, {precision: 0}, ACC.formatMoney, styleNeg],
          'percent':    PERCENT,
          'percentage': PERCENT
        };

    function getFormat($el) {
        var fmt = $el.data(D_FMT);
        if (!fmt) {
            if (fmt = FORMAT[$el.attr('type')]) {
                $.isFunction(fmt) || (fmt[0] = $el, fmt = createFormat.apply($el, fmt));
            } else {
                fmt = FORMAT['none'];
            }
            ($el.editable() || data($el, 'retain', false)) && $el.data(D_FMT,fmt);
        }
        return fmt;
    }

    // TODO: format date/time
    // TODO: multiple values
    var AS_TEXT = {
          get: function(el) {
              var $el = $(el), t = $el.text(), fmt = getFormat($el);

              if (fmt && fmt !== NONE) {
                  var neg = settings.isNeg(t), num = ACC.unformat(t), notNumeric = settings.notNumeric(t);

                  if (num === 0 || notNumeric) {
                      var defv = data($el, 'default', null);
                      if (notNumeric || t === '' || t === defv) {
                          return typeof defv !== 'number' ? null : defv;
                      }
                  }
                  neg && num > 0 && (num = -num);
                  return num;
              } else {
                  return t;
              }
          },
          set: function(el, v) {
              var $el = $(el), fmt = getFormat($el);
              fmt && (v = fmt($el, v));
              $el.empty()[0].appendChild(document.createTextNode(v));
              return v;
          }
    }, AS_BLOCK = {
          get: function(e) {
              var $el = $(e);
              if ($el.prop('contenteditable')) {
                  var arr = [];
                  $el.contents().each(function() {
                      switch (this.nodeType) {
                        case 3: arr.push(this.nodeValue); break;
                        case 8: break;
                        default:
                            if (this.tagName !== 'BR') {
                                arr.push(this.nodeValue);
                            } else {
                                arr.push('\n');
                            }
                      }
                  });
                  return arr.join('');
                }
                // TODO: fill object
                return $el.text();
          },
          set: function(e, v) {
              var $el = $(e);
              if (!$el.data("mapping")) {
                  if (isSimpleValue(v)) {
                      $el.text(v);
                  } else if (v === null) {
                      $el.empty();
                  } else {
                      bind($el, v);
                  }
              }
              return v;
          }
    };

    $.extend($.valHooks, {
        'value': AS_TEXT,
        'td': AS_TEXT,
        'tag': AS_TEXT,
        'timestamp': AS_TEXT,
        'span': AS_TEXT,
        'div': AS_BLOCK,

        // TODO: multiple values
        'item': {
            get: function(e) {
                return $(e).find('value').val();
            },
            set: function(e, v) {
                $(e).find('value').val(v);
                return v;
            }
        },

        'table': {
            get: function(e) {
                return new Grid($(e)).input();
            },
            set: function(e, v) {
                new Grid($(e)).input(v.input).show();
                return v;
            }
        }
    });

    function isSimpleValue(v) {
        return typeof v !== 'object' || v instanceof String || v instanceof Number || v instanceof Boolean || v instanceof Date;
    }

    function bind($target, data, options) {
        if ($.isFunction($target.bindWith) && $target !== this /* not called recursive */) {
            if (!$target.bindWith(data, options)) {
                return;
            };
        }

        var p, $e, s;

        function sval(s) {
            $e = $target.find(s);
            if ($e.length > 1) {
                $e.each(function() { $(this).val(data[p]);});
            } else {
                if ($e.is('table')) {
                    $e.val({input: data[p]});
                } else {
                    $e.val(data[p]);
                }
            }
        }

        if ($.isArray(data)) {
            if ($target.is('table')) {
                $target.val({input: data});
            }
        } else {
            // TODO: should traverse among DOM tree
            // TODO: should bind single value, check more careful
            // TODO: bind empty or null object to leaf or container element
            // TODO: how to pass options to implicit recursive call
            if (isSimpleValue(data)) {
                $target.val(data);
            } else {
                for (p in data) {
                    s = (options && options[p]) || ['#' + p, '[data-tag="' + p + '"]'];

                    if ($.isArray(s)) {
                        s.forEach(sval);
                    } else {
                        sval(s);
                    }
                }
            }
        }
    }

    bind.setup = setup;
    return bind;
});