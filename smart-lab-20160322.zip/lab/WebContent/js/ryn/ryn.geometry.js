/**
 * ryn.geometry.js
 */
define([], function() {
    var NEAR_RIGHT_ANGLE = Math.PI * 3 / 5;

    // geometric calculation, point is presented as [x, y]
    function delta(a, b) { return [a[0] - b[0], a[1] - b[1]]; }

    function direction(a, b) { return a[0] * b[1] - a[1]* b[0] >= 0 ? 1 : -1; }

    function angle(a, b) { return Math.acos((a[0] * b[0] + a[1] * b[1]) / (len(a) * len(b))); }

    function len(v) { return Math.sqrt(v[0] * v[0] + v[1] * v[1]); }

    function unit(c) { var l = len(c); return [c[0] / l, c[1] / l]; }

    function scale(c, f) { return [c[0] * f, c[1] * f]; }

    function add(a, b) { return [a[0] + b[0], a[1] + b[1]]; }

    function same(a, b) { return a[0] === b[0] && a[1] === b[1];}

    function rotate(v, a) { var s = Math.sin(a), c = Math.cos(a); return [v[0] * c - v[1] * s, v[0] * s + v[1] * c]; }

    function average() {
        var args = arguments, len = arguments.length, x = 0, y = 0;
        for (var i = 0; i < len; x += args[i][0], y += args[i++][1]) {};
        return [x/len, y/len];
    }

    // TODO: not implemented yet: chain shape detector and provide a fallback
    function nextShape(args) {
        var fallback = context['shape_fallback'];
        return fallback ? (typeof fallback === 'function' ? fallback(vertices) : null) : vertices;
    }

    var shape_detectors = {
        square: function (vertices) {
            if (vertices.closed && vertices.length === 5) {
                //check for square
                var p1 = vertices[0], p2 = vertices[1], p3 = vertices[2], p4 = vertices[3],
                    p1p2 = delta(p1, p2), p2p3 = delta(p2, p3), p3p4 = delta(p3, p4), p4p1 = delta(p4, p1);

                if ( angle(p1p2, p2p3) < NEAR_RIGHT_ANGLE && angle(p2p3, p3p4) < NEAR_RIGHT_ANGLE &&
                     angle(p3p4, p4p1) < NEAR_RIGHT_ANGLE && angle(p4p1, p1p2) < NEAR_RIGHT_ANGLE) {

                    var p1p3 = delta(p1, p3), p2p4 = delta(p2, p4), diag = (len(p1p3) + len(p2p4)) / 4.0,
                        corner1 = scale(unit(p1p3), -diag), corner2 = scale(unit(p2p4), -diag),
                        center = average(p1, p2, p3, p4);

                    var result = [  add(center, corner1),   add(center, corner2),
                                  delta(center, corner1), delta(center, corner2)];
                    result.push(result[0]);

                    result.square = result.closed = true;
                    return result;
                }
            }

            return null;
        },
        // TODO: more shape detectors: not implemented yet
        snapline: function (vertices) {return null;},
        triangle: function (vertices) {return null;},
        circle: function (vertices) {return null;},
        arc: function (vertices) {return null;},
        pie: function (vertices) {return null;},
        check: function (vertices) {return null;},
    };

    var module = {
        delta: delta,
        direction: direction,
        angle: angle,
        len: len,
        unit: unit,
        scale: scale,
        add: add,
        same: same,
        rotate: rotate,
        average: average,

        shape: shape_detectors,
        exportAs: inject,
    };

    function inject(prefix, G) {
        var arr = 'delta direction angle len unit scale add same rotate average'.split(' '),
            len = arr.length;
        return arr.reduce(function(r, name, i) {
                return r + name + ' = ' + prefix + '.' + name + (i < len - 1 ? ', ' : ';');
            }, 'var ');
    }

    return module;
});