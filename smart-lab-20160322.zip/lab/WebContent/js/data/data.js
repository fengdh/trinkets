/**
 * release version
 *
 * NOTE:
 *  - BUGFIX: jquery.mobile-1.4.2.js #10391-10393
 *            http://stackoverflow.com/questions/5657371/ie9-window-loses-focus-due-to-jquery-mobile
 */

define([], [
   { name: '葉野邸 新築工事',
     tag: 'は',
     contractor: '近藤建設',
     addr: '埼玉県富士見市針ケ谷３丁目',
     floor: 108.48,
     type: '在来',
     star: true,
     status: 1    // 1 = 受注確定、2 = 現場確認
   },

   { name: '真崎邸 増築工事',
         tag: 'ま',
         contractor: '高崎ハウシング',
         addr: '東京都足立区',
         floor: 138.12,
         type: 'RC',
       },

   { name: '浜口邸 増築工事',
       tag: 'は',
       contractor: '大和建設',
       addr: '東京都荒川区',
       floor: 98.12,
       type: '在来',
     },

   { name: 'カミラ邸 新築工事',
         tag: 'か',
         contractor: '新井工務店',
         addr: '神奈川県厚木市',
         floor: 117.41,
         type: '鉄骨',
       },

   { name: '小金井邸 新築工事',
         tag: 'か',
         contractor: '新井工務店',
         addr: '神奈川県厚木市',
         floor: 117.41,
         type: '輸入ログハウス',
       },

    {
        name : '溝口邸 増築工事',
        tag : 'ま',
        contractor : '高崎ハウシング',
        addr : '東京都足立区',
        floor : 138.12,
        type : 'RC',
    },

    {
        name : '谷原邸 増築工事',
        tag : 'た',
        contractor : '大和建設',
        addr : '東京都荒川区',
        floor : 98.12,
        type : '在来',
    },

    {
        name : '森永邸 新築工事',
        tag : 'ま',
        contractor : '新井工務店',
        addr : '神奈川県厚木市',
        floor : 117.41,
        type : '鉄骨',
    },

    {
        name : '榎木邸 新築工事',
        tag : 'あ',
        contractor : '新井工務店',
        addr : '神奈川県厚木市',
        floor : 117.41,
        type : '輸入ログハウス',
    },

    {
        name : '梅田邸 増築工事',
        tag : 'あ',
        contractor : '高崎ハウシング',
        addr : '東京都足立区',
        floor : 138.12,
        type : 'RC',
    },

    {
        name : '木下邸 増築工事',
        tag : 'き',
        contractor : '大和建設',
        addr : '東京都荒川区',
        floor : 98.12,
        type : '在来',
    },

    {
        name : '戸田邸 新築工事',
        tag : 'た',
        contractor : '新井工務店',
        addr : '神奈川県厚木市',
        floor : 117.41,
        type : '鉄骨',
    },

    {
        name : '樋口邸 新築工事',
        tag : 'あ',
        contractor : '新井工務店',
        addr : '神奈川県厚木市',
        floor : 117.41,
        type : '輸入ログハウス',
    },

    {
        name : '北村邸 増築工事',
        tag : 'き',
        contractor : '高崎ハウシング',
        addr : '東京都足立区',
        floor : 138.12,
        type : 'RC',
    },

    {
        name : '地井邸 増築工事',
        tag : 'た',
        contractor : '大和建設',
        addr : '東京都荒川区',
        floor : 98.12,
        type : '在来',
    },

    {
        name : '目黒邸 新築工事',
        tag : 'ま',
        contractor : '新井工務店',
        addr : '神奈川県厚木市',
        floor : 117.41,
        type : '鉄骨',
    },

    {
        name : '猪上邸 新築工事',
        tag : 'あ',
        contractor : '新井工務店',
        addr : '神奈川県厚木市',
        floor : 117.41,
        type : '輸入ログハウス',
    },
]);