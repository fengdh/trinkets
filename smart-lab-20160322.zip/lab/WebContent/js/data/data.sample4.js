// Card Oのためのサンプルデータをランダムに生成するfunctionモジュール
define(
	function() {
		return function() {
			return Math.random() > 0.5 && false
				? { censored: true,
					message: 'クレームあり',
					claimHistory: null }
				: { claimHistory: [
	                   {
	                	   claimNo : 'No13041',
	                	   ts : '2013/10/11 16:33',
	                	   content : '水漏れ',
	                	   cause : 'パイプ破裂'
	                   },

	                   {
	                	   claimNo : 'No13042',
	                	   ts : '2013/10/11 16:42',
	                	   content : '電気ケーブルが焦げた',
	                	   cause : '湿気によるショット'
	                   },

	                   {
	                	   claimNo : 'No13043',
	                	   ts : '2013/10/11 19:01',
	                	   content : '異臭',
	                	   cause : '冷蔵庫の電気が切れた'
	                   },

	                   {
	                	   claimNo : 'No13044',
	                	   ts : '2013/10/11 22:19',
	                	   content : 'ハエが大量発生',
	                	   cause : '冷蔵庫が腫れたため、腐った食品が暴露'
	                   },

	                   {
	                	   claimNo : 'No13045',
	                	   ts : '2013/10/11 23:45',
	                	   content : 'お客さんが転んだ',
	                	   cause : '大量ハエの襲来を驚いた'
	                   }
	                   ]};
	};
});