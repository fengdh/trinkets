/**
 * ryn.ui.widget.js - A lightweight widget management JavaScript module:
 * 	* Promises API based asynchronous loading.
 * 	* Ability to extend widget via inheritance.
 *
 * Usage:
 * ==========
 * - Create a HTML file containing widget(s) definition and link(s) to associated JavaScript/CSS style sheet.
 *      widget specified attributes:
 *      	data-widget   Mark a HTML element as widget, using its value as widget identification.
 * 	 		data-merge    Mark an element(script or stylesheet) to be merged with main document.
 * 						  For <script> element, its value represents a AMD module id.
 *      example: widgets.html
 * 	 <html>
 *   <head>
 *   	<link rel="stylesheet" type="text/css" href="../css/casenote.css" data-merge>
 *   </head>
 * 	 <body>
 * 		<div data-widget="my-widget">
 * 			<span>I am a widget.</span>
 *      </div>
 *      ...
 *      <script data-merge="app/widgets"></script>
 *   </body>
 *   </html>
 *
 * - Use requireJS to load ryn.ui.widget module, which is function object.
 * 		require(['ryn/ui.widget',..], function(widget, ..) {..});
 *
 * - Prepare a path resolver function object for global or local use.
 * 		var widgetFinder = function(tag) { return "widgets.html"; };
 * 		widget.resolveWith(widgetFinder);  // global resolver
 *
 * - Define widget constructor function.
 * 		// a base widget
 * 		widget('my-widget').define(function(color, name) {
 * 			this.css('color', color)
 * 				.append(document.createTextNode('Call me ' + name + '. '));
 * 		});
 * 		// a inherited widget
 * 		widget.inherit('my-widget', 'child-widget').define(function(color, name) {
 * 			this.append(document.createTextNode('I am inherited from "my-widget".'));
 * 		});
 * 		// a sibling widget
 * 		widget.sibling('my-widget', 'sibling-widget').define(function() {
 * 			this.append(document.createTextNode('I am a sibling of "my-widget".'));
 * 		});
 *
 * - Construct new widget instance:
 *		widget('my-widget').construct('red', 'Agent Smith').appendTo($el);
 *		widget('child-widget').construct('blue', 'Smith Jr.').appendTo($el);
 *		widget('no-widget').construct().fail(function(wg) { console.error('Widget does not exist.'); });
 *
 * RYN(凜) is named after my pretty daughter.
 *
 * @author Feng Dihai<fengdh@gmail.com>
 * @version 0.1.0 preview
 * @since  2014/10/01
 */
define(['jquery', 'ryn/utils'], function($, UTILS) {

    // internal variables

    var /* storage  */ widgets = {}, registry = [], descends = {},
        /* function */ getPath = function(tag) {},
                       debug = function(a) { console.error(a); },
        /*    alias */ $will = $.Deferred;

    // internal functions

    function _resolve(tag, $el, err) {
        var w = widgets[tag];
        if (!w) {
            w = widgets[tag] = $will();
        } else if (w.state() !== 'pending') {
            return;
        }
        var f = $will();
        w.resolve(f.promise({
            err:    function() { return err},
            define: function(r) { return f.resolve(r); },
            create: function( ) { return $el.clone(); } }));
    }

    function _scanner($loader, fn, tag) {
        return function whenDone(response, status, xhr) {
            if (status === 'error') {
                tag && (widgets[tag].err = true, debug('Undefined widget: ' + tag));
                _resolve(tag, $('<div class="na">ERROR</div>'), true);
            } else {
                var modules = [], found;
                if (registry.indexOf(fn) === -1) {
                    registry.push(fn);
                    $loader.find('*[data-merge]').each(function() {
                        var $this = $(this);
                        if ($this.is('script')) {
                            var m = $this.data('merge') || $this.attr('src');
                            m && modules.push(m);
                        } else {
                            $($this.parent().is('head') ? 'head' : 'body').append($this);
                        }
                    });
                }

                $loader.find('*[data-widget]').each(function(idx, el) {
                       var $el = $(el), datatag = $el.data('widget') + '';
                       _resolve(datatag, $el.contents());
                       found || (datatag === tag && (found = true));
                   });

                modules.length > 0 && require(modules);
                found || whenDone(response, 'error', xhr);
            }
        };
    }

    function _load(tag, resolver) {
        var fn = resolver(tag), $loader;
        if (fn) {
            $loader = $('<div>', {style: 'display: none;'});
            $loader.load(fn, _scanner($loader, fn, tag));
        } else {
            $loader = $('[data-role=module]');
            _scanner($loader, fn, tag)(null, 'ok', null);
        }
    }

    function _run(willDone, args) {
        return function($el, code) {
            try {
                $.isFunction(code) && code.apply($el, args);
                willDone.resolve($el);
            } catch (e) {
                willDone.reject('ERROR#2 occurred at #construct(..) caused by: \n\t' + e);
            }
        };
    }

    function _appendTo(target) {
        return this.done(function($el) { $el.appendTo($(target)); });
    }

    function _w(tag, f) {
        f.err && (debug('Undefined widget: ' + tag));
        return f.promise({
            tag: function() {return tag;},

            /**
             * Define how to construct widget instance.
             * Required to be called once and no more than once to enable #construct(..).
             *
             * @param func constructor function called right after creation of widget instance, can be empty.
             * @return self, the widget template.
             */
            define: function(func) { return this.done(function(wg) { wg.define(func); }); },

            /**
             * Create and setup widget instance.
             * Require to call #define(..) once and only once anywhere.
             *
             * @param argument(s) to be passed to constructor function if defined.
             * @return a promise to be resolved with value of widget instance wrapped as a jQuery selection.
             */
            construct: function() {
                    var willDone = $will(), args = UTILS.slice(arguments);
                    this.done(function(wg) {
                        wg.err() ? willDone.reject('ERROR#1 failed to load widget.')
                                 : $.when(wg.create(), wg).done(_run(willDone, args, wg)); });
                    return willDone.promise({ appendTo: _appendTo });
                }
        });
    }

    function _extend(tag, _super, defineDone, build) {
        var f = $will();
        return f.promise({
            tag:       function() { return tag; },
            define:    function(func) { _super.done(function(wg) { f.resolve(wg); defineDone.resolve(func); }); return this; },
            construct: build });
    }

    // public APIs

    /**
     * Refer to a widget which can be either lazy-resolved or an existed one (including inherited widget).
     *
     * @param tag id of widget
     * @param resolver optional, resource resolver for local use
     */
    function W(tag, resolver) {
        return descends[tag] || _w(tag, widgets[tag] || (widgets[tag] = $will(), _load(tag, resolver || getPath), widgets[tag]));
    }

    return $.extend(W, {
        /**
         * Assign a global path resolver to find HTML containing widget(s) definition.
         *
         * @param resolver function(tag)
         */
        resolveWith: function(resolver) { getPath = resolver; },

        /**
         * Extend an existed widget and inherit its behavior.
         *
         * @param fromTag id of existed widget as super
         * @param asTag id for inherited widget
         * @param resolver optional, resource resolver for local use
         */
        inherit: function(fromTag, asTag, resolver) {
            if (!descends[asTag]) {
                var defineDone = $will(), _super = W(fromTag, resolver);
                    buildAsChild = function build() {
                        var willDone = $will(), args = UTILS.slice(arguments);
                        $.when(_super.construct.apply(_super, args), defineDone).done(_run(willDone, args)).fail(function(wg) { willDone.reject(wg);});
                        return willDone.promise({appendTo: _appendTo });
                    };
                descends[asTag] = _extend(asTag, _super, defineDone,  buildAsChild);
            }
            return descends[asTag];
        },

        /**
         * Extend an existed widget and override its behavior completely.
         *
         * @param fromTag id of existed widget
         * @param asTag id for sibling widget
         * @param resolver optional, resource resolver for local use
         */
        sibling: function(fromTag, asTag, resolver) {
            if (!descends[asTag]) {
                var defineDone = $will(), _super = W(fromTag, resolver),
                    buildAsSibling = function() {
                        var willDone = $will(), args = UTILS.slice(arguments);
                        _super.done(function(wg) {
                            wg.err() ? willDone.reject('ERROR#1 failed to load widget.')
                                    : $.when(wg.create(), defineDone).done(_run(willDone, args, wg)); });
                        return willDone.promise({appendTo: _appendTo });
                    };
                descends[asTag] = _extend(asTag, _super, defineDone, buildAsSibling);
            }
            return descends[asTag];
        },

        /**
         * Scan HTML to preload all defined widgets in an asynchronous way.
         *
         * @param path(s) of widget definition HTML.
         */
        scan: function() {
            var $loader = $('<div>', {style: 'display: none;'});
            UTILS.slice(arguments).forEach(function(fn) { $loader.load(fn, _scanner($loader, fn)); });
        }
    });

});