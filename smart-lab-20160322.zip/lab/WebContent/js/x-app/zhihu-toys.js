require(['jquery', 'ryn/ui.widget'], function($, widget) {

});
