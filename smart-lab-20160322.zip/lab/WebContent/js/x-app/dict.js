
require(['jquery', 'jquery.transit', 'ryn/ui.notify'], function($, $Transit, NC) {


    $(function() {
        NC.post('StarDict Project: launching...');

        var noti = NC.shout("HI");
        console.log(noti);

        noti.after('hidden').done(function(trigger) {console.log('triggered by = ' + trigger);});
        $('#chooseDictFile').on('change', function(e) {
            var blobUrl = window.URL.createObjectURL($(e.target)[0].files[0]);
//            NC.post(blobUrl);


        });
    });

});
