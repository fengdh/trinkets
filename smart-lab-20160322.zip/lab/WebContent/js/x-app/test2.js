
require(['jquery', 'jquery.transit', 'ryn/remote', 'ryn/ui.notify', 'ryn/ui.databind', 'ryn/utils', 'ryn/ui.touch'], function($, $Transit, Remote, NC, bind, UTILS, TouchSupport) {


    $(function() {

        TouchSupport.debug(true);

        function $$(tag, attrs) {
            var el= document.createElementNS('http://www.w3.org/2000/svg', tag);
            for (var k in attrs)
                el.setAttribute(k, attrs[k]);
            return $(el);
        }

        $('div.box').on('touchstart.trace', '.swipe', {type: 'single', raw: true}, true);

        $('div.box').on('longtap click dblclick', '.block', function(e, fact) {
            console.log('original event? ', e.originalEvent);
            var tg = fact.target();
            s = tg.tagName + '#' + tg.id + (tg['class'] ? '.' + tg['class'] + ' > ' : '');
            NC.shout(e.type + ' event processed!' + '\r\ntouch count = ' + fact.touchCount()
                    + '\r\n' + s);
        });

        $('div').on('click', '.brick', function(e) {
            NC.shout(e.type + ' event processed!');
        });

//        $('div.box').off('dblclick');

        $('div.swipe').on('touchmove', {multitouch: false}, function(e, fact) {
            console.log('original event? ', e.originalEvent);
            console.log(e.type + ' on target', e);

            console.log($(":hover" ));

            var extent = fact.extent();
            if (extent) {

                if (fact.touchCount() > 1) {
                    $(e.target).transition({x: extent.offset.x, y: extent.offset.y}, 0);
                } else {
                    $(e.target).transition({x: extent.offset.x}, 0);
                }
                console.log(extent);
            }
        }).on('touchend', function(e, fact) {
            var target = fact.target();
            console.log('original event? ', e.originalEvent);
            if (fact.isFlick(e.timeStamp)) {
                var motion = fact.motion();
                if (motion.h === 'right') {
                    $(target).transition({x: '+=200%', opacity: 0}, 200);
                } else if (motion.v === 'up') {
                    $(target).transition({y: '-=200%', opacity: 0}, 200);
                } else {
                    $(target).transition({x: 0, y: 0, opacity: ''});
                }
                $(target).transition({x: 0, y: 0, opacity: '', delay: 1000}, 100);
            } else {
                $(target).transition({x: 0, y: 0, opacity: ''});
            }
        });

        $('div.brick')[0].addEventListener('touchmove', function(e) {
            console.log('brick: ', e);
        });

        var $svg = $('svg#debug-trace').empty(), color;
        var COLORS = ['#D28', '#19C', '#00F', '#CC0', '#0FA',
                      '#0F0', '#0FF', '#C0C', '#83C', '#111'];

        $._draw_trace = function(id, path, option) {
            var $g, $p, $c;
            if (typeof id === 'undefined') {
                $svg.empty();
                color = 0;
                return;
            }
            id += '';

            var isCtrl = option === true;
            if (isCtrl) {
                $svg.find('g#_temp_' + id).remove();
                id = 'CTRL_' + id;
            } else {
                if (option === false) {
                    isCtrl = true;
                    id = 'temp_' + id;
                }
            }

            $g = $svg.find('g#_' + id);
            if ($g.length === 0) {
                $g = $$('g', {stroke: COLORS[color++], fill: 'none', 'stroke-width': 1.5}).attr('id', '_' + id).appendTo($svg);
            } else {
                $g.empty();
            }
            $p = $$('path').appendTo($g);

            var i = 0, len = path.length;
            if (len === 2) {
                path = [path[0], path[1], path[0], 2 * path[1]];
            }
            if (len > 2) {
                var s = ['M', path[0], path[1]];
                $c = $$('circle', {cx: path[i], cy: path[i + 1]});
                if (isCtrl) {
                    $c.attr({r: 6, stroke: 'red', fill: 'black'});
                } else {
                    $c.clone().attr({r: 20, 'stroke-dasharray': '10 4', stroke: 'rgba(200,0,0,0.45)', fill: 'rgba(200,0,0,0.25)'}).appendTo($g);
                    $c.attr({r: 2, stroke: 'black', fill: 'white', 'stroke-width': 1});
                }
                $c.appendTo($g);
                (id.substr(0, 4) === 'move' || isCtrl) && $p.attr('stroke', '#222').attr('stroke-width', 1);

                for (i = 2; i < len; i += 2) {
                    s.push('L', path[i], path[i+1]);
                    $c = $$('circle', {cx: path[i], cy: path[i + 1]});
                    if (isCtrl) {
                        $c.attr({r: 6, fill: 'red', stroke: 'black'});
                    } else {
                        $c.attr({r: 3, stroke: 'red', fill: 'white', 'stroke-width': 0.5});
                    }
                    $c.appendTo($g);
                }
                $p.attr('d', s.join(' '));
            }
        };

    });

});
