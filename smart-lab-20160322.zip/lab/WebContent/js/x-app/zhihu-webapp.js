    var today = new Date();
    $('#date-day').contents()[0].nodeValue = today.getDate();
    $('#date-ym').text(today.getFullYear() + '年' + (today.getMonth() + 1) + '月');
    $('#cell-bar').animate({'opacity': 1}, 700);

require(['jquery.transit', 'jquery.color', 'd3', 'ryn/ui', 'ryn/ui.touch', 'ryn/ui.widget', 'ryn/ui.notify'], function($Transit, $Color, d3, UI, Touch, widget, NC) {
    // http://www.henryalgus.com/reading-binary-files-using-jquery-ajax/
    // use this transport for "binary" data type
    $.ajaxTransport("blob", function(options, originalOptions, jqXHR){
        // check for conditions and support for blob / arraybuffer response type
        if (window.FormData && ((options.dataType && (options.dataType == 'blob')) || (options.data && ((window.ArrayBuffer && options.data instanceof ArrayBuffer) || (window.Blob && options.data instanceof Blob))))) {
            return {
                // create new XMLHttpRequest
                send: function(_, callback) {
                    // setup all variables
                    var xhr = new XMLHttpRequest(), url = options.url, type = options.type,
                        // blob or arraybuffer. Default is blob
                        dataType = options.responseType || "blob",
                        data = options.data || null;


                    xhr.addEventListener('load', function() {
                        var data = {};
                        data[options.dataType] = xhr.response;
                        // make callback and send data
//                        callback(xhr.status, xhr.statusText, data, xhr.getAllResponseHeaders());
                        if (xhr.status == 502 && data) {
                            var r = new FileReader();
                            r.readAsBinaryString(data.blob);
                            r.onload = function() {
                                data = JSON.parse(r.result).error;
                                console.log('len', data.length);
                                data = toab(data);
                                var blob = new Blob([data], {type: 'image'});
                                data[options.dataType] = data;
                                callback(200, 'ok', data, xhr.getAllResponseHeaders());
                            }
                        } else {
                            callback(xhr.status, xhr.statusText, data, xhr.getAllResponseHeaders());
                        }
                    });

                    xhr.open(type, url, true);
                    xhr.responseType = dataType;
                    xhr.send(data);
                },
                abort: function() { jqXHR.abort(); }
            };
        }
    });

    function color_sampling(url, vw, vh, blocs){
        var d = $.Deferred(),
            img = new Image();

        img.onload = function() {
            var w = img.width, h = img.height, sw = vw / w, sh = vh /h, dx = 0, dy = 0;
            sw > sh
                ? dy = Math.round((vh - (vh = Math.round(h * sw))) / 2)
                : dx = Math.round((vw - (vw = Math.round(w * sh))) / 2);

            console.log(w, h, vw, vh, dx, dy);

            var canvas = document.createElement('canvas');
            canvas.width = vw;
            canvas.height = vh;

            var context = canvas.getContext('2d'), data;
            context.drawImage(img, 0, 0, w, h, dx, dy, vw, vh);


            context.drawImage(canvas, 0, 0, w + 2 * dx, h + 2 * dy, w + 1, h + 1, 1, 1);
            data = context.getImageData(w + 1, h + 1, 1, 1).data;
            var colors = { '#avg': data.subarray(0, 3)};

            for (var k in blocs) {
                var arr = blocs[k];
                var bx = arr[0] * vw, by = arr[1] * vh,
                bw = arr[2] * vw, bh = arr[3] * vh;
                context.drawImage(canvas, bx, by, bw, bh, w + 1, h + 1, 1, 1);
                data = context.getImageData(w + 1, h + 1, 1, 1).data;
                colors[k] = data.subarray(0, 3);
                colors[k].lightness = $.Color.apply(this, colors[k]).lightness();
            }

            d.resolve(colors);
            console.log(colors);
        };

//        img.crossOrigin = "anonymous";
        img.src = url;
        return d;
      };

    function yql(source, url) {
        return { url: 'http://query.yahooapis.com/v1/public/yql',
                 data: {format: 'json', q: 'select * from ' + source + ' where url="' + url + '"'}};
    }

    function exec(url) {
        url = 'http://techblogcorner.com/wp-content/uploads/2014/09/jpeg.jpg';
        return  {
            url: 'http://query.yahooapis.com/v1/public/yql',
            data: {
                format: 'json',
                q: 'select * from execute where code="' + "var url='" + url
                    + "', req = y.rest(url).accept('image').header('Accept-Encoding', 'gzip,deflate').decompress(true);"
                    + 'var resp = req.get(); response.object= {req: req.headers, resp: resp};"',
                env: 'store://datatables.org/alltableswithkeys'
            }
        };
    }

    function rawStringToBuffer( str ) {
        var idx, len = str.length, arr = new Array( len );
        for ( idx = 0 ; idx < len ; ++idx ) {
            arr[ idx ] = str.charCodeAt(idx) & 0xFF;
        }
        // You may create an ArrayBuffer from a standard array (of values) as follows:
        return new Uint8Array( arr ).buffer;
    }

    function toab(str) {
        var len = str.length, bytes = new Uint8Array(len);
        for (var i = 0; i<len; i++)
            bytes[i] = str.charCodeAt(i) & 0xFF;
        return bytes;
    }

    $(function() {
        $('#cell-header').transit({y: -16}, 9000);
//        var url = 'http://jsonp.nodejitsu.com/?ts=' + today.getTime() + '&url=' + 'http://news-at.zhihu.com/api/3/news/latest';
//        url = 'http://www.corsproxy.com/news-at.zhihu.com/api/3/news/latest';

        $.ajax(yql('json', 'http://news-at.zhihu.com/api/3/news/latest'))
         .done(function(r) {
             console.log(r);
             r = r.query.results.json;
             var $topics = d3.select('#topics');
//             $topics.selectAll().data(r.top_stories)
//                     .enter()
//                     .append('div')
//                     .text(function(d) {return d.title;});

             var n = Math.floor(Math.random() * (r.top_stories.length + 0));

//             $.ajax('http://jsonp.nodejitsu.com/?ts=' + today.getTime() + '&url=' + r.top_stories[n].image, {dataType: 'blob'})
//              .always(function(e) {
//                  console.log(e);
//                  var blob = new Blob([e], {type: 'image/jpeg'}), blobUrl = window.URL.createObjectURL(blob);
//
//
//              $('#cell-main')
//                  .css('background-image', 'url(' + blobUrl + ')')
//                  .find('.mask').css('opacity', 0);
//
//              });
//return;
//             $.ajax(r.top_stories[n].image + '?rss', {dataType: 'blob'})
             $.ajax(exec(r.top_stories[n].image))
              .done(function(data, _, jqxhr) {
                 console.log('data', data);
                 data = data.query.results.result;
                 data = data.resp.response;
                 console.log(data.length);
                 data = toab(data);

                 console.log(data);
                 var blob = new Blob([data], {type: 'image/jpeg'}),
                     blobUrl = window.URL.createObjectURL(blob);


                 $('#cell-main')
                     .css('background-image', 'url(' + blobUrl + ')')
                     .find('.mask').css('opacity', 0);

                 var vw = $('#cell-main').outerWidth(), vh = $('#cell-main').outerHeight();
                 var blocs = {
                    T: [0.28, 0.078, 0.72, 0.13],
                    A: [0.5,0.2, 0.5, 0.5],
                    B: [0.5, 0.2, 0.5, 0.5],
                    C: [0.0, 0.6, 0.5, 0.5],
                    D: [0.5, 0.6, 0.5, 0.5],
                    L: [0.0,  0.21, 0.33, 0.79],
                    M: [0.33, 0.21, 0.33, 0.55],
                    R: [0.67, 0.21, 0.33, 0.79]
                 };
                 color_sampling(blobUrl, vw, vh, blocs).done(function(colors) {
                     var l = colors.T.lightness;
                     if (l > 0.3 && l < 0.8) {
                         $('#subtitle, #date-day').transit({color: '#FFF'}, 5000);
                         $('#cell-bar').transit({'background-color': 'rgba(50,50,50,0.3)'}, 5000);
                     } else if (l < 0.3) {
                         $('#subtitle, #date-day').transit({color: '#FFF'}, 5000);
                     } else {
                         $('#subtitle, #date-day').transit({color: '#000'}, 5000);
                     }
                 });
             }).fail(function(e) {
                 console.log(e);
             });
 //*/
         });
});

});


