/**
 * release version
 *
 * NOTE:
 *  - BUGFIX: jquery.mobile-1.4.2.js #10391-10393
 *            http://stackoverflow.com/questions/5657371/ie9-window-loses-focus-due-to-jquery-mobile
 */
var DISTANT = 50;

var require = {
        // TODO: 暫定、Offline Webを利用すべき
        waitSeconds: 0,
        baseUrl: '../js',

        paths: {
                 'app'            	: 'app',
                 'ryn'            	: 'ryn',
                 'data'           	: 'data',
                 'dev'            	: 'dev',
                 'api'            	: '../remoting/ryn/api',

                 'accounting'     	: 'accounting.min',
                 'jquery'         	: 'jquery-1.11.1.min',
                 'jquery.color'		: 'jquery.color-2.1.2.min',
                 'jquery.notyfy'  	: 'jquery.notyfy',
                 'jquery.opentip' 	: 'opentip-jquery.min',
                 'jquery.transit' 	: 'jquery.transit.min',
                 'text'			  	: 'text'
             },
        map: {'*' : {
                 'ryn/app'		   : 'ryn/ryn.app',
                 'ryn/geometry'	   : 'ryn/ryn.geometry',
                 'ryn/utils'       : 'ryn/ryn.utils',
                 'ryn/remote'      : 'ryn/ryn.remote',
                 'ryn/ui'          : 'ryn/ryn.ui',
                 'ryn/ui.grid'     : 'ryn/ryn.ui.grid',
                 'ryn/ui.databind' : 'ryn/ryn.ui.databind',
                 'ryn/ui.jqm'      : 'ryn/ryn.ui.jqm',
                 'ryn/ui.notify'   : 'ryn/ryn.ui.notify',
                 'ryn/ui.pulldown' : 'ryn/ryn.ui.pulldown',
                 'ryn/ui.touch'    : 'ryn/ryn.ui.touch',
                 'ryn/ui.widget'   : 'ryn/ryn.ui.widget',
             }
        },

        shim: {
            'jquery.color'     : {deps: ['jquery']},
            'jquery.resize'	   : {deps: ['jquery']},
            'jquery.notyfy'	   : {deps: ['jquery']},
            'jquery.opentip'   : {deps: ['jquery']},
            'jquery.transit'   : {deps: ['jquery']},
            'ryn/ryn.ui.grid'  : {deps: ['jquery.resize', 'jquery.color']}
        }
};

var Ryn = {
      App: {},
      Remote: {
          options: {
                  toSpecUrl: function(ids) { return 'api/' + ids + '/spec';}
          }
      },
      Notify: {
        assembleMore: function(args) {
          args[0] = ['<b>', args[0], '</b>:<br>'].join('');
          return args.join('');
        },
        neterr: function(resource) {
          this.shout({id: 'F', text: "ネットワーク・エラー: " + resource});
        }

      }
};

Ryn.App.name = 'TOROKUN';
Ryn.App.ver = 'Ver. 0.0.1-20140602';
