
require(['jquery', 'jquery.transit', 'selectize', 'jquery.clock', 'ryn/utils', 'ryn/ui', 'ryn/ui.notify', 'ryn/ui.touch'],
        function($, $Transit, $SELECTIZE, $CLOCK, UTILS, UI, NC) {

  function repeat($host, $tmp, count, op) {
        $host = $($host);
        $tmp =  $($tmp).contents();
        op = op || function(e) {return e;};
        $host.each(function() {
            var i, $frag = $(document.createDocumentFragment());
            for (i = 0; i < count; i++) {
                $frag.append(op($tmp.clone()));
            }

            $(this).replaceWith($frag);

        });
    }

    function stopPropagationInside(e, target) {
        var target = target || e.target;
        if (e.target === elementUnderTouch(e)) {
            e.stopPropagation();
        }
    }

    function canSwipeClear(e, fact, flick) {
        return !(flick ^ fact.isFlick())
                    && fact.motion().h === 'right'
                    && ($('field .selectize-input.dropdown-active').length + $('.clockpicker-popover:visible').length) === 0;
    }

    function clearEffect(target, clear /* is a function */) {
        return function() {
            target = $(target).transition({opacity: 0, x: '+=100'}, function() {
                clear();
                target.css({opacity: 'initial', x: '-=100'});
            });
        };
    }

    function elementUnderTouch(e) {
        var t = e.originalEvent.changedTouches[0];
        return document.elementFromPoint(t.clientX, t.clientY);
    }


    $(function() {
        $('.overlay-viewport').appendTo(document.body);

        var page = 0, i = 0, WD = '日月火水木金土', dayone = new Date('2015/5/1');

        var wstart = dayone.getDay() + 1, w;
        i = 2;
        var fillday = function ($r) {
            w = (wstart + i++ - 1) % 7;
            $r.children()
              .eq(0).text(WD[w]).end()
              .eq(1).text(i);
            if (w == 0 || w == 6) { $r.addClass('holiday');}
            return $r;
        };

        repeat('#host-day-entry', '#day-entry', 31 - 2, fillday);

        $('#timesheet .sheet > div')
            .eq(4).addClass('wait').end()
            .eq(5).addClass('accept');


        (function _setup_dot() {
            var $dot = $('#menu-timecard'), $touched;

            $dot.click(function() {
                switch (page) {
                case 0:
                    page = 1;
                    $('#activities').transition({y: '-100%'});
                    $('#timesheet').transition({y: '-100%'});
                    $dot.attr('data-mark', '\ue683').transition({rotate: '360deg'});
                    $('#dynamic').transition({'-webkit-opacity': "1"});
                    break;
                default:
                    page = 0;
                    $('#activities').transition({y: '0'});
                    $('#timesheet').transition({y: '0'});
                    $dot.attr('data-mark', '\ue66b').transition({rotate: '0deg'});;
                    $('#dynamic').transition({'-webkit-opacity': "0"});
                    break;
                }

                $('#top').toggleClass('p2');
            }).on('touchstart', function() {
                if (page === 0) {
                    var eyed, keep = {attr: $dot.attr('data-mark'),
                            css: {background: '',
                                  'box-shadow': $dot.css('box-shadow')}};
                    $dot.on('touchmove.DOT longtap.DOT', function(e, fact) {
                        if (e.type[0] === 't') {
                            if (!fact.isOutofTapBox()) {
                                return;
                            }
                        }
                        eyed = true;
                        $dot.attr('data-mark', '\ue63e').css({background: '#444', 'box-shadow' : '40px 0px 3px -16px rgba(0,0,0,0.4)'});
                        var offset = fact.motion().extent.offset;
                        $dot.css('transform', 'translate(' + (offset.x - 60) + 'px,' + offset.y + 'px), scale(1.5)');
                        if (e.type === 'touchmove') {
                            $touched = $(elementUnderTouch(e)).closest('.section').addClass('floatup');
                            $('#content .section').not($touched).removeClass('floatup');
                        }
                    }).on('touchend.DOT', function() {
                        $dot.off('.DOT');

                        if (!eyed) return;


                        $dot.transition({x: 0, y: 0, scale: 1}, function() {
                                $dot.attr('data-mark', keep.attr).css(keep.css);
                        });
                        $('#content .section').removeClass('floatup');
                        if ($touched && $touched.length !== 0) {
                            var msg;
                            switch ($touched.attr('id')) {
                                case 'projects': msg = '取込中ＰＪ管理画面を開きます。';  break;
                                case'approvals': msg = '承認管理画面を開きます。';  break;
                                case'applicants': msg = '申請管理画面を開きます。';  break;
                            }
                            NC.shout('I', '【未実装】' + msg);
                        }
                        $touched = null;
                    });
                }
            })
            ;//.click();

        })(/* scope call */);
        repeat('#host-regular-entry', '#time-entry', 7);
        repeat('#host-overwork-entry', '#time-entry', 5);

        var $body = $(document.body);

        (function _setup_timesheet() {
            var $selected, $sheet = $('#timesheet .sheet'), batchOpened;

            function flipLeft($e) {
                $e.transit({perspective: 1000, x: '29em', z: 0, rotateY: '-60deg', duration: 0})
                   // .transit({x: 20, z: -5, rotateY: '5deg', duration: 300})
                   .transit({x: 0, z: 0, rotateY: 0, duration: 200});
            }
            function edit($this) {
                if ($this) {
                    flipLeft($('#daily'));
                    $selected = $this;
                    $this.toggleClass('selected', true);
                    $body.toggleClass('edit', true);
                    $('#cell-menu').transition({x: 100});

                } else {
                    $('#daily').transition({x: '29em'});
                    $selected = undefined;
                    $sheet.find('.selected').toggleClass('selected', false);
                    $body.toggleClass('edit', false);
                    $('#cell-menu').transition({x: 0});
                }
            }

            function batch(open) {
                if (batchOpened != open) {
                    if (open) {
                        flipLeft($('#batch'));
                        $('#cell-menu').transition({x: 100});
                    } else {
                        $('#batch').transition({x: '29em', duration: 300});
                        $('#cell-menu').transition({x: 0});
                        $sheet.children('.checked').removeClass('checked');
                    }
                    batchOpened = open;
                    $body.toggleClass('batch', open);
                }
            }

            var edit_close = edit.bind(null, null);

            $sheet.on('touchstart', 'div', function(e) {
            });
            $sheet.on('click', 'div', function(e) {
                if (!$selected && !batchOpened) {
                    var $target = $(e.target);
                    switch ($target.index()) {
                        case 0:
                        case 1:
                            return;
                        case 2:
                        case 3:
                        case 4:
                            edit($(this));
                            break;
                        case 5:
                        case 6:
                        case 7:
                            NC.shout('【未実装】時間外申請を処理します。')
                            break;
                        default: /* 8, 9, 10 */
                            NC.shout('【未実装】休暇申請を処理します。')
                            break;
                    }
                    $('#timesheet .sheet > div.checked').removeClass('checked');
                }
            }).on('touchstart', 'div', function(e) {
                if (!$selected) {
                    var $all = $sheet.children('div'),
                        startAt = $(e.target).parent().index();
                    switch ($(e.target).index()) {
                        case 0:
                        case 1:
                            $(e.target).parent().toggleClass('checked');
                            var $current = $sheet.children('.checked');
                            $sheet.on('touchmove.CHECK', function(e) {
                                var $div = $(elementUnderTouch(e)).closest('#timesheet .sheet > div');
                                if ($div.length) {
                                    var idx = $div.index(),
                                        $list = startAt < idx ? $all.slice(startAt + 1, idx + 1) : $all.slice(idx, startAt);
                                    if ($list.length > 0) {
                                        $list.each(function() {
                                            $(this).toggleClass('checked', $current.filter(this).length === 0);
                                        });
                                    }
                                }
                            }).on('touchend.CHECK', function(e) {
                                $sheet.off('.CHECK');
                                batch( $sheet.children('.checked').length > 0);
                            });
                            break;
                    }
                }
            });
            $('#op_daily_close').on('click', edit_close);
            $sheet.on('click', 'div.selected', edit_close);


            $('#timesheet').on('touchend', function(e, fact) {
                if (canSwipeClear(e, fact, true)) {
                    if ($selected) {
                        edit_close();
                    } else {
                        batch(false);
                    }
                }
            });

            $('#daily').on('touchend', '.time-entry', function(e, fact) {
                if (!fact.isFlick(e.timeStamp) && fact.motion().h === 'right') {
                    $(this).find('field[data-option]').each(function() {
                        var $this = $(this);
                        if ($this.data('option') === '#time') {
                            clearEffect($this.children(), function() {$this.children('span').text('').removeProp('value');}).call();

                        } else {
                            var target = $this.children('span');
                            clearEffect(target, target[0].selectize.clear.bind(target[0].selectize, true)).call();
                        }
                        e.preventDefault();
                    });

                }
            });

            $('#daily').on('touchend', '[data-option=#time]', function(e, fact) {
                if (canSwipeClear(e, fact)) {
                    var $this = $(this);
                    clearEffect($this.children(), function() {$this.children('span').text('').removeProp('value');}).call();
                    e.preventDefault();
                    stopPropagationInside(e);
                }
            });

            $(document.body).on('touchstart', '[data-hint]', function() {
                $('#huge-hint').html($(this).data('hint'));
            }).on('touchmove', function(e) {
                var $touched = $(elementUnderTouch(e)).closest('[data-hint]');
                $('#huge-hint').html($touched.length !== 0 ? $touched.data('hint') : '');
            }).on('touchend', function() {
                $('#huge-hint').empty();
            });

            $('#batch .btn').on('click', function(e) {
                var $self = $(this);
                $self.transition({x: "300%", opacity: 0}, 300, 'easeInBack', function() {
                    $self.css({x: 0}).transition({opacity: 1, delay: 1000});
                });
            }).on('touchend', function(e) {
                e.stopPropagation();
                e.preventDefault();
            });
        })();


//        $('#projects .list .pj').attr('data-hint', '取込中PJ（3件まで）の概要を表示します');
//        $('#approvals').attr('data-hint', '<UL>承認依頼を表示します<LI>【未実装】 タップで詳細を表示して承認を行う');
//        $('#applicants').attr('data-hint', '<UL>自分が直近提出した申請を表示します。<LI>【未実装】コンテキスト・メニューで「詳細表示・閲覧済み」を行う');

        (function _swipe_clear_selectize_plugin(){
            $SELECTIZE.define('swipe_clear', function(options) {
                var original = this.setup;
                // override the setup method to add an extra "click" handler
                this.setup = (function() {
                    return function() {
                        original.apply(this, arguments);
                        var clearFunc = this.settings.clearFunc || clearEffect(this.$control, this.clear.bind(this, true));
                        if ($.isFunction(clearFunc)) {
                            clearFunc = clearFunc.bind(this);
                            this.$control.parent().on('touchstart touchmove').on('touchend', function(e, fact) {
                                if (canSwipeClear(e, fact)) {
                                    e.preventDefault();
                                    stopPropagationInside(e);
                                    clearFunc.call();
                                }
                            });
                        }
                    };
                })();

            });
        })(/* scope call */);

        (function _setup_select_list(){
            $('[data-option=#daytype] > :first-child').selectize({
                dropdownParent: 'body',
                maxItems: 1,
                highlight: false,
                options: [
                  {value: '1', text: '通常出勤'},
                  {value: '2', text: '公休日'},
                  {value: '3', text: '有給休暇'}
                ],
                render: {
                  item: function(item, escape) {
                      return '<div>' + escape(item.text) + '</div>';
                  },
                  option: function(item, escape) {
                      return '<div>' + escape(item.text) + '</div>';
                  }
                },
                plugins: ['swipe_clear'],
            });


            $('[data-option=#memo] > :first-child').selectize({
                dropdownParent: 'body',
                maxItems: 1,
                highlight: false,
                placeholder: '直接入力または選択',
                plugins: ['restore_on_backspace', 'swipe_clear'],
                options: [
                  {value: '1', text: '私用'},
                  {value: '2', text: '体調不良'},
                  {value: '3', text: '客先休業'},
                  {value: '4', text: '冠婚葬祭'},
                  {value: '5', text: '宗教義務'},
                  {value: '6', text: '国民義務'},
                ],
                render: {
                  item: function(item, escape) {
                      return '<div>' + escape(item.text) + '</div>';
                  },
                  option: function(item, escape) {
                      return '<div>' + escape(item.text) + '</div>';
                  }
                },
                create: function(input) {
                    return {text: input, value: input};
                }
            });

            $('[data-option=#pj] > :first-child').selectize({
                dropdownParent: 'body',
                maxItems: 1,
                highlight: false,
                sortField: 'value',
                options: [
                  {value: 'C1339485', text: 'Ｃ社システム'},
                  {value: 'A0138474', text: 'Ａ社システム'},
                  {value: 'B1388021', text: 'Ｂ社システム'},
                  {value: '@991', text: '社内会議'},
                  {value: '@992', text: '社内研修'},
                  {value: '@993', text: '営業支援'},
                  {value: '　', text: '検索...'},
                ],
                render: {
                  item: function(item, escape) {
                      return '<div>' + escape(item.value) + '</div>';
                  },
                  option: function(item, escape) {
                      if (item.value !== '　') {
                          return '<div>' +
                          '<span class="pj-code">' + item.value + "</span>" + " <span>" + escape(item.text) + '</span>' + '</div>';
                      } else {
                          return '<div style="font-style:italic; color: yellow;">PJを検索する...</div>';
                      }
                  }
                },
                create: function(input) {
                    return {text: input, value: input};
                },
                positionFunc: function() {
                    var $control = this.$control;
                    var offset = $control.offset();
                    offset.top += $control.outerHeight(true);
                    var w = $control.outerWidth();

                    this.$dropdown.css({
                        width : 2 * w , //$control.outerWidth(),
                        top   : offset.top - window.scrollY,
                        left  : offset.left - w
                    });

                },
                plugins: ['swipe_clear'],
            });


            $('[data-option=#time] > span').clockpicker({
                'default': 'now',
                autoclose: true,
                afterDone: function() {
                    this.element.text(this.element.prop('value'));
                }});


        })(/* scope call */);

    });

}, function(err) { alert(err);});
