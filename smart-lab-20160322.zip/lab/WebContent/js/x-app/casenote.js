
require(['jquery', 'jquery.transit', 'ryn/remote', 'ryn/ui.notify', 'ryn/ui.databind', 'ryn/utils', 'ryn/ui.widget', 'ryn/ui.touch'], function($, $Transit, Remote, NC, bind, UTILS, W) {

    W.resolveWith(
        function getFileName(tag) {
            return 'widgets.html';
        }
    );
  
    // -------------------------------------------
    var BINDTO = {
            name: ':tag(name)',
            contractor: ':tag(contractor)',
            addr: ':tag(addr)',
            floor: ':tag(floor)',
            tag: ':tag(tag)'};


    $(function() {
        $('#tagfilter span').slice(2).addClass('na');
        function init(user) {
            require(['ryn/ui.databind', 'data/data'], function(bind, DATA){
                userData = DATA;
//                W('case').done(function($w) {
//                    console.log('TEST:', $('<div>').append($w.create()).html());
//                  });
//
//                W('note').done(function($w) {
//                    console.log('TEST:', $('<div>').append($w.create()).html());
//                });

//                W('case');

                userData.forEach(function(v) {
                    var tag = v.tag;
                    $tagfilter.filter(function(idx, el) {
                        if ($(el).text() === tag) {
                            $(el).removeClass('na');
                        }
                    });
                });

                $tagfilter.first().click();
            });
        }

        function updateCaseItem($case, data) {
            if ($case.length === 0) {
                return;
            }
            $case.data('data', data);
            bind($case, data, BINDTO);

            if (data.status === 1) {
                $case.find(':tag(status)').val('★');
            } else if (data.status === 2) {
                $case.find(':tag(status)').val('★★');
            } else {
                $case.find(':tag(status)').val('');
            }
        }

        W.scan('widgets.html');

        var $container = $(document.createDocumentFragment());

        function show(arr) {
/*
            W('case').done(function(w) {
                var i, $case, $container = $(document.createDocumentFragment());
                for (i = 0; i < arr.length; i++) {
                    $case = w.create().addClass('case');
                    updateCaseItem($case, arr[i]);
                    $case.appendTo($container);
                }
                $container.appendTo($('#list').empty());
            });
//*/
//*
            var i,  all = [], caseWidget = W('case.two');
            for (i = 0; i < arr.length; i++) {
                var data = arr[i];
                all.push(caseWidget.construct(arr[i], updateCaseItem)
                                     .done(function($el) { $el.addClass('case').appendTo($container); }));
            }

            $.when.apply(null, all).done(function() {
                $container.appendTo($('#list').empty());
            }).fail(function() {console.log('failed!')});
//*/
        }


//        init({id: 'ankenkoji', name: '安間孝二'});


        $('.smokeglass').fadeOut();
        $('.smokegalss').remove();

        var $uid = $('#uid'), $pwd = $('#pwd'), $login = $('#go'), $clear = $('#clear');

        function doLogin() {
            var uid = $uid.val(), pwd = $pwd.val();
            if (!uid) {
                NC.shout("ユーザIDを入力してください。");
            } else if (!pwd) {
                NC.shout("パスワードを入力してください。");
            } else {
                $uid.blur();
                $pwd.blur();
                var notyfy = NC.post("認証中、しばらくお待ちください...");

                init({id: 'ankenkoji', name: '安間孝二'});
                var leftShift = {x: '-100%'};
                $('#cell-main').css({display: 'block'}).transit(leftShift);//, init.bind({uid: 'ankenkoji', name: '安間孝二'}));
                $('#login').parent().transit(leftShift);

                notyfy.close();
            }
        };

        function doClear() {
            $uid.val(""); $pwd.val("");
        }

        function motion($e) {
            var textColor = $e.css('color');
            var timer;

            var fadeText = function() {
                clearTimeout(timer);
                $e.css({color: textColor});
            },
            hilight = function() {
                $e.css({color: '#111'});
                clearTimeout(timer);
                timer = setTimeout(fadeText, 1500);
            },
            autoNext = function(e) {
                if (e.keyCode === 13) {    // ENTER key
                    if (this.id === 'pwd') {
                        if (this.value) {
                            doLogin();
                        }
                    } else {
                        $pwd.focus();
                    }
                }
                setTimeout(function() {
                    if ($uid.val().trim().length > 0 && $pwd.val().trim().length > 0) {
                        $login.addClass('active');
                    } else {
                        $login.removeClass('active');
                    }
                },100);
            };

            $e.keypress(hilight).focusin(hilight)
              .focusout(fadeText)
              .keydown(autoNext);
        }

        // setup animation
        motion($uid);
        motion($pwd);

        // setup login action
        $login.click(doLogin);

        // setup clear action
        $clear.click(doClear);

        // init focus
//        $uid.focus().select();


        $('#exit').click(function() {
            $('#login').parent().transit({x: '0%'});
            $('#cell-main').transit({x: '0'}, function() {$('#cell-main').css({display: 'none'});});

        });

        var $left = $('#left'), $list = $('#list'), $view = $('#view'), $note = $('#note'),
            $quicktag = $('#quicktag > span'), $tagfilter = $('#tagfilter > span');

        $view.on('click', '#content *', function() {
            console.log(this.id);
            if ($(this).closest('.dumb').length > 0) {
                return;
            } else if (!$view.hasClass('edit')) {
                $view.addClass('edit')
                     .find('item:not([data-tag=type]) value, [data-tag=type-other], #more .editable').editable('true');
            }
        });

        $('#cancel, #save').on('click', function(e) {
            $view.removeClass('edit');
            $view.find('[contenteditable]').editable(false);

            if ($('.case.edit').length === 0) {
                $view.addClass('blank');
            }

            // force mobile safari to repaint => dashed bottom border missing problem
            $('item value, #more > div').transition({x: 0});

            var $case = $('.case.edit');
            updateCaseItem($case, $case.data('data'));
            e.stopPropagation();
        });

        $note.bindWith = function(data) {
            var found,
                options =
                    $note.find('item:tag(type) > .flags span')
                         .removeClass('on')
                         .each(function() {
                             var $el = $(this);
                             if ($el.text() === data.type) {
                                 $el.text(data.type).addClass('on');
                                 found = true;
                                 return false;
                             }
                         });
            if (!found && data.tag) {
                $note.find('item:tag(type)').find('.flags span:last-child').addClass('on');
                $note.find(':tag(type-other)').text(data.type);
            } else {
                $note.find(':tag(type-other)').text('');
            }

            $('#slides').empty();
            $quicktag
                 .removeClass('on')
                 .each(function() {
                     var $el = $(this);
                     if ($el.text() === data.tag) {
                         $el.toggleClass('on', true);
                         return false;
                     }
                 });
            return true;
        }

        function showNote(caseData) {
            bind($note, caseData, BINDTO);
            $view.removeClass('status-2').removeClass('status-1');
            switch (caseData.status) {
                case 2:
                    $view.addClass('status-2');
                    // continue;
                case 1:
                    $view.addClass('status-1');
                    break;
            }
        }

        function fillClientNames(base) {
            var buf = UTILS.buffer('<option>'), cn = base;
            cn = cn ? base.replace(/(^.*)邸.*$/, '$1') : '○○';
            buf.add('');
            ['邸 新築工事', '邸 増築工事', '邸 増改築工事', '邸 改修工事']
                .forEach(function(v) {buf.add(cn + v);});
            $note.find(':tag(name) select.quick').html(buf.join());
        }

        function flipNote(caseData) {
            $note.parent()
                .transition({opacity: 0}, 0, function() {showNote(caseData)})
                .transition({opacity: 1, delay: 100});
        }
        $list.on('click', '.case', function(e) {
            hideTagFilter();

            var $el = $(this), caseData = $el.data('data');
            if (!$el.hasClass('case')) {
                $el = $el.closest('.case');
            }

            $list.find('.case.edit').removeClass('edit');
            fillClientNames(caseData.name);
            $view.toggleClass('blank', false);
            flipNote(caseData);

            $el.toggleClass('edit', true);
            e.stopPropagation();
        });

        $('item:tag(name) > .dropdown > select').on('click', function() {
            fillClientNames($('item:tag(name)').val());
        });

        $('#tagfilter').on('click', 'span:not(.na)', function() {
            var $el = $(this), tag = $el.text();
            $tagfilter.removeClass('on');
            $el.addClass('on');
            if (tag !== '全') {
                show(userData.filter(function(v) {
                    return v.tag === tag;
                }));
            } else {
                show(userData);
            }
            $('#tag').val(tag);
            $('#cancel').trigger('click');
            $view.addClass('blank').removeClass('edit');
        });

        $('#pick-photo > input').on('change', function(e) {
            // TODO: resize, <=3 photos, check duplication
/*
            var reader = new FileReader();
            reader.onload = function(e) {
                var $img = $('<img>').appendTo($('#slides'));
                console.log(reader.result);
                $img.css('background-image',  'url(' + reader.result + ')');
            };
            reader.readAsDataURL($(e.target)[0].files[0]);
//*/
//*
            var blobUrl = window.URL.createObjectURL($(e.target)[0].files[0]);
            var $img = $('<span>').appendTo($('#slides'));
            $img.css('background-image', 'url(' + blobUrl + ')');
//*/
        });

        $quicktag.on('click', function() {
            $quicktag.removeClass('on');
            $(this).addClass('on');

            showDropdown($('select')[0]);
        });

        $view.on('click', function() {
            if ($view.hasClass('blank')) {
                $view.removeClass('blank').addClass('edit')
                     .find('item:not([data-tag=type]) value').editable(true);

                bind($note, {name: '', addr: '', contractor: '', floor: '', type: '', tag: null}, BINDTO);
                fillClientNames();
            }
        });

        $('select.quick').on('change', function(e) {
            var $el = $(this);
            $el.closest('.dropdown').prev().val($el.val());
            console.log($(e.target).val());
        });

        $('.flags').on('click', 'span', function(e) {
            var $el = $(e.target);
            $el.closest('.flags').find('span.on').removeClass('on');
            $el.addClass('on');
            $el.transition({scale: 1.2}, 100).transition({scale: 1}, 100);
        }).on('longtap', 'span', function(e) {
            var $el = $(e.target);
            if ($el.hasClass('on')) {
                $el.removeClass('on');
                $el.transition({scale: 1.2}, 100).transition({scale: 1}, 100);
            }
        });

        $('#submit').on('click', function(e) {
            $('#submit').transition({x: "250%"}, 400, 'easeInBack', function() {
                var caseData = $('.case.edit').data('data');
                if ($view.hasClass('status-1')) {
                    caseData.status = 0;
                    $view.removeClass('status-1');
                } else {
                    caseData.status = 1;
                    $view.addClass('status-1');
                }

                var $case = $('.case.edit');
                updateCaseItem($case, $case.data('data'));

            }).transition({x : 0});
        });

        $('#confirm').on('click', function(e) {
            $('#confirm').transition({x: "250%"}, 400, 'easeInBack', function() {
                var caseData = $('.case.edit').data('data');
                if ($view.hasClass('status-2')) {
                    caseData.status = 1;
                    $view.removeClass('status-2');
                    $('#more .flags span.on').removeClass('on');
                } else {
                    caseData.status = 2;
                    $view.addClass('status-2');
                }

                var $case = $('.case.edit');
                updateCaseItem($case, $case.data('data'));

            }).transition({x : 0});
        });

        function openTagFilter() {
            var toX = 32;
            $left.addClass('-tag-filter-on').transition({x: toX});//, 400, 'snap');
            $view.transition({x: toX});//, 400, 'snap');
        }

        function hideTagFilter() {
            if ($left.hasClass('-tag-filter-on')) {
                $left.transition({x: 0}, 200, 'snap')
                .removeClass('-tag-filter-on');
                $view.transition({x: 0}, 200, 'snap');
            }
        }

        (function pullLeftSide() {
            var pulldown = false, $shadow;
            $('#title').on('click', function() { $('#list').animate({scrollTop: 0}, 'fast'); });

            function pull(e, fact) {
                var motion = fact.motion();
                if ($left.hasClass('-tag-filter-on')) {
                    if (motion.h === 'left') {
                        hideTagFilter();
                        $left.off('touchmove', pull);
                        console.log('hidden');
                    }
                } else if (!$shadow) {
                    if (motion.h === 'right') {
//                        if (motion.start.x < 160) {
                            openTagFilter();
                            $left.off('touchmove', pull);
                            return;
//                        }
                    } else if (motion.v === 'down' && !pulldown) {
                        if ($(e.target).closest('#list').length !== 0) {
                            if ($list.scrollTop() !== 0) {
                                return;
                            }
                        }
                        var dx = Math.min(200, motion.extent.offset.y) + 20;
                        $left.transition({y: dx});
                        $('#exit').transition({rotate: '-90deg', 'color': '#F00'}).removeClass('fadeout icon-spin');
                        var h = $('#pull-to-refresh');
                        $('#pull-to-refresh')
                            .css({'-webkit-perspective': '300px'})
                            .transition({perspective: '300px', rotateX: '0deg', translateY: '-100%', 'background': '#F8F8F8', color: '#AAA', height: dx}, 700);
                        pulldown = true;
                        return;
                    }
                } else {
                    var extent = fact.extent(), offset = extent.offset, end = extent.end;
                    $shadow.css({top: $shadow.b.top + offset.y, left: $shadow.b.left + offset.x});

                    var $hover = $(document.elementFromPoint(end.x, end.y));
                    if ($hover.closest('#content').length > 0) {
                        $('#drop-target').toggleClass('on', true);
                    } else {
                        var $slot = $hover.closest('#drop-target > span');
                        $('#drop-target > span.hover').toggleClass('hover', false);
                        $slot.toggleClass('hover', true);
                    }
                    e.preventDefault();
                }
            };

            $('#tag').on('click', openTagFilter);

            $left.on('touchstart', function(e) { pulldown = false; $left.on('touchmove', pull); })
                 .on('touchend', function(e, fact) {
                     if (pulldown) {
                         $left.transition({y: '0'});
                         $('#exit').transition({rotate: '0', color: ''}).addClass('icon-spin');
//                         $('#pull-to-refresh').transition({ rotateX: '90deg', 'background': '#000'});
                         $('#pull-to-refresh')
                             .css({'-webkit-perspective': '300px'})
                             .transition({perspective: '300px', rotateX: '90deg', translateY: '0%', 'background': '#000', 'color': '#FFF'});
                         pulldown = false;

                         setTimeout(function(){
                             $('#exit')
                                 .transition({rotate: '0', color: 'inherit'}, function(){$(this).removeClass('icon-spin')})
                                 .addClass('fadeout');
                         }, 1400);
                     }
                     $left.off('touchmove', pull);
                     if ($shadow) {
                         var $base = $shadow.base, $action = $('#drop-target > .hover'),
                             effect = [{x: -50, y: -50, scale: 0.8, opacity: 0}];

                         $('#drop-target').toggleClass('on', false);
                         $shadow.base.removeClass('drag');
                         if ($action.length > 0) {
                             switch ($action.attr('id')) {
                                 case 'drop-del':
                                     effect = [{x: $(document.body).width() - $shadow.position().left + 120, opacity: 0}, 250, 'cubic-bezier(.45,.33,.95,.73)'];
                                     $base.hide($base.remove);
                                     break;
                                 case 'drop-copy':
                                     var $case = $('.case.edit', $list).toggleClass('edit', false),
                                     caseData = $.extend({}, $base.data('data'));

                                     caseData.name = caseData.name.replace(/(^.*)(邸.*$)/, '○○$2');
                                     caseData.status = null;
                                     caseData.tag = null;
                                     $view.toggleClass('blank', false);

                                     $view.toggleClass('edit', true)
                                          .find('item:not([data-tag=type]) value, [data-tag=type-other], #more .editable').editable('true');

                                     flipNote(caseData);
                                     break;
                                 default:
                                     $base.click();
                                     break;
                             }
                         }
                         effect.push($shadow.remove);
                         $shadow.transition.apply($shadow, effect);
                         $action.toggleClass('hover', false);
                         $shadow = null;
                     }
                  });


            $list.on('longtap', '.case', function(e, fact) {
                if ($left.hasClass('-tag-filter-on')) {
                    return;
                }
                var $case = $(this),
                    pos = $case.bounds();
                $shadow = $case.clone();
                $case.addClass('drag');
                $('#drop-target').toggleClass('on', true);
                $shadow.b = pos;
                $shadow.base = $case;
                $shadow.css({'z-index': 1, 'pointer-events': 'none', width: pos.width, top: pos.top + 1, left: pos.left, opacity: 0.9, 'box-shadow': '3px 3px 12px #999'});
                if (!$case.hasClass('edit')) {
                    $shadow.css('background-color', '#FFF');
                }
                $shadow.appendTo($(document.body));
            });

        }) ();
    });

});
