require(['jquery', 'ryn/ui.widget'], function($, widget) {

    widget('case').define(function(data, update) {
        update(this, data);

//        widget('my-widget').construct('red', 'Agent 007').appendTo(this);
//        widget('child-widget').construct('blue', 'Agent Jr. 007').appendTo(this);
    });

    widget.inherit('case', 'case.one').define(function(args) {
//        this.find('[data-tag=name]').css('color', '#D22');
    });

    widget.inherit('case.one', 'case.two').define(function(args) {
//        this.find('[data-tag=addr]').css('color', '#22D');
    });

    widget('my-widget').define(function(color, name) {
        console.log('super!');
        this.css('color', color)
            .append(document.createTextNode('Call me ' + name + '. '));
    });

    // a inherited widget
    widget.inherit('my-widget', 'child-widget').define(function(name, color) {
        this.append(document.createTextNode('I am inherited from "my-widget".'));
    });
/*
    widget.sibling('my-widget', 'child-widget').define(function(name, color) {
        this.append(document.createTextNode('I am a sibling of "my-widget".'));
    });
//*/
});
