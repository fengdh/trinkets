define(['jquery', 'card', 'ryn/utils', 'ryn/remote', 'ryn/ui.grid', 'ryn/ui.databind', 'ryn/ui.notify'],
	function($, card, UTILS, Remote, Grid, bind, NC) {
    console.log("Module for card N/O");

    var sampleModule = {
            uses: ['ICardService'],
            reload:
            	function ($card, cardService, extra) {
            		// 他カードから呼ばれる時に限る付加情報をデバッグで出力してみる
            		console.log(extra);

            		// $card.isInitDone()はメインメニューまたはほかのカードから初めて開く時だけ、falseを返す。
            		// いったんカードが表示されたら、常にtrueを返す。
            		if (!$card.isInitDone()) {
            			// ここで初期化処理を実行する
            			$card.empty().append($('<div>', {
            				'style': 'color: blue',
            				'html': 'メイン・メニューより開くので、初期化処理は実行されました。'
            			}));

            			// この以下画面更新処理(初期及びほかのカードから開く時)を記述する
            			// - 例はサンプルカード#5の時だけダイアログを表示する
	            		if ($card.data('tag') === 5) {
    	        			NC.post('W', '初期化: Card #' + $card.data('tag'));
//        	    			NC.debug('E', '初期化: Card #' + $card.data('tag'));
            			}
            		}

            		// 以下は通常の初期、または他カードから呼ばれる時の更新処理
            		if (extra) {
            			$card.empty().append($('<div>', {
            				'style': 'color: red',
                			'html': 'CARD ' + $card.data('tag') + ': ' + extra.data + ' // from CARD ' + extra.source.data('tag') + ' <input>'
                		}));


            		}

            		$card.append('<p>' + new Date());
                }
        };

    card('5').define(sampleModule);
    card('6').define(sampleModule);
    card('7').define(sampleModule);

});
