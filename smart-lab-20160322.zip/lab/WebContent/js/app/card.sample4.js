define(['jquery', 'card', 'ryn/remote', 'ryn/ui.grid', 'ryn/ui.databind', 'data/data.sample4'],
    function($, card, Remote, Grid, bind, getSampleData) {
    console.log("Module for card N/O");

    card('4').define({
        uses: ['ICardService'],
        reload:
            function ($card, cardService, extra) {
                return cardService.getCardData('4', null, null)
                    .then(function(data) {
                        // extraが存在すれば、ほかのカードから呼ばれることを示す
                        // 本来は条件変更のありなしを判断しなければならない

                        // まだサーバ側が用意できていないため、cardServiceの戻り値を無視して、ランダムに生成するサンプルデータを使用する
                        data = extra ? extra.data() : getSampleData();
                        
                        for (var x = 0, c = Math.random() * 3; x < c; x++) {
                          data.claimHistory.unshift({
                             claimNo : 'Random',
                             ts : (new Date()).toLocaleString(),
                             content : '--',
                             cause : '--'
                          });
                        }

                        console.log('Card O sample data: ', data);

                        // ローカルのサンプルデータ(data/data.O.js)をグリッドとバインドする。
                        // 本番はカードサービスの戻り値を使うべき。

                        if (data.censored) {
                            // 検閲済みの簡単情報を用いて、動的にクレーム履歴テーブルを置き換える
                            $card.empty().append($('<div>', {
                                'class': 'censored',
                                'text': data.message
                            }));
                        } else {
                            if (extra) {
                                // カードの構成を初期状態に戻す
                                $card = $card.restore();
                                console.warn('restore');
                            }
                            // 通常は、クレーム履歴を表示する
                            bind($card, data);

// グリッドのデータバインドはすぐに#show()が呼ばれるため、以下の対応は不要（むしろ重複）
//                            // 通常グリッドのデータバインディングは遅延して更新されるため、Grid#show()を呼び出してすぐに更新を行う。
//                    		new Grid($card.find('#claimHistory')).show();

                            // サンプル：　「クレーム内容/不具合要因」のTDセルを編集可能に
                            //        「不具合要因」は複数行テキストを入力可能
                            $card.find('td>:tag(content, cause)').editable(true);


                            // 編集可能な項目は編集値を取得する場合は、$el.val()を使ってください
                            // (改行可能な場合は改行を含むテキスト、数値タイプは数値を取得できるため）
                            // サンプル：
                            console.log('一行目の「不具合要因」: ' + $card.find(':tag(cause)').eq(0).val());
                        }
                    });
            }
    });

});
