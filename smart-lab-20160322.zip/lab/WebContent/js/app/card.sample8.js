define(['jquery', 'card', 'ryn/remote', 'ryn/ui.grid', 'ryn/ui.databind', 'data/data.sample4'],
    function($, card, Remote, Grid, bind, getSampleData) {
    console.log("Module for card N/O");

    card('8').define({
        uses: ['ICardService'],
        reload:
            function ($card, cardService, extra) {
            }
    });

});
