/**
 * dev version
 */

var require = {
        // TODO: 暫定、Offline Webを利用すべき
        waitSeconds: 0,
        baseUrl: '../js',

        paths: { 'app'            	: '../js/app',
                 'ryn'            	: '../js/ryn',
                 'data'           	: '../js/data',
                 'dev'           	: '../js/dev',
                 'api'            	: '../remoting/ryn/api',
                 'accounting'     	: 'dev/accounting',
                 'd3'			  	: 'dev/d3',
                 'hammer'		  	: 'dev/hammer',
                 'jquery'         	: 'dev/jquery-1.12.0',
                 'jquery.color'		: 'dev/jquery.color-2.1.2',
                 'jquery.mobile'  	: 'dev/jquery.mobile-1.4.2',
                 'jquery.notyfy'  	: 'jquery.notyfy',
                 'jquery.opentip' 	: 'dev/opentip-jquery',
                 'murmurhash3'      : 'dev/murmurhash3',
                 'text'			  	: 'text',
                 'pack'             : '../pack',
             },
        map: {'*' : {
                 'ryn/app'		   : 'ryn/ryn.app',
                 'ryn/utils'       : 'ryn/ryn.utils',
                 'ryn/remote'      : 'ryn/ryn.remote',
                 'ryn/ui'          : 'ryn/ryn.ui',
                 'ryn/ui.grid'     : 'ryn/ryn.ui.grid',
                 'ryn/ui.databind' : 'ryn/ryn.ui.databind',
                 'ryn/ui.jqm'      : 'ryn/ryn.ui.jqm',
                 'ryn/ui.notify'   : 'ryn/ryn.ui.notify',
                 'ryn/ui.pulldown' : 'ryn/ryn.ui.pulldown',
                 'ryn/ui.widget'   : 'ryn/ryn.ui.widget',
                 'card'            : 'app/card',
           // DELETE ME!
           'app/card.sample123.js' : '../js/app/card.sample123.js',
              }
        },

        shim: {
            'jquery.color'     : {deps: ['jquery']},
            'jquery.mobile'    : {deps: ['jquery']},
            'jquery.resize'	   : {deps: ['jquery']},
            'jquery.notyfy'	   : {deps: ['jquery']},
            'jquery.opentip'   : {deps: ['jquery']},
            'ryn/ryn.ui.grid'  : {deps: ['jquery.resize', 'jquery.color']}
        }
};

var Ryn = (function(){
    var errlist = [], delay;

    return {
          App: {},
          Remote: {
              options: {
                      toSpecUrl: function(ids) { return 'api/' + ids + '/spec';}
              }
          },
          Notify: {
            assembleMore: function(args, option) {
                if (!option || option.type !== 'raw') {
                    args[0] = ['<b>', args[0], '</b>:<br>'].join('');
                }
                return args.join('');
            },
            neterr: function(resource, more, option) {
                var NC = this;
                function x() {
                    var msg = errlist.length > 1 ? '\r\t' : '';
                    msg += errlist.join(',\r\t');
                    errlist = [];
                    NC.shout({id: 'F', text: "ネットワーク・エラー: " + msg}, more, option);
                }

                if (more && more !== "") {
                    more = $.makeArray(more);
                    this.shout({id: 'F', text: "ネットワーク・エラー: " + resource}, more, option);
                } else {
                    clearTimeout(delay);
                    errlist.push(resource);
                    delay = setTimeout(x);
                }
             }
          }
    };
})();

Ryn.App.ver = 'Ver. 0.0.1-20150123-dev';

//*/
(this.Ryn = this.Ryn || {})
  .WidgetKit = { 
    domains: {
      '': {
        base: '/lab/pack',
      },
      'sample': {
        base: '/lab/pack',
        events: {defined: true, willCreate: true, created: true}, 
        proto: [
          function _Root() { // IMPORTANT: root constructor of domain can not takes any argument.
            console.warn('Sample Domain: ROOT constructor invoked by', this.$('id'));
            this.$().addClass('card')
                    .attr({'data-tag': this.tag, 'data-info': this.title})
                    .css({'padding-right': '2em', margin: '0.8em', 'border-color': this.color})
                    .append($('<div>', {html: (this.msg || '') + ' [' + this.$('id') + ']', 
                                        style: 'color: red;text-align: right;padding:0.5em 1em;'}));
          }, 
          {  show: function() { return this.$().css({display: 'block'}), this },
             hide: function() { return this.$().css({display: 'initial'}), this },
            shake: function() { 
                      var $content = this.$();
                      $content.toggleClass('run-shake', true)
                              .on('webkitAnimationEnd', function() { $content.toggleClass('run-shake', false)});
                      return this;
                   },
              mow: function() { return console.log(this.$('id') + ' says MOW~'), this },
         redAlert: function(color) {
                      var $content = this.$();
                      console.log('\t implemented in ' + '<root>');
                      $content.css({'border-color': color});
                      $content.toggleClass('run-redAlert', true)
                              .on('webkitAnimationEnd', function() { $content.toggleClass('run-redAlert', false)});
                      return this;
                   },
          }]
      }
    }
  }
//*/