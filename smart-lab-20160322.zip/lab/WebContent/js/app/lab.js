/**
 * Insane Smart Web Lab
 */
require(['jquery', 'ryn/remote', 'ryn/ui.notify'], function($, Remote, NC) {
    $(function() {
        var $uid = $('#uid'), $pwd = $('#pwd'), $login = $('#login');

        function doLogin() {
            NC.shout({id: 'W', text: 'Warning: No Entomophobian'}, ['Caution: Welcome to World of Bugs']);
            NC.post('S', 'Warning: No Entomophobian');
//            NC.shout('W', 'Warning: Are you human?');
//            NC.shout('W', 'Warning: Are you human?');

            var uid = $uid.val(), pwd = $pwd.val(), valid = false, msg;
            if (!uid) {
                msg = "Missing user ID!";
                NC.shout(msg);
                return;
            } else if (!pwd) {
                msg = "Missing password!";
                NC.shout(msg);
                return;
            } else {
                msg = "Connecting to server...";
                valid = true;
            }
            window.ratio = NC.post('R', 'Installing Karte web app...');
console.log(ratio);


            // styling message
            var YES_NO_CANCEL = [{
                addClass: 'btn btn-primary',
                text: 'YES',
                onClick: function(notyfy) {
                    notyfy.resolve('hidden', this).close();
                }
              }, {
                    addClass: 'btn btn-primary',
                    text: 'NO',
                    onClick: function(notyfy) {
                        notyfy.resolve('hidden', this).close();
                    }
                  }, {
                    addClass: 'btn btn-danger',
                    text: 'Cancel',
                    onClick: function(notyfy) {
                        notyfy.resolve('hidden', this).close();
                    }
                  }];
            NC.post({id: 'Q', text: '正規ユーザ以外は利用禁止。\r\n<B style="color:yellow">ログインを継続しますか？'}, undefined, undefined, {buttons: YES_NO_CANCEL}).after('hidden').then(function(trigger) {
                    alert($(trigger).text() + ' is clicked.');
                });
            NC.post(msg);

            if (valid) {
                Remote.use(['IFacetService', 'prototype/IZipService'], function(facetService, zipService) {
                    ratio.message.find('.notyfy-ratio').children().first().text('60%')
                        .animate({'width': '60%'}, 900);

                    console.log(this);
                    console.log(facetService, zipService);
                    var result;
//*
                    // -------------------------------------------
                    // サンプル：　リモート・サービスのメソッドの呼び出し
                    // [注] リモート・サービスは予めSpring Frameworkコンテナーに定義＆公開済みのもの
                    // -------------------------------------------

                    var badThings = (new Date().getMilliseconds() % 5) === 1;
                    // -------------------------------------------
                    // 同期処理で実行する:
                    //    - HTTPレスポンスが返すまで、処理を待つ
                    //    - 戻り値はすぐに取得できる
                    //      - リモート・サービスのメソッドが実行中例外を送り出した場合は、RemoteErrorオブジェクトが
                    // -------------------------------------------
                    console.log('# synchronized remote call');

                    result = facetService.auth(uid, pwd);
                    console.log('auth: ', result);

                    // primitive parameter type
                    result = zipService.add(324, 128);
                    console.log('add(324, 128): ' + result);

                    // missing primitive type argument (using default value of 0 or false)
                    result = zipService.add(324);
                    console.log('add(324): ' + result);

                    // missing args
                    result = zipService.match();
                    // send with varlen args
                    result = zipService.match({zipCode: '100-1010'}, 'A', 'B', 'c');
                    console.log('match zip: ', result);

                    result = zipService.lookup("179-0072");
                    console.log('lookup zip: ', result);
                    result.done(function(value) {
                        console.log('lookup result also as a promise: ', value);
                    });

                    result = zipService.silent();
                    console.log('Keep silent', result);
                    result.done(function() {
                        console.log('So I go silent for a while', result);
                        NC.post("browser said: なにも起こらなかったよ。お静かに...")
                    });

                    if (badThings || true) {
                        // リモート・サービスのメソッドは実行中に例外を送り出した
                        try {
                            result = zipService.setup({context: {title: 'パスワード(同期処理時)', item: $pwd}}).bad();
                            console.log('bad: ', result);
                        } catch (e) {
                            console.error('caught ', e instanceof this.Error);
                        }
                    }

                    // -------------------------------------------
                    // 非同期処理で実行する：
                    //     - HTTPレスポンスを待つことなく、処理を続行できる
                    //     - 戻り値はjQueryのpromiseオブジェクト、HTTPレスポンスが返されたら、
                    //       戻り値または例外
                    // -------------------------------------------
                    console.log('# asynchronized remote call');
                    result = zipService.setup().lookup("1790072");
                    result.done(function(value) {
                        console.log('lookup zip(deferred): ', value);
                    });

                    result = zipService.setup({async: true, context: {title: 'パスワード(非同期処理時)', item: $pwd}}).bad();
                    result.fail(function(err) {
                        console.log('bad(deferred)', err);
                    });

//*/
                    // -------------------------------------------
                    Remote.Session.open({async: true});
                    console.log('# batch remote call');

                    var p1 = zipService.lookup("179-0072");

                    badThings = (new Date().getMilliseconds() % 3) === 2;
                    var p2 = badThings ? zipService.setup({async: true, context: {title: 'パスワード(非同期処理時+バッチ)', item: $pwd}}).bad() : zipService.lookup("356-0031");

                    var p3 = zipService.listAll();
                    p3.done(function(value) {
                        console.log('list all zips(deferred,　OR-relationship): ', value);
                    });

                    $.when(p1, p2, p3)
                     .done(function(r1, r2, r3) {
                         console.log('deferred result[1]: ', r1);
                         console.log('deferred result[2]: ', r2);
                         console.log('deferred result[3]: ', r3);
                     })
                     .fail(function(err) {
                               console.log('batch remote call failed: ', err);
                          });
                    Remote.Session.close();
                });
//                location.href="buildings.html";
            }
        };

        function motion($e) {
            var textColor = $e.css('color'), borderColor = $e.css('border-color');
            var timer;

            var fadeText = function() {
                clearTimeout(timer);
                $e.css({color: textColor});
            },
            hilight = function() {
                $e.css({color: '#666', 'border-color' : '#777'});
                clearTimeout(timer);
                timer = setTimeout(fadeText, 1500);
            },
            autoNext = function(e) {
                if (e.keyCode === 13) {    // ENTER key
                    if (this.id === 'pwd') {
                        if (this.value) {
                            doLogin();
                        }
                    } else {
                        $pwd.focus();
                    }
                }
            };

            $e.keypress(hilight).focusin(hilight)
              .focusout(fadeText).focusout(function() {$e.css({'border-color': borderColor});})
              .keypress(autoNext);
        }

        // setup animation
        motion($uid);
        motion($pwd);

        // setup login action
        $login.click(doLogin);

        // init focus
        $uid.focus().select();

        var $fmUploader = $('#fmUploader');
        $('#btnUploadFile').on('click', function() {
            // TODO: check if file(s) being selected
            Remote.use('prototype/IZipService', function(zipService) {
                var settings = {form: '#fmUploader', useName: 'zip'};
                var result = zipService(settings)							// フォームと結び付け
                                .upload({purpose: 'TEST', etc: 123456})		// アップロード実行
                                .done(function(value) {						// 非同期のため、戻り値はPromiseオブジェクト
                                    console.log('Upload Processed: ', value);
                                    NC.post('I', value[3]);
                                });
            });
        });

        $('.btnDownload').on('click', function() {
            console.log(this);
            var ext = $(this).data('ext');
            Remote.use('prototype/IZipService', function(zipService) {
                if (ext !== 'any') {
                    zipService.output({msg: 'Nothing important.'})
                              .done(function() {
                                  NC.post('I', "Starting to download csv file ...");
                              });
                } else {
                    zipService.outputAny()
                              .done(function() {
                                  NC.post('I', "Starting to download binary data file ...");
                              });
                }
            });
        });
    });
});
