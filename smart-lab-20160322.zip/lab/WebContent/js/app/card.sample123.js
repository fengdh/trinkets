define(['jquery', 'card', 'ryn/remote', 'ryn/ui.databind'], function($, card, Remote, bind) {
    console.log("Module for card A/B");

    card('1').define({
        uses: ['ICardService'],
        reload:
            function ($card, cardService) {
            	// サンプル： 「敷地面積～構造」を編集可能に
        		$card.find('value').editable(true);

                return cardService.getCardData('1', null, null)
                    .then(function(data) {
                    	var currencyData = {
                    			c1: 1394.57,
                    			c2: 1394.57,
                    			c3: 1394.57,
                    			c4: null,
                    			c5: null,
                    			c6: "'120A",
                    	};
                    	bind($card.find('#test-currency'), currencyData);

                    	var numData = {
                    			n1: 1394.57,
                    			n2: 1394.57,
                    			n3: 1394.57,
                    			n4: null,
                    			n5: null,
                    			n6: null,
                    	};
                    	bind($card.find('#test-num'), numData);
                    	data.rentableArea = null;
                    	data.area = 4334.45;

                    	// データバインディングの例
                    	bind($card, data, {'parkingSlots': ':tag(parkingSlots)'});
                    	// シングル値（数値/文字列/Date型/true/false）のデータ・バインディング
                    	bind($card.find(':tag(parkingSlots)'), new Object('満車'));
                    });
            }
    });

    card('2').define({
        uses: ['ICardService', 'prototype/IZipService'],
        reload: function($card, cardService, zipService) {
        	// 意味の無いサンプル：両方からの結果を取得した場合に限って処理する
            return $.when(cardService.getCardData('2', null, null), zipService.listAll())
             .then(function(data,list) {
             	// データバインディングの例
             	bind($card, data);
                console.log('zip list:', list);
             });
        }
    });

    card('3').define({
        uses: ['ICardService'],
        reload:
            function ($card, cardService) {
        		console.log('init card sample #3');
        		$card.find('li').on('click', function(e) {
        			var $this = $(this),
        			    target = $this.find('h2').text().substr(-1, 1),
        			    info = $this.find('p').text();
        			console.log('will jump to card', target, '.  info:', info);
        			if (target == '4') {
        				require(['data/data.sample4'], function(info) {
                          card(target).show({source: $card, data: info});
        				});
        			} else {
        				card(target).show({source: $card, data: info});
        			}
        		});
            }
    });

});
