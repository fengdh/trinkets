/**
 * release version
 *
 * NOTE:
 *  - BUGFIX: jquery.mobile-1.4.2.js #10391-10393
 *            http://stackoverflow.com/questions/5657371/ie9-window-loses-focus-due-to-jquery-mobile
 */

var require = {
        // TODO: 暫定、Offline Webを利用すべき
        waitSeconds: 0,
        baseUrl: '../js',

        paths: { 'app'            	: '../js/app',
                 'ryn'            	: '../js/ryn',
                 'data'           	: '../js/data',
                 'dev'            	: '../js/dev',
                 'api'            	: '../remoting/ryn/api',
                 'accounting'     	: 'accounting.min',
                 'd3'			 	: 'd3.min',
                 'hammer'		  	: 'hammer.min',
                 'jquery'         	: 'jquery-1.12.0.min',
                 'jquery.color'		: 'jquery.color-2.1.2.min',
                 'jquery.mobile'  	: 'jquery.mobile-1.4.2.min',
                 'jquery.notyfy'  	: 'jquery.notyfy',
                 'jquery.opentip' 	: 'opentip-jquery.min',
                 'murmurhash3'      : 'murmurhash3.min',
                 'text'			  	: 'text',
                 'pack'             : '../pack'
             },
        map: {'*' : {
                 'ryn/app'		   : 'ryn/ryn.app',
                 'ryn/utils'       : 'ryn/ryn.utils',
                 'ryn/remote'      : 'ryn/ryn.remote',
                 'ryn/ui'          : 'ryn/ryn.ui',
                 'ryn/ui.grid'     : 'ryn/ryn.ui.grid',
                 'ryn/ui.databind' : 'ryn/ryn.ui.databind',
                 'ryn/ui.jqm'      : 'ryn/ryn.ui.jqm',
                 'ryn/ui.notify'   : 'ryn/ryn.ui.notify',
                 'ryn/ui.pulldown' : 'ryn/ryn.ui.pulldown',
                 'ryn/ui.widget'   : 'ryn/ryn.ui.widget',
                 'card'            : 'app/card'
             }
        },

        shim: {
            'jquery.color'     : {deps: ['jquery']},
            'jquery.mobile'    : {deps: ['jquery']},
            'jquery.resize'	   : {deps: ['jquery']},
            'jquery.notyfy'	   : {deps: ['jquery']},
            'jquery.opentip'   : {deps: ['jquery']},
            'ryn/ryn.ui.grid'  : {deps: ['jquery.resize', 'jquery.color']}
        }
};

var Ryn = (function(){
    var errlist = [], delay;

    return {
          App: {},
          Remote: {
              options: {
                      toSpecUrl: function(ids) { return 'api/' + ids + '/spec';}
              }
          },
          Notify: {
            assembleMore: function(args, option) {
                if (!option || option.type !== 'raw') {
                    args[0] = ['<b>', args[0], '</b>:<br>'].join('');
                }
                return args.join('');
            },
            neterr: function(resource, more, option) {
                var NC = this;
                function x() {
                    var msg = errlist.length > 1 ? '\r\t' : '';
                    msg += errlist.join(',\r\t');
                    errlist = [];
                    NC.shout({id: 'F', text: "ネットワーク・エラー: " + msg}, more, option);
                }

                if (more && more !== "") {
                    more = $.makeArray(more);
                    this.shout({id: 'F', text: "ネットワーク・エラー: " + resource}, more, option);
                } else {
                    clearTimeout(delay);
                    errlist.push(resource);
                    delay = setTimeout(x);
                }
             }
          }
    };
})();

Ryn.App.ver = 'Ver. 0.0.1-20150123';

/*/
(this.Ryn = this.Ryn || {})
  .WidgetKit = { // Default settings for WidgetKit
    base: '/lab/pack', //
    toUrl: undefined, // = requirejs.toUrl as default value
    finder: undefined, // default returning toUrl(widget_id + ".html")
    map: {
      'widget.id': 'resource.path.html',
      //...
    },
    package: {
      'pack1.html': ['w1', 'w2'],
      //...
    },
    domains: {
      'card': {
          finder: 
            {map: {'1': '/lab/html/card.sample123.html',
                   '2': '/lab/html/card.sample123.html',
                   '3': '/lab/html/card.sample123.html',
                  }
            },
          options:
            { ':import': '[data-merge]',   '@url': 'data-merge',
               ':model': '.card[data-tag]', '@id': 'data-tag',
                content: 'slice',         
                resolve: requirejs.toUrl,
                  extra: { toggle: function() { 
                    console.warn('toggle: card.' + this.$('id')); return this; }}
            } 
          }
      }
  }
//*/