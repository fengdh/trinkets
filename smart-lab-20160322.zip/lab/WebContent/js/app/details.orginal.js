/**
 * app/details.js: 建物詳細情報画面
 一枝桂发祥，一段郭德纲。
 举杯呷清茗，尤好野茶香。
 咖啡苦成引，汉堡充饥肠。
 疑似天上乐，好龙尝轻狂。
 */
require(['jquery', 'jquery.mobile', 'hammer', 'ryn/remote', 'ryn/ui.jqm', 'ryn/ui.grid', 'ryn/utils', 'ryn/ui.databind', 'ryn/ui.notify', 'ryn/ui.pulldown', 'jquery.opentip', 'ryn/ui'],
        function($, $JQM, Hammer, Remote, Mobile, Grid, UTILS, bind, NC) {
    $(function() {

        if (location.protocol == "file:") {
            $('<link>')
                .appendTo($('head'))
                .attr({type : 'text/css', rel : 'stylesheet'})
                .attr('href', '../css/dev.css');
        }

        // ------------------------------------------------------------------------
        // BEGIN: card module
        var cards = {}, queue = [], delayer = UTILS.delayer(), cardsInPage = [], SCROLL_LOCK = false,
            INIT_DONE = function() {return true;}, INIT_NOTYET = function() {return false;};

        define('card', function() {return card;})

        /**
         * Define a function to get one or multiple promised cards which is resolved(loaded) from other HTML source already or later.
         */
        function card(/* tag1, tag2, .. */) {
            var args = UTILS.slice(arguments);
            if (args.length == 1 && $.isArray(args[0])) {
                args = args[0];
            }
            if (args.length > 1) {
                return each(args.map(function(tag) {return _card(tag);}), ['toggle']);
            } else if (args.length == 1) {
                return _card(args[0]);
            }

            function each(obj, methods) {
                methods.forEach(function(m) {
                    obj[m] = function() {var _args = UTILS.slice(arguments); this.forEach(function(one) {return one[m].apply(one, _args);}); return this;};
                });
                return obj;
            }

            function willUpdate($card, module, extra) {
                queue.push([$card, module, extra]);
                delayer.call(function() {
                    var set = {}, uses, keys, i, len, copy = UTILS.slice(queue);
                    queue = [];

                    // create set of service ids
                    copy.forEach(function(e) {
                        uses = e[1].uses;
                        if ($.isArray(uses)) {
                            len = uses.length;
                            for (i = 0; i < len; i++) {
                                set[uses[i]] = null;
                            }
                        } else {
                            set[uses] = null;
                        }
                    });

                    keys = Object.keys(set);
                    len = keys.length;
                    if (len > 0) {
                        // get proxies of service
                        Remote.use(Object.keys(set), function() {
                            for (i = 0; i < len; i++) {
                                set[keys[i]] = arguments[i];
                            }

                            Remote.Session.open({async: true});
                            copy.forEach(function(e) {
                                // mapping arguments
                                var args = [e[0]];
                                uses = e[1].uses;
                                if ($.isArray(uses)) {
                                    len = uses.length;
                                    for (i = 0; i < len; i++) {
                                        args.push(set[uses[i]]);
                                    }
                                } else {
                                    args.push(set[uses]);
                                }
                                args.push(e[2]);

                                // invoke update
                                e[1].reload.apply(e[1], args);
                                args[0].isInitDone = INIT_DONE;

                            });

                            Remote.Session.close();
                        });
                    }

                });
            }

            /**
             * internal function, get only one card by it's tag.
             *
             * @return a promise which will resolve a Card DOM object.
             */
            function _card(tag) {
                var cd = cards[tag];
                if (!cd) {
                    cards[tag] = (cd = $.Deferred());
                    loadFromFile(tag);
                }

                return cd.promise({
                    tag: function() {return tag;},
                    show: function(extra) {
                            SCROLL_LOCK = false;
                            this.done(function() {updateTab(tag, true);});
                            return this.toggle(true, false, extra);
                        },

                    // return a promise which will be resolved at finish of toggle.
                    toggle: function(visible, quiet, extra) {
                        var willFinish = $.Deferred();
                        // TODO: swipe to discard (hammer.js is confilicted with selection of contenteditable element)
                        //var self = this;
                        this.done(function($card) {
                                willFinish.done(function() { $card.trigger('toggled', $card.revealed);});
                                if ($card.revealed === visible) {
                                    if (!UTILS.isUndefined(extra)) {
                                        $card.revealed = false;
                                    } else {
                                        return;
                                    }
                                }
                                if ($card.parent()[0] !== $scroll[0]) {
                                    $scroll.find('.card[data-tag=' + tag + ']').replaceWith($card);
                                    $card.attr('data-info', TAGS[tag]).trigger('create');

// TODO: swipe to discard (hammer.js is confilicted with selection of contenteditable element)
//                                    Hammer($card[0]).on('swiperight', function(e) {
//                                        self.toggle();
//                                        updateTab(tag, false);
//                                    });
                                }
                                $card.is(':animated') && $card.finish();
                                var scrollCardIntoView = quiet ? function(){} : $card.scrollIntoView.bind($card);

                                $card.trigger('willToggle', $card.revealed);
                                if ($card.revealed) {
                                    scrollCardIntoView();
                                    $card.fadeOut(willFinish.resolve);
                                } else {
                                    $card.fadeIn(function() { scrollCardIntoView();  willFinish.resolve(); quiet || $card.autofocus();});
                                    scrollCardIntoView();
                                    quiet || $card.autofocus();
                                }

                                $card.revealed = !$card.revealed;
                                //$card.appeal();

                                if (!$card.resoluted || ($card.revealed && $card.data('reload') == 'always')) {
                                    $card.module()
                                         .done(function(module) {willUpdate($card, module, extra);})
                                         .fail(function(e) {console.log(e);})
                                         .always(function() {$card.resoluted = true;});
                                } else if (!UTILS.isUndefined(extra)) {
                                    $card.module()
                                         .done(function(module) { willUpdate($card, module, extra); });
                                }
                            });
                        return willFinish.promise();
                    },

                    define: function() {
                        var args = UTILS.slice(arguments);
                        this.done(function($card) {
                            $card.module.apply($card, args);
                        });
                    }
                });
            }

            function loadFromFile(tag) {
                var $loader = $('<div>', {style: 'display: none;'}).load(getFileName(tag), whenDone);

                function resolveCard(card, $jqo) {
                    var future = $.Deferred(),
                        promise = $.extend(future.promise($jqo), {
                            appeal: function() {
                                var $self = this, color = $self.css('border-left-color');
//                                return $self.css({'border-color' : 'rgba(250, 128, 64, 0.75)'})
//                                    .animate({'border-color' : color}, function() {$self.css({'border-color': color});});
                                $self.css({'border-color' : 'rgba(250, 128, 64, 0.75)'});
                                setTimeout(function() {$self.css({'border-color': color});}, 200);

                                return this;
                            },
                            scrollIntoView: function (func) {
                                var sh = $sticky.height(),  st = $scroll.scrollTop(),
                                    tt = this.offset().top, th = this.outerHeight(),
                                    ch = $scroll.outerHeight();
                                if (th <= 1) { th = 23; }

                                if (tt < sh) {
                                    st -= (sh - tt) + 6;
                                } else if (th = Math.min(th, ch - (sh > 0 ? sh : $topCard.outerHeight() + $topCard.offset().top + 6) - 12), tt + th > ch) {
                                    st += (tt + th - ch) + 6;
                                }
                                func = func || function(pos) {$scroll.scrollTop(pos);};
                                func(st);
                            },
                            bindWith: function() {
                                var args = UTILS.slice(arguments);
                                args.unshift(this);
                                if (SCROLL_LOCK) {
                                    bind.apply(this, args);
                                } else {
                                    var container = this.closest('.scroll-y')[0], top = container.scrollTop;
                                    bind.apply(this, args);
                                    container.scrollTop = top;
                                    this.scrollIntoView();
                                }
                            },
                            isInitDone: INIT_NOTYET,
                            /* status: data being loaded */
                            resoluted: false,
                            /* status: card visible */
                            revealed: false,
                            module: function() {
                                if (arguments.length > 0) {
                                    var result = arguments.length == 1 ? arguments[0] : UTILS.slice(arguments);
                                    future.resolve(result);
                                }
                                return future.promise();
                            },
                            expect : function() {return future;}
                        });

                    card.resolve(promise);
                    return promise;
                };

                function whenDone(response, status, xhr) {
                    if (status === 'error') {
                        resolveCard(cards[tag], $scroll.find('.card[data-tag=' + tag + ']').addClass('na'))
                            .expect().reject("Unable to load module for card " + tag);
                    } else {
                        var modules = [], found = false;
                        if (cardsInPage.indexOf(tag) == -1) {
                            $loader.find('*[data-merge]').each(function() {
                                var $this = $(this);
                                // avoid merging duplicated resource
                                if ($this.is('script')) {
                                    var m = $this.data('merge') || $this.attr['src'];
                                    m && modules.push(m);
                                } else if ($this.parent().is('head')) {
                                    $('head').append($this);
                                } else {
                                    $('body').append($this);
                                }
                            });
                        }

                        $loader.find('.card[data-tag]')
                               .each(function(idx, dom) {
                                       var $dom = $(dom), datatag = $dom.data('tag') + '';

                                       var $content = $dom.children().clone();
                                       $dom.restore = function() {
                                           $dom.empty().append($content.clone());
                                       };
                                       resolveCard(cards[datatag] || (cards[datatag] = $.Deferred()), $dom);
                                       cardsInPage.push(datatag);
                                       datatag === tag && (found = true);
                                   });

                        modules.length > 0 && require(modules, function() {});

                        if (!found) {
                            whenDone(response, 'error', xhr);
                        }
                    }
                };
            }

            function getFileName(tag) {
                return 'card.' + TAG_TO_FILE[tag] + '.html';
            }
        }

        // END: card module
        // ------------------------------------------------------------------------

        var
            // tagはカードの識別子、今は画面表示と同じものを使っているが、お客様要求次第「画面はアルファベット連番、内部実装はtag」を使い分けが可能
            TAGS = {
                '1' : '建物基本情報',
                '2' : '支社所見',
                '3' : '棟情報',
                '4' : '収支状況',
                '5' : '収支推移集計表',
                '6' : '収支推移グラフ',
                '7' : '得意先',
                '8' : '営業担当',
                'I' : '施工担当',
                'J' : '施工部署',
                'K' : '棟別',
                'L' : '工事履歴',
                'M' : 'リニューアル予測表',
                'N' : '設備事故',
                'O' : 'クレーム',
                'P' : 'SS365',
                'Q' : '設備メンテナンス台帳',
                'R' : '当社開発商品',
                },
            // カード識別子のtagから実際のカード定義ファイル名への変換テーブル、実装者は各自に自分が使用するファイル名に置き換えてください。
            // [ファイル名規約(変更可能)] card.XXXX.html
            TAG_TO_FILE = {
                '1': 'sample123',
                '2': 'sample123',
                '3': 'sample123',
                '4': 'sample4',
                '5': 'sample567',
                '6': 'sample567',
                '7': 'sample567',
                '8': 'sample8',
                'I': 'sekoTanto',
                'J': 'SekoBuSiten',
                'K': 'TouBetsu',
                'L': 'KjiRireki',
                'M': 'ChoukiSznKei',
                'N': 'StbJiko',
                'O': 'claim',
                'P': 'ss365',
                'Q': 'StbMaint',
                'R': 'TsyaKhtShn'  },
            $tabs    = $('#tabs'),
            $topCard = $('div.card.top'),
            $sticky  = $('#sticky-wrapper'),
            $scroll  = $('#cell-cards > div.scroll-y'),
            $puller  = $('#puller'),
            PATTERNS = [
                ['すべてクリア', ''],
                ['建物の詳細情報', 'ABC'],
                ['収支に関する情報', 'DEFGHIJKL'],
                ['得意先に関する情報', 'GL'],
                ['品質に関する情報', 'NOPQR'],
                ['リニューアル予測表', 'M'],
                ['全体', Object.getOwnPropertyNames(TAGS).join('')]
            ];

        // update associated checker in tabs board
        function updateTab(tag, checked) {
            var $input = $tabs.find('label[data-tag=' + tag + '] + input'), curr = $input.prop('checked');
            $input.prop('checked', checked).checkboxradio('refresh');
            if (curr !== checked) {
                $('#puller .pull-handler').text('<ユーザ選択>');
            }
        }

        // initialize sticky header
        function stickHeader() {
            var top = $scroll[0].scrollTop, isStickyHidden = ($sticky.height() === 0 || $sticky.css('visibility') === 'hidden' || $sticky.is(':hidden'));
            if (top > 60 ) {
                // ready to stick
                if (isStickyHidden) {
                    var sw = $scroll.width() - $scroll[0].clientWidth + 4; 	// scroll bar width
                    $sticky.empty().css({'margin-right': sw + 'px'});
                    $topCard.clone().css({'visibility': 'visible', 'height': 'auto'}).appendTo($sticky).find('.exclude').hide();

                    var h = $sticky.height(),
                        // saved space when sticky header is visible
                        saved = $topCard.height() - h - 60,
                        // gap between bottom line of viewport and scroll content
                        gap = $scroll[0].scrollHeight - (top + $scroll.height());

                    if ((top > h + 60 || saved < gap) && (top > h || gap > h)) {
                        $topCard.css({'height': $sticky.height() + 60});
                        $topCard.css({'visibility': 'hidden'});
                        $sticky.fadeIn();
                    } else {
                        $sticky.hide();
                    }
                }
            } else {
                // always restore
                if (!isStickyHidden) {
                    $sticky.finish().fadeOut(function(){$sticky.empty().hide();});
                    $topCard.css({'height': 'auto', 'visibility': 'visible'});
                }
            }
        }

        var scrollDelayer = UTILS.delayer();
        $scroll.scroll(function() { scrollDelayer.call(stickHeader);});
        $(window).resize(function() {$scroll.scroll();});

        /**
        * mouseenter時、表示内容が幅が足りなくて表示しきれない項目に対するtooltip表示、および、mouseleave時tooltip非表示を行う
        * ("ellipse-on"をclassに指定したタグに対して上記制御を行い、value値をtooltip上に表示する)
        */
        $('#cell-cards').on('mouseenter', '.ellipse-on value', function(e) {
            var $e = $(this), h = $e.height(), ow = this.offsetWidth, sw = this.scrollWidth;

            $e.css({'overflow': 'visible', 'white-space': 'normal', 'word-break': 'break-all'});
            if (ow  < sw || $e.height() > h) {
                $e.opentip($e.text(), {removeElementsOnHide: true, style: 'dark'}).prepareToShow();
            }
            $e.css({overflow: '', 'white-space' : '', 'word-break': ''});
            if ($e.attr('style') === '') {
                $e.removeAttr('style');
            }
        }).on('mouseleave', '.ellipse-on value', function(e) {
            var tips = $(this).data('opentips');
            tips && (tips.forEach(function(t) {t.deactivate();}), $(this).removeData('opentips'));
        });

        /**
         * 初期表示ユーザ前回選択を復元する、またはパターンを選んで複数カードを強制表示する。
         *
         * @param tags 表示したいカードのタグの連結文字列
         * @returns 本当に表示したカードのタグの連結文字列（権限によって、削除されることがある）
         */
        function showTags(tags) {
            SCROLL_LOCK = true;
            $(document.body).removeClass("turbo");
            tags = tags.split('');
            var arr = [];			// collect available menu items
            $tabs.find(':not(.na) + input').each(function() {
                var $this = $(this);
                // メニューが抑止されていない、かつ、表示要求のあったカード(tags)のみカード表示する
                if ( $.inArray($this.prev().data('tag') + '', tags) > -1) {
                    arr.push($this.prev().data('tag') + '');	// NOTE: need to convert number to string
                }
                $this.prop('checked', tags.indexOf($this.prev().data('tag')+'') >= 0).checkboxradio('refresh');
            });

            var willDone = [];
            $scroll.find('.card[data-tag]').each(function() {
                var $this = $(this);
                if ($this.is(':visible')) {
                    willDone.push(card($this.data('tag')).toggle(false, true));
                }
            });

            tags = arr;
            if (tags.length > 0) {
                // 初期表示のレスポンスを改善するため、先頭のいくつかカードをロードした後さらに残り分を開く。
                var FIRST_RUN = 3;
                if (tags.length > FIRST_RUN) {
                    Array.prototype.push.apply(willDone, card(tags.slice(0, FIRST_RUN)).toggle(true, true));

                    var next = FIRST_RUN;
                    function batchLoad() {
                        var start = next;
                        next = Math.min(next + 3, tags.length);
                        Array.prototype.push.apply(willDone, card(tags.slice(start, next)).toggle(true, true));
                        if (next < tags.length) {
                            setTimeout(batchLoad);
                        }
                    };
                    setTimeout(batchLoad);
                } else {
                    Array.prototype.push.apply(willDone, card(tags).toggle(true, true));
                }
            }
            $.when.apply(null, willDone).done(function() { $scroll.scroll(); });
            $(document.body).addClass("turbo");
            return tags;
        }

        /**
         * メニュー表示処理（Serverから権限が取得できた場合）
         * Serverから各カードに対する表示権限を取得し、メニューのEnable/Disable状態を制御してメニューの表示を行う
         *
         * @param authLst カードの各権限(authLst.tag:タグ名('A'、'B'等)、authLst.auth[authIndex]:true(Enable)/false(Disable)
         */
        function initMenus(authLst) {
            var p,
            buf1 = UTILS.buffer('<div class="card" data-tag="', '"></div>'),
            buf2 = UTILS.buffer('<label data-tag="', '<input type="checkbox"/></label>');

            if(!UTILS.isUndefined(authLst)) {
                // 画面左上のエリアにログイン情報(ユーザID+ユーザ名)を設定する
                bind($('#cell-title'), authLst);
            }

            for (p in TAGS) {
                // カードの各権限が取得できた(Serverの処理結果を取得済み)場合、取得した権限に従い、メニュー項目はEnable/Disableを設定する
                // カードの各権限が取得できない(Serverの処理結果が返ってこない)場合、メニュー項目は全てDisableにする
                if(!UTILS.isUndefined(authLst)) {
                    // カードのタグが権限チェックを行ったカード、かつ、権限チェックでEnableと判定したカードのみ操作可能とする
                    var authIndex = $.inArray(p, authLst.tag);
                    if ( (authIndex > -1) && (authLst.auth[authIndex]) ) {
                        buf1.add(p);
                        buf2.add(p, '">', TAGS[p]);
                    } else {
                        buf1.add(p);
                        buf2.add(p, '" class="na">', TAGS[p]);
                    }
                } else {
                    buf1.add(p);
                    buf2.add(p, '" class="na--">', TAGS[p]);
                }
            }

            // fill tabs & cards(placeholder)
            $scroll.append($(buf1.join()));
            $tabs.controlgroup('container').html(buf2.join());

            /**
             *  メニューの生成、および、メニュー選択時に選択したカードを表示する
             *  メニュー選択時、選択したタグをログインユーザのStorageに保存する
             */
            $tabs.trigger('create')
                 .on('click', ':not(.na)', function(e, target) {
                     var $el = $(e.target);
                     if (e.clientX < $el.width() + $el.offset().left + 8) {
                         if ($el.next()[0].checked) {
                             card($el.attr('data-tag')).done(function($card) {
                                 $card.scrollIntoView(function(pos) {
                                     if (pos !== $scroll.scrollTop()) {
                                         //$scroll.animate({scrollTop: pos}, $card.appeal.bind($card));
                                         $scroll.scrollTop(pos);
                                     } else {
                                         //$card.appeal();
                                     }
                                 });
                             });
                             e.preventDefault();
                             e.stopPropagation();
                         }
                     }
                 })
                 .on('change', ':not(.na) + input', function(e, target) {
                     if (e.originalEvent && e.originalEvent.type === 'change') { return; }

                     SCROLL_LOCK = false;
                     target || (target = e.target);
                     card($(target).prev().attr('data-tag')).toggle()
                         .done(function() {
                            // TODO: search matched pattern
                            $('#puller .pull-handler').text('<ユーザ選択>');
                            $scroll.scroll();
                        });
                     })
                 .controlgroup({coners: true, shadow: true});

            /**
             * グループメニュー(puller)の初期処理、および、グループメニュー選択によるカード表示する。
             */
            $puller.puller({
                init: function() {
                    var buf = UTILS.buffer('<li>', '</li>'),
                        $list = $(this).find('.pull-list');
                    PATTERNS.forEach(function(each) {buf.add(each[0]);});
                    $list.html(buf.join());
                    $list.show().listview('refresh');
                    $(this).find('.pull-handler').text('<ユーザ選択>');
                },
                cancelable: true,
                cancelCaption: '取り消す',
                caption: '放して選択'
            })
            .on('change', function(e, $selected) {
                var $handler = $('#puller .pull-handler'),
                    txt = PATTERNS[$selected.index()][0];
                if (txt != $handler.text()) {
                    var tags = PATTERNS[$selected.index()][1];
                    $handler.text(txt);
                    showTags(tags);
                }
            });
        }

        /**
         * 縮小したヘッダにクリックすると、スクロールバーを0に戻してヘッダを復元する。
         */
        $sticky.on('click', function(e) {
            if (!$(e.target).hasClass('btn')) {
                //$scroll.animate({scrollTop: 0});
                $scroll.scrollTop(0);
            }
        });

        /**
         * メニュー表示処理（Serverから応答がなく権限が取得できなかった場合）
         * メニュー表示処理を引数：カードの権限をなしでコールすることで、メニューを全てDisable状態で表示する
         *
         */
        function errBack() {
            initMenus();
        }

        initMenus();
      
        /**
         * メニュー表示処理
         * Serverから各カードの権限を取得して、メニュー表示処理を実施する
         *
         */
//        Remote.use(['IDetailsService', 'IMasterService'], function (detailsService, masterService) {
//            menuAuth = detailsService.getMenuAuth(TAG_AUTH_CHKPTN_CODE)
//                .done(initMenus)
//                .fail(errBack);
//
//            radioOptions = UTILS.expect(function() {
//            });

            // BEGIN: details common module
            // ------------------------------------------------------------------------

            /**
             * ラジオ選択肢を取得するキャッシュ・ファクション。
             *
             * @param key DB保存に使われるラジオ選択肢のキー、受注形態 = "1", 物件区分２ = "2", 工事種 = "3"
             * @return 戻り値はpromiseオブジェクトである。
             */
            var radioOptions = UTILS.expect(function(deferred, key) {
                masterService.getRadio(key).done(function(data) { deferred.resolve(data.radio); });
            });

            define('details.common', {
                initRadioOptions: function($rdo, key, name, changeHandler) {
                    // 物件区分2(ラジオボタン)を設定する
                    radioOptions(key).done(function(options) {
                        var i, buf = UTILS.buffer();

                        // 動的にラジオボタンのリストを生成する
                        for (i = 0; i < options.length; i++) {
                            var ct = options[i];
                            buf.add('<input name="' + name + '" id="ct-', ct[0], '" value="', ct[0], '" type="radio">')
                               .add('<label for="ct-', ct[0], '">', ct[1], '</label>');
                        }

                        // jQuery Mobileが自動的に処理しないみたいため、最初と最後のラベルにマーカー・クラスを付ける（丸い角表示用）
                        var $list2 = $(buf.join())
                           .filter('label')
                               .first().addClass('ui-first-child').end()
                               .last().addClass('ui-last-child').end()
                            .end();

                        // jQuery MobileのControlGroupを明示的に生成する。
                        $rdo.controlgroup('container').append($list2).trigger('create');
                        // 最初のラジオボタンをONにする
                        $rdo.find('.ui-radio input').first().click();
                        // 表示を更新する
                        $rdo.controlgroup('refresh');
                        // ハンドラーを登録する
                        changeHandler && $rdo.on('change', changeHandler);
                    });
                }
            });

            // END: details common module
            // ------------------------------------------------------------------------
//        });


        /**
         * 建物メイン表示処理
         * 画面右上のカードに建物の主要情報を表示する
         *
         */
        var data = {};
        bind($('#cell-cards'), data);
        $('#btnBack').css("display", "inline-block");

        $(document).on('click', '#btnBack', function() {
//            window.location.href = 'buildings.html';
            window.location.reload();
        });

        $(document).on('click', '#btnBackKji', function() {
            window.location.href = 'kjiJiskBuildings.html';
        });

        $(document).on('click', '#btnBackSs365', function() {
            window.location.href = 'ss365Buildings.html';
        });

        $(document).on('click', '#btnBackTsyKihtShn', function() {
            window.location.href = 'tsyKihtShnList.html';
        });

        $(document).on('click', '#btnLogout', function() {
            Remote.use(['ILoginService'], function (loginService) {
                loginService
                    .doLogout()
                    .always( function() {
                        window.location.href = 'login.html?logout';
                    });
            });
        });

        $(document).on('click', '#btnmap', function() {
            var mapaddress = document.getElementById("tmnoMapAddress").value;
            window.open('http://maps.google.co.jp/maps?f=q&hl=ja&z=17&q=' + mapaddress);
        });

        $.fx.off = true;
    });
});
