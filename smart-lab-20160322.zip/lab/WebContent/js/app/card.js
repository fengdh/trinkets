// Card Module
define(['jquery', 'ryn/utils', 'ryn/ui.widget', 'ryn/remote'], function($, UTILS, Widget, Remote) { 
  var $scroll, $sticky, emitter = $({}), 
      revealLater = UTILS.delayer(),
      willStartup = UTILS.delayer().call.bind(null, startup);

  var domain = Widget.register('card',{
        finder: {
               package: {
                 'card.sample123' : ['1', '2', '3'],
                   'card.sample4' : ['4'],
                 'card.sample567' : ['5', '6', '7'],
                   'card.sample8' : ['8'],
               }
            },
         ':mixin': '[data-merge]',   '@url': 'data-merge',
         ':model': '.card[data-tag]', '@id': 'data-tag',
           events: {created: true, defined: true},
          content: function($el) { return $el },
         location: function(path) { return path + '.html' },
            solve: requirejs.toUrl,
            proto: [
                function _CardRoot() {
                  console.info('Card Domain: ROOT constructor invoked by', this.$('id'));
                  this.$().css({'xbackground-color':'#CCC'}).toggleClass('card notready', true);
                }, 
                { showup: function(quiet, willReady) { 
                            this.$().show();

                            willReady = willReady || $.Deferred().resolveWith(this);
                            willReady.then(function() { 
                              this.appeal();
                              quiet < 0 && revealLater.call(reveal.bind(null,this.$()));
                            });
                            return this; 
                          },
                  appeal: function(duration, done) {
                            var $self = this.$().finish(), color = $self.css('border-left-color');
                            $self.css({'border-color' : 'rgba(250, 128, 64, 0.95)'})
                                 .animate({'border-color' : color}, duration || 300, done);
                            return this;
                          },
               disappear: function(quiet) {
                            if (quiet < 0) {
                              var $el = this.$();
                              reveal($el);
                              $scroll.queue(function() {
                                var color = $el.css('border-left-color');
                                $el.css({'border-color' : 'rgba(250, 128, 64, 0.95)'})
                                   .delay(50)
                                   .slideUp(150)
                                   .animate({'border-color' : color}, 300)
                                $scroll.dequeue();
                              });
                            } else {
                              this.$().hide();
                            }
                          }
                }
          ]
        });

  function reveal($el, done) {
    var sh = $sticky.height(),  st = $scroll.scrollTop(),
        tt = $el.offset().top,  th = $el.outerHeight(),
        ch = $scroll.outerHeight();
    if (th <= 1) { th = 23; }

    if (tt < sh) {
        st -= (sh - tt) + 6;
    } else if (th = Math.min(th, ch - (sh > 0 ? sh : $sticky.outerHeight() + $sticky.offset().top + 6) - 12), tt + th > ch) {
        st += (tt + th - ch) + 6;
    }
    
    return $scroll.animate({scrollTop: st}, 100, done);
  }
  
  // DEBUG
  domain.on('created defined',    function(e, id, def)   { console.info('CARD', e.type, id, def); });
  
  var NOOP = Widget._.NOOP, fnConst = Widget._.fnConst, 
      queue = [], repo = {}, pool = UTILS.pool(1);
  
  var SingleCard = {
         items: fnConst([this]),
        widget: NOOP,
         trait: fnConst({}),
        define: function(trait, setup, proto) {
                  !trait || (this.trait = fnConst(trait));
                  this.model().define(setup, proto);
                  return this;
                },
        toggle: function(visible, quiet, extra) {
                  var w = this.widget(), thisItem = this, willDone = $.Deferred();
                  if (!w) {
                    this.widget = fnConst(w = this.model().thenCreate());
                    w.then(function() {
                      var proxy = this, $el = this.$();
                      $scroll.find(':tag(' + this.$('id') + ')').replaceWith(this.$());
                      if (!$el.isInitDone) {
                        $el.trigger('create');  // for jQuery Mobile
                        $el.isInitDone = fnConst(false);
                        $el.restore = function restore() {
                          w.restore();
                          var $fresh = proxy.$();
                          $fresh.restore = restore;
// DELETE next line!                          
                          $fresh.prepend($('<div>', {html: new Date + ''}));
                          proxy.showup(true, thisItem.willReady);
                          proxy.$().removeClass('notready');
                          return $fresh;
                        }
                        queueStartup(thisItem, extra);
                      }
                      willDone.resolve();
                    }, whenFail);
                  }
                  w.then(function() {
                    if (this.visible !== visible || visible === void 0) {
                      this.visible ? this.disappear(quiet) : this.showup(quiet, thisItem.willReady);
                      this.visible = !this.visible;
                      willDone.resolve();
                    }
                  }, whenFail);
                  return $.when(willDone, this.willReady);
                },
          show: function(extra) {
                  var thisItem = this, w = this.widget();
                  if (w) {
                    w.then(function() {
                      queueStartup(thisItem, extra);
                      thisItem.willReady.then(function() {
                        this.showup(-1, thisItem.willReady);
                      })
                    })
                  } else {
                    thisItem.toggle(true, -1, extra);
                  }
                  emitter.trigger('toggle', [thisItem.model().id(), true]);
                }
      };
  
  function CardSet(items) {
    this.items = function() { return items };
  }
  
  CardSet.prototype = {
      define: function(trait, setup, proto) {
        this.items().forEach(function(each) { each.define(trait, setup, proto) });
        return this;
      },
      toggle: function(visible, quiet, extra) {
        this.items().forEach(function(each, index) { each.toggle(visible, quiet ? true : (index === 0 ? -1 : 0), extra) });
        return this;
      },
  };

  function Item(model) {
    this.model = fnConst(model);
    this.willReady = $.Deferred();
  }
  
  Item.prototype = SingleCard;


  function startup() {
    var copy = queue.slice(0), keys, set = {};
    queue = [];
    if (copy.length === 0) {
      return;
    }
    copy.forEach(function(entry) {
      console.info("willStartup: card.", entry.item.model().id());
      var trait = entry.item.trait(), arr = entry.use = $.makeArray(trait.use || trait.uses);
      for (var i in arr) {
          set[arr[i]] = null;
      }
    });
    keys = Object.keys(set);
    
    Remote.use(keys,function() {
      for (var i in keys) {
        set[keys[i]] = arguments[i];
      }

      Remote.Session.open({async:true});

      copy.forEach(function(entry) {
        var item = entry.item, trait = item.trait(), slot = pool.get();
        
        $.when(slot, item.widget()).then(function(_, thisWidget) {
          var result, $el = thisWidget.$();
          if (trait && trait.reload) {
            var args = [$el], use = entry.use;
            if (use.length) {
              for (var j in use) {
                args.push(set[use[j]]);
              }
            }
            if (entry.extra) {
              args.push(entry.extra)
            }
            result = trait.reload.apply(thisWidget, args);
          }
          $el.isInitDone = fnConst(true);
          $el.removeClass('notready');
          $.when(thisWidget, result).then(function(wp) {
            item.willReady.resolveWith(wp);
          })
        }, whenFail).done(setTimeout.bind(null, slot.free));

      })

      Remote.Session.close();
    });
  }
  
  function queueStartup(item, extra) {
    queue.push({item: item, extra: extra});
    willStartup();
  }
  
  function whenFail(e) {
    console.log(e)
  }

  function getCards(id /* or id_0, id_1, ... */) {
    if (arguments.length === 1 && !$.isArray(id)) {
      return repo[id] = repo[id] || new Item(domain(id));
    } else {
      var args = $.isArray(id) ? id : arguments;
      return new CardSet([].map.call(args, function(id) { return repo[id] = repo[id] || new Item(domain(id)) }));
    }
  }
  
  getCards.resideIn = function($el, $top) { return $scroll = $($el), $sticky = $($top), this };
  getCards.slotSize = function(n) { return pool.adjust(n), this };
  getCards.on       = function()  { return $.fn.on.apply(emitter, [].slice.apply(arguments)), this };
  
  return getCards;
}); 