define(['jquery', 'jquery.mobile'], function($) {
    console.log("executing: card.blank.js");
    $('<link>')
        .appendTo($('head'))
        .attr({type : 'text/css', rel : 'stylesheet'})
        .attr('href', '../css/card.blank.css');
    
    if (location.protocol == "file:") {
        $('<link>')
            .appendTo($('head'))
            .attr({type : 'text/css', rel : 'stylesheet'})
            .attr('href', '../css/dev.css');
    }
});
