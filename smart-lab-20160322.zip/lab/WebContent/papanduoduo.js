(function(start, max, threshold) {
  var URL = '/u/bd/',
      $div = $('<div>', {'style': 'display: none;'}),
      page = start,
      arr = [];
      
      threshold = threshold || 10;

      function parse($top) {
        $top.find('li > .content').each(function() {
          var $e = $(this), $t = $e.children('a'), $d = $e.find('.list-content > b'),
              item = {
                  bdid: $t.attr('href').slice(6), 
                  name: $t.attr('title').slice(0, -3),
                 share: +$d[0].innerText || 0, 
                follow: +$d[1].innerText || 0, 
                   fan: +$d[2].innerText || 0};
          item.share > threshold && arr.push(item);
        });
      }

      function whenDone() {
        $div.remove();
        console.log('-------');
        console.log(arr.length > 0 ? '发现这么些个分享达人：' + arr.length : '哪有神马分享达人？');
        arr.sort(function(a, b) {
          var diff = a.share - b.share;
          return -(diff != 0 ? diff : (a.name > b.name ? -1 : 1));
        });
        arr.forEach(function(v) {
          console.log(v.share, v.name, 'http://pan.baidu.com/share/home?uk=' + v.bdid);
        });
      }
  
      function go() {
        console.log('正在爬第' + ++page + '页...');
        if (page === 1) {
          parse($('body'));
          go();
        } else {
          $div.load(URL + page, function(data, status, xhr) {
            if (data) {
                parse($div);
                $div.empty();
                if (page < max) {
                  go();
                  return;
                }
                whenDone();
            } else {
              console.log('爬不起来了，看看神马情况:', data, status, xhr);
            }
          });
        }
      }

      go();
      return '爬一爬盘多多上列出的分享达人：'
})(0, 10, 50); // 开始页, 终止页，分享数下限