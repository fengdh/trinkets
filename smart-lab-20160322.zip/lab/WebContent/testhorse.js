require(['ryn/ui.widget', 'card'], function(widget, card) { 
  var kit = widget.domain('sample');
  kit.on('defined',    function(e, id, def)   { console.info(e.type, id, def); def.props.title='Z'; });
  kit.on('willCreate', function(e, id, invoc) { console.info(e.type, id, invoc); });
  kit.on('created',    function(e, id, widget){ console.info(e.type, id, widget); });

  var DATA = {name: 'Wilson Robert', addr: 'Palmo, CA', status: '★★★　　'};
  var log = function(r) { console.log(r) }, CONTAINER = '#cell-cards .scroll-y';
  
  function one(id1, id2) {
    var pw1 = kit(id1).thenCreate(DATA);
    var pw2 = kit(id2).thenCreate(DATA);

    console.log(pw1, pw2);
    
    pw1.will($.fn.css, {'box-shadow': '1px 1px 8px rgba(0,0,0,0.4)'});

    $.when(pw1, pw2).then(function(w1, w2) { 
       console.log(w1, w2);
       w1.$().appendTo(CONTAINER);
       w2.$().appendTo(CONTAINER);
       w1.show().shake().mow();
       w2.show().redAlert().mow().shake();

//       throw (new Date).getTime();
     }, function(e) { console.log('EEE', e); });
  }
  
//  var card1 = card('1').at(0).thenCreate();
//  card1.then(function(w) { console.log(w); w.toggle() });
//  card1.appendTo(CONTAINER).will($.fn.show)();
  
  card.resideIn(CONTAINER, $('#sticky-wrapper'));
//  card('1','2').toggle();
  
  one('sample>edit:pro', 'sample>edit');
  one('sample>edit:pro:neo', 'sample>info');
});


require(['ryn/ui.widget', 'card'], function(widget, card) { 
    var kit = widget.domain('sample'), CONTAINER = '#cell-cards .scroll-y';

//    kit('sample>edit:pro:neo').thenCreate().then(function() {
//      this.$().appendTo($(CONTAINER));
//      this.show().redAlert().shake();
//    });
  
    kit.scan('sample');

    function NormalButton(name) {
      this.redAlert()
          .$().find('span').on('click', this.popup.bind(this));
      if (name !== void 0) {
        this.$().find('span').text(name);
      }
    }

    function BigButton(name) {
      BigButton._super(name); // equals to ===>  NormalButton.call(this, name);
      this.$().find('span').css({'font-size': '20pt'});
    }

    var protoNormalButton = {
            popup: function() {
                     this.$().css({'background-color': '#EA5'})
                             .find('span').css({'background-color': 'yellow'});
                   },
        },
        protoBigButton = {
            popup: function() {
                     this.shake()
                         .$().css({'background-color': 'blue'})
                             .find('span').css({'background-color': 'cyan'});
                   },
        };

    var normalButtonModel = kit.draft('button').pupulate($('<div class="push"><span class="btn blue">Press me!</span></div>'));

    var bigButtonModel = kit('button:big').define(BigButton, protoBigButton);
    
    normalButtonModel.define(NormalButton, protoNormalButton);

    normalButtonModel.thenCreate('I am a humble button.').appendTo(CONTAINER);
    bigButtonModel.thenCreate().cast($('#lottery'));
    bigButtonModel.thenCreate('BIG NOISY BUTTON').appendTo(CONTAINER);
});