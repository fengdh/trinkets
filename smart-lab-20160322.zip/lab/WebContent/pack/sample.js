
require(['jquery', 'ryn/ui.widget', 'ryn/ui.databind'], function($, widget, bind) {
    var kit = widget.domain('sample');
  
    // base
    kit('sample>info').define(
      function SampleInfo(data) {
        SampleInfo._super();
        console.log('setup: ', this.$('id'), arguments);
        bind(this.$(), data || {status: ''});
      }, 
      { tag: '◆',
        title: '情報',
        color: '#AAA',
        shake: function() { return this },
          mow: function() {
                 return console.log(this.$('id') + ' is unable to say MOW~'), this;
               },          
      });

    // another base
    kit('sample>edit').define(
      function SampleEdit(data) {
        // SampleEdit._super();  // call root constructor implicitly
        console.log('setup: ', 'in sample.edit, by ', this.$('id'));
        bind(this.$(), data || this.initialData);
      }, 
      { tag: '★',
        title: 'サンプル',
        initialData: {name: '--邸', addr: '[都道府県]', contractor: '[業者]', floor: '－－'},
        msg: 'Parents say "Wonderful".',
        color: '#F44',
      }
    ).then(function(r) {
      console.log('sample.edit is defined: ', r);  // module itself
    });
  
    // child
    kit('sample>edit:pro').define(
      function SampleEditPro(data) {
        // unable to pass modified this.msg to root constructor of domain
        this.msg = this.msg + ' Or "Cool" for some guys.'; 
        SampleEditPro._super(data);
        console.log('setup: ', 'in sample.edit.pro, by ', this.$('id'));

        var $el = this.$();
        bind($el, $.extend(data, {type: '3D Print'}));
        $el.css({'background-color': '#FF8'});
        $el.find(':tag(type) > label').text('革新工法').css({'font-weight': 'bold'});
        $el.find(':tag(type) > value').css({background: '#888', color: '#FFF'});
      }, 
      {      msg: 'Children like "Awsome".',
           color: '#4A4',
        redAlert: function(color, anim) { 
                    console.log('redAlert by ', this.$('id')); 
                    console.log('\t overriden in ' + 'sampel.edit:pro');
                    try {
                      return this.$('super').redAlert(color, anim);
                    } catch (e) {
                      throw e;
                    }
                  },
      }
    ); 
  
    // grand child
    kit('sample>edit:pro:neo').define(
      function SampleEditProNeo(data) {
        SampleEditProNeo._super(data);
      },
      { msg: 'Neo-gen retreats to old fashion. ',
        color: '#44F',
        redAlert: function(color, anim) { 
                    console.log('redAlert by ', this.$('id')); 
                    console.log('\t overriden in ' + 'sampel.edit:pro:neo');
                    console.log('super.msg = ', this.$('super').msg); 
                    try {
                      this.$().css({'-webkit-filter': 'blur(0.7px)'});
                      return this.$('super').redAlert(color, anim);
                    } catch (e) {
                      throw e;
                    }
                  },
      }
    )

});
