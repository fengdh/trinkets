<link rel="stylesheet" type="text/css" href="css/details.css">

<div class="card top">
<div type="button" class="btn" style="font-style:italic">thinking smart</div>

## ** Working with `ryn.ui.widget.js` **
</div>

- What is ryn.ui.widget.js?
- Concepts in ryn.ui.widget.js
- Define a widget
- Use a widget
- Configuration

## What is ryn.ui.widget.js?


ryn.ui.widget.js is a Javascript library defined as an AMD module, which can be used 
to develop web application 

- [x] @mentions, #refs, [links](), **formatting**, and <del>tags</del> supported
- [x] list syntax required (any unordered or ordered list supported)
- [x] this is a complete item
- [ ] this is an incomplete item

 
 First Header | Second Header
------------ | -------------
Content from cell 1 | Content from cell 2
Content in the first column | Content in the second column


** This is ** important * for users *
> Quoting from
> Wikipedia

```javascript
var y = 100;
```
    d dooddfd ddood >
    
----------------------------
    code block
----------------------------