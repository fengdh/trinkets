define([], [
  {
    name: 'ICardService',
    methods: [
      {name: 'getCardData'}
    ]
  },
]);