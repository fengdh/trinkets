define([], [
  {
    name: 'prototype/IZipService',
    methods: [
      {name: 'listAll'},
      {name: 'lookup'},
      {name: 'search'}
    ]
  }  
]);