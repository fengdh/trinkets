define([], [
  {
    name: 'ICardService',
    methods: [
      {name: 'getCardData'}
    ]
  },
  {
    name: 'prototype/IZipService',
    methods: [
      {name: 'listAll'},
      {name: 'lookup'},
      {name: 'search'}
    ]
  }  
]);