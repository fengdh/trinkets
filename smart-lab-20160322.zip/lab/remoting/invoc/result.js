[
  {"value": {"floorArea": 789789,
             "siteReport": "現場からの報告...",
             "salesReport": "セールスポイントは..."
            }, 
   "ryn.remote.result":0},
  
  {"value": {"floorArea": 789789,
             "siteReport": "現場からの報告...",
             "salesReport": "セールスポイントは..."
            }, 
   "ryn.remote.result":0},
  
  {"value": ["1001001", "1107878"], 
   "ryn.remote.result":0},
  
  {"value": ["1001001", "1107878"], 
   "ryn.remote.result":0},
  
  {"value": {"floorArea": 789789,
             "siteReport": "現場からの報告...",
             "salesReport": "セールスポイントは..."
            }, 
   "ryn.remote.result":0},
  
  {"value": {"floorArea": 789789,
             "siteReport": "現場からの報告...",
             "salesReport": "セールスポイントは..."
            }, 
   "ryn.remote.result":0},
  
  {"value": ["1001001", "1107878"], 
   "ryn.remote.result":0},
  
  {"value": ["1001001", "1107878"], 
   "ryn.remote.result":0}
  
]